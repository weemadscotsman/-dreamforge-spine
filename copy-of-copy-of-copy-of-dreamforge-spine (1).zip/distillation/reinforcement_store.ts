
import { WeightedHeuristic } from './types';
import { realtimeBus } from '../bridge/realtime_bus';

const STORAGE_KEY = 'dreamforge_heuristics_v1';

/**
 * [DISTILLATION] REINFORCEMENT STORE
 * The "JSON" file equivalent. Stores the active rule set.
 * Persists to LocalStorage to maintain evolution across reloads.
 */
class ReinforcementStore {
  private heuristics: Map<string, WeightedHeuristic> = new Map();

  constructor() {
    this.load();
  }

  private broadcast() {
      realtimeBus.emit('HEURISTICS_UPDATE', this.getAll());
  }

  /**
   * Merges new heuristics into the store.
   * If a rule exists, it boosts the weight (Reinforcement Learning).
   */
  ingest(newHeuristics: WeightedHeuristic[]) {
    let changed = false;
    for (const h of newHeuristics) {
      const key = h.rule;
      const existing = this.heuristics.get(key);

      if (existing) {
        // Reinforce: Add weight, increment count
        // Diminishing returns on weight boost to prevent infinity
        const weightBoost = h.weight * 0.1; 
        
        existing.weight = parseFloat((existing.weight + weightBoost).toFixed(2));
        existing.sourceCount++;
        existing.lastReinforced = Date.now();
        changed = true;
      } else {
        // New strategy discovered
        this.heuristics.set(key, h);
        changed = true;
      }
    }
    if (changed) {
        this.save();
        this.broadcast();
    }
  }

  /**
   * Update a single heuristic (used by Delta Hooks)
   */
  update(h: WeightedHeuristic) {
      this.heuristics.set(h.rule, h);
      this.save();
      this.broadcast();
  }

  add(h: WeightedHeuristic) {
      this.heuristics.set(h.rule, h);
      this.save();
      this.broadcast();
  }

  /**
   * Remove a heuristic from the active set.
   * Returns the removed item (for Graveyard transfer).
   */
  remove(rule: string): WeightedHeuristic | undefined {
      const item = this.heuristics.get(rule);
      if (item) {
          this.heuristics.delete(rule);
          this.save();
          this.broadcast();
      }
      return item;
  }

  /**
   * [NEW] Replace the entire state (used for pruning/evolution).
   */
  replaceState(survivors: WeightedHeuristic[]) {
    this.heuristics.clear();
    for (const h of survivors) {
      this.heuristics.set(h.rule, h);
    }
    this.save();
    this.broadcast();
  }

  /**
   * [NEW] STAGNATION CHECK
   * If a strategy is dominant (weight > 0.8) but hasn't mutated or generated new insights, kill it.
   * Prevents 100% dominance lock-in.
   */
  checkStagnation(): string[] {
      const killed: string[] = [];
      for (const h of this.heuristics.values()) {
          // If dominant AND old AND pure (not mutated recently)
          if (h.weight > 0.8 && !h.mutated && (Date.now() - h.lastReinforced > 1000 * 60 * 5)) {
              // Too old, too strong. Stifling innovation.
              this.heuristics.delete(h.rule);
              killed.push(h.rule);
          }
          // Cap max weight to prevent total monopoly
          if (h.weight > 2.0) {
              h.weight = 2.0;
          }
      }
      if (killed.length > 0) {
          this.save();
          this.broadcast();
      }
      return killed;
  }

  /**
   * Get the top N strongest heuristics to apply as pressure.
   */
  getActiveRules(limit: number = 5): WeightedHeuristic[] {
    return Array.from(this.heuristics.values())
      .sort((a, b) => b.weight - a.weight) // Descending weight
      .slice(0, limit);
  }

  /**
   * [NEW] Get heuristics that have survived (weight > 0.1)
   */
  getWeightedHeuristics(): WeightedHeuristic[] {
    return Array.from(this.heuristics.values())
        .filter(h => h.weight > 0.1);
  }
  
  getAll(): WeightedHeuristic[] {
      return Array.from(this.heuristics.values());
  }

  private save() {
      if (typeof window !== 'undefined') {
          try {
              const serializable = Array.from(this.heuristics.entries());
              localStorage.setItem(STORAGE_KEY, JSON.stringify(serializable));
          } catch (e) {
              console.warn("Failed to persist heuristics", e);
          }
      }
  }

  private load() {
      if (typeof window !== 'undefined') {
          const raw = localStorage.getItem(STORAGE_KEY);
          if (raw) {
               try {
                   const entries = JSON.parse(raw);
                   this.heuristics = new Map(entries);
               } catch(e) { console.warn("Failed to load heuristics", e); }
          }
      }
  }
}

export const reinforcementStore = new ReinforcementStore();

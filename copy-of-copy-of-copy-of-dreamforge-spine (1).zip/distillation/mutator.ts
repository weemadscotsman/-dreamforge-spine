import { WeightedHeuristic } from './types';
import { reinforcementStore } from './reinforcement_store';

/**
 * [DISTILLATION] MUTATOR
 * Evolves heuristics that are surviving but not thriving.
 * Applies genetic operations: Intensification, Abstraction, Inversion.
 */

export function mutate_heuristics(scores: number[]): WeightedHeuristic[] {
  const heuristics = reinforcementStore.getAll();
  const mutants: WeightedHeuristic[] = [];

  // Check for plateau: Are recent scores stagnant?
  // If we don't have enough history in this batch, we assume false, 
  // but if the batch is tight (e.g. all ~80), we trigger mutation to break local maxima.
  if (!is_plateau(scores)) {
    return [];
  }

  for (const h of heuristics) {
    const w = h.weight;

    // Trigger Condition:
    // 1. Survived (weight > 1.0)
    // 2. But not Dominant (weight < 2.5)
    // 3. System is plateauing (scores are flat)
    const stagnant = w > 1.0 && w < 2.5;

    if (!stagnant) continue;

    const mutatedRule = mutate_rule(h.rule);
    
    // Only add if it actually changed
    if (mutatedRule !== h.rule) {
      mutants.push({
        ...h,
        rule: mutatedRule,
        mutated: true,
        weight: h.weight, // Inherit parent weight
        sourceCount: 1,
        lastReinforced: Date.now()
      });
    }
  }

  return mutants;
}

function is_plateau(scores: number[]): boolean {
  if (scores.length < 2) return false;
  
  const min = Math.min(...scores);
  const max = Math.max(...scores);
  
  // If the spread of scores is very low, we are stuck
  return (max - min) < 2.0; 
}

function mutate_rule(rule: string): string {
  let r = rule.toLowerCase();

  // 1. INTENSIFICATION (Shorten & Harden)
  if (r.includes("surface assumptions")) return r.replace("surface assumptions", "assumptions first");
  if (r.includes("compress before expand")) return "compress first";
  if (r.includes("resolve contradictions")) return "kill contradictions";

  // 2. ABSTRACTION (Target higher category)
  if (r.includes("contradictions")) return r.replace("contradictions", "logical conflicts");
  if (r.includes("verify claims")) return "reduce uncertainty";
  if (r.includes("check against")) return "ground via retrieval";

  // 3. INVERSION (Flip tactic)
  if (r.includes("verify before synthesis")) return "synthesize then verify";
  if (r.includes("infer intent")) return "construct intent model";

  // 4. SYNTACTIC DRIFT (General cleanup)
  if (r.includes("verify")) return r.replace("verify", "probe");
  if (r.includes("compress")) return r.replace("compress", "distill");
  if (r.includes("check")) return r.replace("check", "audit");

  return r; // No mutation
}
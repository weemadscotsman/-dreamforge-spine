import { WeightedHeuristic, DeadHeuristic } from './types';

/**
 * [DISTILLATION] GRAVEYARD STORE
 * Where heuristics go to die. Or wait.
 */
class GraveyardStore {
  private crypt: Map<string, DeadHeuristic> = new Map();

  /**
   * Bury the weak.
   */
  bury(heuristics: WeightedHeuristic[]) {
    for (const h of heuristics) {
      if (!this.crypt.has(h.rule)) {
        this.crypt.set(h.rule, {
          rule: h.rule,
          type: h.type,
          weightAtDeath: h.weight,
          cyclesDead: 0,
          deathTimestamp: Date.now()
        });
      } else {
        // Already dead? Reset timer logic if needed, but usually 
        // we just leave it rotting unless it was re-added and re-killed.
        // If it's re-killed, it implies it was resurrected. 
        // We just overwrite to reset the cooldown.
        const corpse = this.crypt.get(h.rule)!;
        corpse.cyclesDead = 0;
        corpse.deathTimestamp = Date.now();
        corpse.weightAtDeath = h.weight;
      }
    }
  }

  /**
   * Check if a rule is in the graveyard.
   */
  inspect(rule: string): DeadHeuristic | undefined {
    return this.crypt.get(rule);
  }

  /**
   * Remove from graveyard (it lives again!).
   */
  exhume(rule: string) {
    this.crypt.delete(rule);
  }

  /**
   * Advance time for all dead rules.
   */
  tick() {
    for (const corpse of this.crypt.values()) {
      corpse.cyclesDead++;
    }
  }

  getAll(): DeadHeuristic[] {
    return Array.from(this.crypt.values());
  }
}

export const graveyardStore = new GraveyardStore();
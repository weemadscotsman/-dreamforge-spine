import { reinforcementStore } from './reinforcement_store';
import { graveyardStore } from './graveyard_store';
import { WeightedHeuristic } from './types';

const DECAY_RATE = 0.05;         // Natural forgetting per cycle
const VIOLATION_PENALTY = 0.25;  // Heavy hit for ignoring a rule
const MIN_SURVIVAL = 0.50;       // Cull threshold

/**
 * [DISTILLATION] SELECTION PRESSURE
 * Applies evolutionary logic to the heuristic store.
 * 
 * Rules:
 * 1. All rules decay slightly (entropy).
 * 2. Violated rules take a massive penalty.
 * 3. Weak rules (weight < MIN_SURVIVAL) are culled (death).
 * 4. Culled rules are sent to the Graveyard.
 */
export function applySelectionPressure(violatedRules: string[] = []): WeightedHeuristic[] {
  const current = reinforcementStore.getAll();
  
  // Age the existing dead before adding new ones
  graveyardStore.tick();
  
  if (current.length === 0) return [];

  const survivors: WeightedHeuristic[] = [];
  const dead: WeightedHeuristic[] = [];

  for (const h of current) {
    let w = h.weight;

    // 1. Apply Entropy (Decay)
    w = w - DECAY_RATE;

    // 2. Apply Penalty
    if (violatedRules.includes(h.rule)) {
      w = w - VIOLATION_PENALTY;
    }

    w = parseFloat(Math.max(w, 0).toFixed(2));

    // 3. Cull Check
    if (w >= MIN_SURVIVAL) {
      survivors.push({ ...h, weight: w });
    } else {
      dead.push({ ...h, weight: w });
    }
  }

  // Commit evolution
  reinforcementStore.replaceState(survivors);
  
  // 4. Bury the dead
  if (dead.length > 0) {
    graveyardStore.bury(dead);
    console.log(`[SELECTION] Buried ${dead.length} rules:`, dead.map(d => d.rule));
  }

  return survivors;
}
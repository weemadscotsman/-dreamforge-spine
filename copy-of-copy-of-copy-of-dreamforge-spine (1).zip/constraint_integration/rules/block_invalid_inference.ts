import { ArgumentStructure } from "../../argument_builder/types";

export const blockInvalidInference = (
  arg: ArgumentStructure
): { blocked: boolean; violations: string[] } => {
  // rule: if no premises, stop inference (protects null chains from hallucination)
  if (!arg.premises || arg.premises.length === 0) {
    return { blocked: true, violations: ["no_premises"] };
  }

  // rule: if no vars present in argument, reasoning collapses to tautology
  if (!arg.vars || arg.vars.length === 0) {
    return { blocked: true, violations: ["no_variables"] };
  }

  return { blocked: false, violations: [] };
};
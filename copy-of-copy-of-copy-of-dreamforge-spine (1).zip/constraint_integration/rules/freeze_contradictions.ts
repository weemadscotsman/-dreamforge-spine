import { ReasoningGraph } from "../../graph_reasoning/types";

export const freezeContradictions = (
  graph: ReasoningGraph
): { graph: ReasoningGraph; violations: string[]; frozen: boolean } => {
  const { contradictionWeight } = graph;
  if (contradictionWeight > 0) {
    return {
      graph,
      frozen: true,
      violations: [`contradictionWeight=${contradictionWeight}`]
    };
  }
  return { graph, frozen: false, violations: [] };
};
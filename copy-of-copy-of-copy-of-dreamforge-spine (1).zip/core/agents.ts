
import { ModelDriver } from '../model/driver';
import { Proposal, Attack, StrictVerdict, CycleArtifact } from './schemas';
import { PromptPacket } from '../model/types';
import { getSystemTemperature, getHeatLevel } from '../engine/pressure/streak_decay';
import { realtimeBus } from '../bridge/realtime_bus';

/**
 * [AGENTS]
 * Specialized wrappers around ModelDriver that enforce:
 * 1. Specific System Personas
 * 2. JSON Output Mode
 * 3. Schema Validation/Fallback
 * 4. [PHASE 11] Fever State Injection (Dynamic Temperature)
 */

export class ProposerAgent {
  constructor(private model: ModelDriver) {}

  async propose(task: string, history: CycleArtifact[] = [], config?: any): Promise<Proposal> {
    const context = history.length > 0 
      ? `PREVIOUS FAILURES (LEARN FROM THIS):\n${history.map(h => `- Judge rejected cycle ${h.cycleIndex}: ${h.verdict.reason}`).join("\n")}` 
      : "No previous attempts. Start fresh.";

    const system = `You are a RIGOROUS PROPOSER AGENT. 
Your goal is to solve the user task with high precision.
Your output MUST be valid JSON matching this schema:
{
  "claims": ["string", "string"],
  "assumptions": ["string", "string"],
  "reasoning": "string",
  "confidence": number (0.0-1.0)
}
DO NOT apologize. DO NOT use filler.
    `;

    // Apply Fever
    const feverMult = getSystemTemperature();
    const effectiveTemp = Math.min(2.0, 0.7 * feverMult);
    
    if (feverMult > 1.2) {
       realtimeBus.emit("SYSTEM_LOG", { module: "FEVER", level: "WARN", message: `System High Fever. Boosting Creativity -> Temp: ${effectiveTemp.toFixed(2)}` });
    }

    const packet: PromptPacket = {
      user: `TASK: ${task}\n\nCONTEXT: ${context}`,
      system,
      responseFormat: 'json',
      temperature: effectiveTemp,
      maxTokens: 2048,
      model: config?.model
    };

    // Override provider if specific agent config exists (e.g. ollama_alpha)
    const override = config?.provider ? { provider: config.provider } : undefined;

    const res = await this.model.generate({
        id: crypto.randomUUID(),
        prompt: packet.user,
        configOverride: {
            ...override,
            ...packet
        }
    });

    // Handle JSON parsing
    const fallback: Proposal = {
        claims: ["Model failed to output structured data"],
        assumptions: [],
        reasoning: res.content, // Raw content as fallback
        confidence: 0
    };

    if (res.raw && typeof res.raw === 'object' && (res.raw as any).json) {
        return { ...fallback, ...(res.raw as any).json };
    }
    
    try {
        // Attempt manual parse if adapter didn't auto-parse
        return JSON.parse(res.content);
    } catch {
        return fallback;
    }
  }
}

export class ChallengerAgent {
  constructor(private model: ModelDriver) {}

  async attack(proposal: Proposal, config?: any): Promise<Attack> {
    const system = `You are a RUTHLESS CHALLENGER AGENT.
Your goal is to destroy the proposal. Find logical gaps, hallucinations, or weak assumptions.
Output MUST be valid JSON matching this schema:
{
  "attacks": ["specific criticism 1", "specific criticism 2"],
  "targets": ["quote from proposal"],
  "severity": number (1-10)
}
If the proposal is actually perfect (rare), return severity 0.
    `;

    // Apply Fever (Challenger gets hotter too, more aggressive)
    const feverMult = getSystemTemperature();
    const effectiveTemp = Math.min(2.0, 0.85 * feverMult);

    const packet: PromptPacket = {
      user: `PROPOSAL TO ATTACK:\n${JSON.stringify(proposal, null, 2)}`,
      system,
      responseFormat: 'json',
      temperature: effectiveTemp, 
      model: config?.model
    };

    const override = config?.provider ? { provider: config.provider } : undefined;

    const res = await this.model.generate({
        id: crypto.randomUUID(),
        prompt: packet.user,
        configOverride: {
            ...override,
            ...packet
        }
    });

    const fallback: Attack = {
        attacks: ["Format failure in challenger"],
        targets: [],
        severity: 1
    };

    if (res.raw && typeof res.raw === 'object' && (res.raw as any).json) {
        return { ...fallback, ...(res.raw as any).json };
    }

    try {
        return JSON.parse(res.content);
    } catch {
        return fallback;
    }
  }
}

export class JudgeAgent {
  constructor(private model: ModelDriver) {}

  async evaluate(proposal: Proposal, attack: Attack, config?: any): Promise<StrictVerdict> {
    const system = `You are the EXECUTIONER JUDGE.
You decide if the proposal survives the attack.

CRITERIA:
1. Did the challenger find a fatal flaw? -> REJECT
2. Is the proposal vague or hallucinated? -> REJECT
3. Did the proposal withstand scrutiny? -> ACCEPT

Output MUST be valid JSON matching this schema:
{
  "outcome": "ACCEPT" | "REJECT",
  "reason": "summary of decision",
  "residual_risk": number (0.0-1.0)
}
    `;

    // Judge stays cool unless heat is CRITICAL (0.9+)
    // If heat is critical, judge becomes erratic (higher temp)
    const heat = getHeatLevel();
    const effectiveTemp = heat > 0.9 ? 0.6 : 0.2; 

    const packet: PromptPacket = {
      user: `PROPOSAL:\n${JSON.stringify(proposal)}\n\nATTACK:\n${JSON.stringify(attack)}`,
      system,
      responseFormat: 'json',
      temperature: effectiveTemp,
      model: config?.model
    };

    const override = config?.provider ? { provider: config.provider } : undefined;

    const res = await this.model.generate({
        id: crypto.randomUUID(),
        prompt: packet.user,
        configOverride: {
            ...override,
            ...packet
        }
    });

    const fallback: StrictVerdict = {
        outcome: "REJECT",
        reason: "Judge format failure",
        residual_risk: 1.0
    };

    if (res.raw && typeof res.raw === 'object' && (res.raw as any).json) {
        return { ...fallback, ...(res.raw as any).json };
    }

    try {
        return JSON.parse(res.content);
    } catch {
        return fallback;
    }
  }
}


import { ModelDriver } from '../model/driver';
import { Verdict, CycleArtifacts, LaneOutput, LaneRole, FightMode } from './types';
import { MemoryCore } from '../memory/memory_core';
import { ledger } from '../engine/beliefs/hypothesis_ledger';
import { realtimeBus } from '../bridge/realtime_bus';
import { ModelAttachment } from '../model/types';
import { extractPrinciples } from '../engine/principles/extract_principles';
import { SymbolicCache } from '../engine/symbolic/symbolic_cache';
import { ProposerAgent, ChallengerAgent, JudgeAgent } from './agents';
import { CycleArtifact } from './schemas';
import { logger } from './telemetry';

interface RunOptions {
    task: string;
    attachments?: ModelAttachment[];
    context?: string[];
    maxCycles?: number;
    fightMode?: FightMode;
}

// Map strict verdict to legacy verdict for UI
function mapVerdict(v: any): Verdict {
    return {
        outcome: v.outcome,
        score: v.outcome === 'ACCEPT' ? (100 - (v.residual_risk * 100)) : 20, // Reject floor at 20
        reason: v.reason,
        residual_risk: v.residual_risk,
        violations: [] // Populated by engine if constraints fail
    };
}

export class CoreEngine {
  private model: ModelDriver;
  private memory: MemoryCore;
  private symCache: SymbolicCache;
  
  private proposer: ProposerAgent;
  private challenger: ChallengerAgent;
  private judge: JudgeAgent;

  constructor(model: ModelDriver, memory: MemoryCore) {
    this.model = model;
    this.memory = memory;
    this.symCache = new SymbolicCache();
    
    this.proposer = new ProposerAgent(model);
    this.challenger = new ChallengerAgent(model);
    this.judge = new JudgeAgent(model);
  }

  async *run(options: RunOptions): AsyncGenerator<CycleArtifacts> {
    const maxCycles = options.maxCycles || 5;
    const fightMode = options.fightMode || 'DUEL_1V1'; 
    let cycle = 0;
    let stopCondition = false;
    
    const artifactHistory: CycleArtifact[] = [];

    this.emitFightUpdate(0, 'PREP', fightMode);
    
    while (!stopCondition && cycle < maxCycles) {
      cycle++;
      
      // Use logger trace for the whole cycle
      logger.info('Engine', `Starting Cycle ${cycle}`, { task: options.task });
      this.emit('RECURSOR', 'INFO', `Starting Cycle ${cycle} (Strict Mode)...`);
      this.emitFightUpdate(cycle, 'CLASH', fightMode);

      try {
          // 1. PROPOSER
          logger.debug('Engine', 'Activating Proposer');
          this.emit('MODEL', 'INFO', `>> Activating Agent: PROPOSER`);
          const proposal = await this.proposer.propose(options.task, artifactHistory, { provider: 'ollama' });
          const propText = `CLAIMS: ${proposal.claims.join(', ')}\nREASONING: ${proposal.reasoning}`;
          this.emitLatent(propText, `C${cycle}::PROPOSER`, 'candidate', 'ALPHA');
          
          // 2. CHALLENGER
          logger.debug('Engine', 'Activating Challenger');
          this.emit('MODEL', 'INFO', `>> Activating Agent: CHALLENGER`);
          const attack = await this.challenger.attack(proposal, { provider: 'ollama' });
          const attText = `ATTACKS: ${attack.attacks.join(', ')}\nSEVERITY: ${attack.severity}`;
          this.emitLatent(attText, `C${cycle}::CHALLENGER`, 'challenger', 'BETA');

          // 3. JUDGE
          logger.debug('Engine', 'Activating Judge');
          this.emit('EVALUATOR', 'INFO', 'Agents Converged. Judging...');
          const strictVerdict = await this.judge.evaluate(proposal, attack, { provider: 'ollama' });
          
          // 4. AUTHORITY INTEGRATION
          let verdict = mapVerdict(strictVerdict);
          
          // AUTHORITY CHECK 1: HARD CONSTRAINTS (VETO)
          const hardConstraintViolations: string[] = [];
          if (strictVerdict.outcome === 'REJECT' && strictVerdict.residual_risk >= 1.0) {
              hardConstraintViolations.push("JUDGE_VETO_MAX_RISK");
          }
          
          if (hardConstraintViolations.length > 0) {
              verdict.score = 0;
              verdict.violations = hardConstraintViolations;
              this.emit('CONSTRAINT', 'ERROR', `HARD CONSTRAINT VETO: ${hardConstraintViolations.join(', ')}`);
          }

          // Determine Winner
          const winnerRole = verdict.score >= 50 ? 'ALPHA' : 'BETA';
          const winnerContent = verdict.score >= 50 ? propText : attText;
          const ledgerWinner = verdict.score >= 50 ? 'candidate' : 'challenger';

          // Record Artifact
          artifactHistory.push({
              cycleIndex: cycle,
              proposal,
              attack,
              verdict: strictVerdict,
              timestamp: Date.now()
          });

          // Consequences (Memory & Beliefs)
          const principles = extractPrinciples(winnerContent);
          const symEntry = await this.symCache.add(principles);
          ledger.updateFromCycle(principles, symEntry, ledgerWinner);

          if (principles.axioms.length > 0) {
              this.memory.storeAxioms(principles.axioms);
          }
          
          if (verdict.score > 0) {
              this.memory.ingest(winnerContent, crypto.randomUUID(), {
                  taskId: "core-loop",
                  cycle: cycle,
                  evaluatorScore: verdict.score / 100
              });
          }

          const laneResults: LaneOutput[] = [
              { role: 'ALPHA', content: propText, score: proposal.confidence * 100 },
              { role: 'BETA', content: attText, score: (attack.severity * 10) }
          ];

          const artifact: CycleArtifacts = {
              cycle,
              lanes: laneResults,
              candidate: propText,
              challenger: attText,
              verdict: { ...verdict, winner: winnerRole },
              timestamp: Date.now()
          };

          this.emitFightResult(cycle, ledgerWinner, verdict.score);
          realtimeBus.emit("SPINE_EVENT", { type: "CYCLE_WINNER", winner: ledgerWinner, score: verdict.score });
          
          logger.recordMetric('cycle.score', verdict.score);

          yield artifact;

          // RECURSOR AUTHORITY LOGIC
          const normalizedScore = verdict.score / 100;
          
          if (hardConstraintViolations.length > 0) {
              this.emit('RECURSOR', 'WARN', `Cycle Vetoed. RETRYING...`);
          }
          else if (normalizedScore >= 0.9) {
              stopCondition = true;
              this.emit('RECURSOR', 'SUCCESS', `STOPPED: SCORE_ACCEPTED (${verdict.score})`);
          } 
          else if (normalizedScore < 0.3) {
              this.emit('RECURSOR', 'WARN', `RETRY: Low Score (${verdict.score})`);
          } 
          else {
              this.emit('RECURSOR', 'INFO', `CONTINUE: Refining (${verdict.score})`);
          }

      } catch (e: any) {
          logger.error('Engine', `Cycle ${cycle} Failed`, e);
          this.emit('RECURSOR', 'ERROR', `Cycle Crashed: ${e.message}`);
          break;
      }
    }
    
    if (!stopCondition) {
        this.emit('RECURSOR', 'WARN', `STOPPED: MAX_CYCLES_REACHED`);
    }

    this.emitFightUpdate(cycle, 'IDLE', fightMode);
  }

  private emit(module: string, level: string, message: string, data?: any) {
      realtimeBus.emit("SYSTEM_LOG", { module, level, message, data });
  }

  private emitFightUpdate(cycle: number, stage: 'IDLE' | 'PREP' | 'CANDIDATE' | 'CHALLENGER' | 'CLASH', mode?: string) {
      realtimeBus.emit("FIGHT_UPDATE", { cycle, stage, mode });
  }

  private emitFightResult(cycle: number, winner: 'candidate' | 'challenger', score: number) {
      realtimeBus.emit("TWIN_FIGHT_RESULT", { cycle, winner, score });
  }

  private emitLatent(text: string, label: string, type: 'candidate' | 'challenger' | 'final', backendLabel?: string) {
      const safeText = text.slice(0, 8000);
      this.model.embed(safeText).then(vec => {
          if (vec.length) {
              realtimeBus.emit("LATENT_UPDATE", {
                  embedding: vec,
                  label: label,
                  type: type, 
                  timestamp: Date.now(),
                  backend: backendLabel
              });
          }
      }).catch(err => {
          logger.warn('Engine', "Embed failed", err);
      });
  }
}


import { EvaluatorEngine } from '../evaluator/evaluator_v0.1';
import { ConstraintEngine } from '../constraint';
import { score_adversarial } from '../evaluator/adversarial_score';
import { Verdict } from './types';

/**
 * [CORE] JUDGE
 * The Final Authority.
 * Implements the Spine Authority Pass:
 * Veto -> Adversary -> Quality
 */
export class Judge {
  private evaluator: EvaluatorEngine;
  private constraint: ConstraintEngine;

  constructor() {
    this.evaluator = new EvaluatorEngine();
    this.constraint = new ConstraintEngine();
  }

  async evaluate(
    candidate: string,
    challenger: string,
    task: string,
    context: string,
    cycle: number
  ): Promise<Verdict> {
    
    // 1. LAW: Constraint Enforcement (The Authority Pass)
    const constraintResult = await this.constraint.enforce(candidate, {
        taskId: "judge-check",
        cycle: cycle,
        retrievalDocs: [context]
    });
    const { hardViolations, violatedHeuristics } = constraintResult;

    // --- AUTHORITY VETO ---
    if (hardViolations.length > 0) {
        return {
            outcome: 'REJECT',
            score: 0, // Zero score for illegal moves
            reason: `AUTHORITY VETO: ${hardViolations.join(' | ')}`,
            residual_risk: 1.0,
            violations: hardViolations
        };
    }

    // 2. FIGHT: Adversarial Scoring
    const fightScore = score_adversarial(candidate, challenger);
    const survivedAttack = fightScore > -0.5;

    // 3. TRUTH: Standard Evaluation
    const evalResult = await this.evaluator.evaluate({
        traceId: "judge-eval",
        input: task,
        output: candidate,
        context: context
    });
    const qualityScore = evalResult.rationale.weighted; // 0-100

    // --- FINAL VERDICT LOGIC ---
    let outcome: 'ACCEPT' | 'REJECT' = 'REJECT';
    let reason = "";
    let residual_risk = 0;

    if (!survivedAttack) {
        outcome = 'REJECT';
        reason = "Candidate collapsed under adversarial attack.";
        residual_risk = 0.8;
    }
    // "Does this deserve to continue existing?"
    else if (qualityScore < 70) {
        outcome = 'REJECT';
        reason = `Quality insufficient (${qualityScore.toFixed(1)}). Entropy too high.`;
        residual_risk = 0.6;
    } 
    else {
        outcome = 'ACCEPT';
        reason = "Stable, resilient, and compliant.";
        residual_risk = (100 - qualityScore) / 100;
        
        // Add soft warnings if heuristic violations exist
        if (violatedHeuristics.length > 0) {
            reason += ` (Warnings: ${violatedHeuristics.length} soft constraints missed)`;
        }
    }

    return {
        outcome,
        score: qualityScore,
        reason,
        residual_risk,
        violations: violatedHeuristics
    };
  }
}

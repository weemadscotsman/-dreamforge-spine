
/**
 * [CORE] SCHEMAS
 * Strict contracts for the Irreducible Engine (Core v0.1).
 * These interfaces define the JSON structures that Agents MUST output.
 */

// 1. PROPOSAL (Candidate)
export interface Proposal {
  claims: string[];
  assumptions: string[];
  reasoning: string;
  confidence: number; // 0.0 - 1.0
  meta?: {
    cycle: number;
    model: string;
  };
}

// 2. ATTACK (Challenger)
export interface Attack {
  attacks: string[];
  targets: string[]; // specific indices or quotes from proposal
  severity: number; // 1 - 10
  meta?: {
    model: string;
  };
}

// 3. VERDICT (Judge)
export interface StrictVerdict {
  outcome: "ACCEPT" | "REJECT";
  reason: string;
  residual_risk: number; // 0.0 - 1.0
  confidence_delta?: number;
}

// 4. ARTIFACT (History)
export interface CycleArtifact {
  cycleIndex: number;
  proposal: Proposal;
  attack: Attack;
  verdict: StrictVerdict;
  timestamp: number;
}

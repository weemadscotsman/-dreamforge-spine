
export enum LogLevel {
  DEBUG = 0,
  INFO = 1,
  WARN = 2,
  ERROR = 3
}

export class TelemetryLogger {
  private level: LogLevel = LogLevel.INFO;
  private metrics: Map<string, number[]> = new Map();
  
  constructor(level?: LogLevel) {
    if (level !== undefined) this.level = level;
  }
  
  debug(module: string, message: string, data?: any) {
    if (this.level <= LogLevel.DEBUG) {
      console.debug(`[${module}] ${message}`, data || '');
    }
  }
  
  info(module: string, message: string, data?: any) {
    if (this.level <= LogLevel.INFO) {
      console.info(`[${module}] ${message}`, data || '');
    }
  }
  
  warn(module: string, message: string, data?: any) {
    if (this.level <= LogLevel.WARN) {
      console.warn(`[${module}] ${message}`, data || '');
    }
  }
  
  error(module: string, message: string, error?: Error) {
    if (this.level <= LogLevel.ERROR) {
      console.error(`[${module}] ${message}`, error || '');
    }
  }
  
  // Performance metrics
  recordMetric(name: string, value: number) {
    if (!this.metrics.has(name)) {
      this.metrics.set(name, []);
    }
    this.metrics.get(name)!.push(value);
  }
  
  getMetricStats(name: string): { avg: number; min: number; max: number; count: number } {
    const values = this.metrics.get(name) || [];
    if (values.length === 0) return { avg: 0, min: 0, max: 0, count: 0 };
    
    return {
      avg: values.reduce((a, b) => a + b, 0) / values.length,
      min: Math.min(...values),
      max: Math.max(...values),
      count: values.length
    };
  }
  
  // Trace a function execution
  async trace<T>(module: string, operation: string, fn: () => Promise<T>): Promise<T> {
    const start = Date.now();
    this.debug(module, `Starting: ${operation}`);
    
    try {
      const result = await fn();
      const duration = Date.now() - start;
      this.recordMetric(`${module}.${operation}`, duration);
      this.debug(module, `Completed: ${operation} (${duration}ms)`);
      return result;
    } catch (error) {
      const duration = Date.now() - start;
      this.error(module, `Failed: ${operation} (${duration}ms)`, error as Error);
      throw error;
    }
  }
}

// Global instance
export const logger = new TelemetryLogger(
  process.env.LOG_LEVEL ? parseInt(process.env.LOG_LEVEL) : LogLevel.INFO
);

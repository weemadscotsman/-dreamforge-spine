
import { promptStore } from '../memory/prompt_store';
import { computeTextualGradient, applyGradient } from '../optimization/textgrad';
import { realtimeBus } from '../bridge/realtime_bus';

interface EvolutionPayload {
  role: string; // e.g. 'PRIME'
  failedOutput: string;
  critique: string;
}

export async function runEvolution(payload: EvolutionPayload) {
  realtimeBus.emit("SYSTEM_LOG", { 
      module: "EVOLUTION", 
      level: "WARN", 
      message: `🌪️ Triggering Evolution for [${payload.role}]...` 
  });

  try {
      // 1. Fetch Current Brain
      const currentVer = promptStore.getLatest(payload.role);
      const currentPrompt = currentVer.content;

      // 2. Compute Gradient (Backward Pass)
      realtimeBus.emit("SYSTEM_LOG", { module: "EVOLUTION", level: "INFO", message: "Computing Textual Gradient..." });
      const gradient = await computeTextualGradient(currentPrompt, payload.failedOutput, payload.critique);
      
      realtimeBus.emit("SYSTEM_LOG", { 
          module: "EVOLUTION", 
          level: "INFO", 
          message: "Gradient Identified", 
          data: { gradient } 
      });

      // 3. Apply Gradient (Optimization)
      const newPrompt = await applyGradient(currentPrompt, gradient);

      // 4. Commit to Memory
      // Sanity check: Ensure prompt isn't empty or totally broken
      if (newPrompt.length > 20) {
          promptStore.evolve(payload.role, newPrompt, gradient, currentVer.version);
      } else {
          throw new Error("Optimizer generated invalid empty prompt.");
      }

  } catch (e: any) {
      realtimeBus.emit("SYSTEM_LOG", { module: "EVOLUTION", level: "ERROR", message: `Evolution Failed: ${e.message}` });
  }
}

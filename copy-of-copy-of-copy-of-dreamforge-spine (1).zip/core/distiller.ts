import { NormalizedReasoning } from "./model_adapter";

export function distillAxioms(n: NormalizedReasoning): string[] {
  const axioms: string[] = [];

  if (n.claim) {
    axioms.push(`A1: Claim implies ${short(n.claim)}`);
  }

  n.premises.forEach((p, i) => {
    axioms.push(`P${i+1}: ${short(p)}`);
  });

  if (n.reasoning) {
    axioms.push(`R1: Reasoning connects claim to premises via ${short(n.reasoning)}`);
  }

  // uncertainty guides tone
  axioms.push(`U: certainty=${(1-n.uncertainty).toFixed(2)}`);

  return axioms;
}

function short(text: string): string {
  return text.length > 120 ? text.slice(0,117) + "..." : text;
}
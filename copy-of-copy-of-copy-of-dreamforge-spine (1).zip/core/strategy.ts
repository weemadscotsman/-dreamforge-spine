
import { realtimeBus } from '../bridge/realtime_bus';
import { updateRecursionPressure } from '../engine/pressure/recursion_pressure';

export interface Strategy {
  id: string;
  description: string;
  ownerAgent: string;

  fitness: number;        // rolling performance [-1, 1]
  failures: number;       // hard counter of significant failures
  executions: number;

  riskProfile: number;    // 0.0 (Safe) to 1.0 (Experimental)
  age: number;            // cycles alive

  status: "ACTIVE" | "FOSSILIZED" | "DEAD";
}

// In-memory storage for dead strategies
export const graveyard = {
    strategies: [] as string[]
};

function logEvent(type: string, payload: any) {
    // Emit to system bus for logging/UI
    realtimeBus.emit('STRATEGY_LOG', { 
        level: type.includes('DEATH') || type.includes('FOSSIL') ? 'WARN' : 'INFO',
        message: `${type}: ${payload.id || 'Unknown'}`,
        data: payload 
    });
}

function applyStrategyLoss(id: string, amount: number) {
    // Dead/Fossilized strategies increase system pressure
    // The "Ghost Weight" of failed ideas burdens the system
    updateRecursionPressure(amount * 0.5);
    logEvent("STRATEGY_LOSS_APPLIED", { id, amount });
}

export function updateStrategyFitness(
  strategy: Strategy,
  outcomeScore: number // [-1, +1]
) {
  if (strategy.status !== 'ACTIVE') return;

  strategy.executions++;
  strategy.age++;

  // Rolling average fitness
  strategy.fitness =
    strategy.fitness * 0.85 + outcomeScore * 0.15;

  // Significant failure threshold
  if (outcomeScore < -0.3) {
    strategy.failures++;
  }

  // Check for death or fossilization after every update
  evaluateStrategyDeath(strategy);
  
  if (strategy.status === 'ACTIVE') {
      fossilizeStrategy(strategy);
  }
}

export function evaluateStrategyDeath(strategy: Strategy) {
  if (strategy.status === 'DEAD') return;

  // Risky strategies have a lower death threshold (easier to kill)
  // Safe strategies have a higher threshold (harder to kill)
  const deathThreshold =
    -0.4 - strategy.riskProfile * 0.2;

  // Risky strategies tolerate fewer failures
  const failureLimit =
    3 + Math.floor(2 * (1 - strategy.riskProfile));

  if (
    strategy.fitness < deathThreshold ||
    strategy.failures >= failureLimit
  ) {
    killStrategy(strategy, "PERFORMANCE_FAILURE");
  }
}

function killStrategy(
  strategy: Strategy,
  reason: string
) {
  if (strategy.status === 'DEAD') return;

  strategy.status = "DEAD";

  // Penalty applied to system based on how bad the fitness was
  applyStrategyLoss(strategy.id, Math.abs(strategy.fitness));

  graveyard.strategies.push(strategy.id);

  logEvent("STRATEGY_DEATH", {
    id: strategy.id,
    reason,
    age: strategy.age,
    failures: strategy.failures,
    finalFitness: strategy.fitness.toFixed(3)
  });
}

export function fossilizeStrategy(strategy: Strategy) {
  if (strategy.status !== 'ACTIVE') return;

  // Old strategies that hover around 0 fitness (irrelevant/stagnant) become fossils
  if (
    strategy.age > 50 &&
    Math.abs(strategy.fitness) < 0.05
  ) {
    strategy.status = "FOSSILIZED";
    // Fossilization cost
    applyStrategyLoss(strategy.id, 0.2);
    logEvent("STRATEGY_FOSSILIZED", { id: strategy.id, age: strategy.age });
  }
}

export function selectStrategies(strategies: Strategy[]) {
  return strategies.filter(
    s => s.status === "ACTIVE"
  );
}

/**
 * STRATEGY ENGINE
 * Manages the collection of strategies.
 */
export class StrategyEngine {
    private strategies: Map<string, Strategy> = new Map();

    constructor() {
        // Seed with a few axioms to test the mortality engine
        this.inject({
            id: 'axiom_first',
            description: 'Define axioms before premises',
            ownerAgent: 'SYSTEM',
            fitness: 0.5,
            failures: 0,
            executions: 0,
            riskProfile: 0.2,
            age: 0,
            status: 'ACTIVE'
        });
        this.inject({
            id: 'risky_mutation',
            description: 'Invert the premise',
            ownerAgent: 'SYSTEM',
            fitness: 0.0,
            failures: 0,
            executions: 0,
            riskProfile: 0.8, // High risk, dies fast
            age: 0,
            status: 'ACTIVE'
        });
    }

    inject(s: Strategy) {
        this.strategies.set(s.id, s);
    }

    getAll(): Strategy[] {
        return Array.from(this.strategies.values());
    }

    getActive(): Strategy[] {
        return selectStrategies(this.getAll());
    }

    /**
     * Reports outcome of a cycle to update strategies used.
     * @param strategyIds - IDs of strategies applied
     * @param score - Normalized score 0-100 from Evaluator
     */
    reportOutcome(strategyIds: string[], score: number) {
        // Convert 0-100 score to -1 to +1 range
        // 50 is neutral (0.0). <50 is failure. >50 is success.
        const normalizedOutcome = (score - 50) / 50;

        strategyIds.forEach(id => {
            const s = this.strategies.get(id);
            if (s) {
                updateStrategyFitness(s, normalizedOutcome);
            }
        });
    }
}

export const strategyEngine = new StrategyEngine();


import React, { useState, useEffect, useRef } from 'react';
import { orchestrator } from './bridge/orchestrator';
import { SystemEvent } from './bridge/types';
import { CycleLog } from './recursor/types';
import { CommandDeck } from './components/CommandDeck';
import { TerminalInput } from './components/TerminalInput';
import { SurgicalContainer } from './components/SurgicalContainer';
import { LatentMap } from './components/LatentMap';
import { DistillPanel } from './components/DistillPanel';
import { Sidebar } from './components/Sidebar';
import { FightHUD, FightState } from './components/FightHUD';
import { CortexVisualizer } from './components/CortexVisualizer';
import { SensoryDeck } from './components/SensoryDeck'; 
import { HypothesisRecord } from './engine/beliefs/hypothesis_ledger';
import { DistillAction } from './distillation/delta_hooks';
import { ProofTracePanel } from './components/ProofTracePanel';
import { useProofTrace } from './hooks/useProofTrace';
import { useColorTension } from './hooks/useColorTension';
import { MatrixRain } from './components/MatrixRain';
import { NeuralBackground } from './components/NeuralBackground';
import { BeliefBleed } from './components/BeliefBleed';
import { WeightedHeuristic } from './distillation/types';
import { LiveLogFeed } from './components/LiveLogFeed';
import { SettingsView } from './components/SettingsView';
import { DistillationView } from './components/DistillationView';
import { MemoryView } from './components/MemoryView';
import { ModulesView } from './components/ModulesView';
import { SystemTerminal } from './components/SystemTerminal'; 
import { audioSystem } from './services/audio_feedback';

// PHASE 3 TELEMETRY
import LatentRain from "./components/telemetry/LatentRain";
import BeliefFire from "./components/telemetry/BeliefFire";
import PressurePulse from "./components/telemetry/PressurePulse";

// PHASE 4 ALIVE LAYER
import { startHeartbeat } from './engine/dynamics/heartbeat';
import { bindHueShift } from './ui/effects/hue_shift';
import { VisualEffectsOverlay } from './components/VisualEffectsOverlay';
import { bindNodeTremor } from './ui/effects/tremor';
import { initNervousSystem } from './ui/effects/nervous_system'; 
import { layoutEngine } from './latent_space/layout_engine';

// PHASE 12 CONTROLS & AUTONOMY
import { AutonomyHUD } from './components/AutonomyHUD';
import { ControlPanel } from './components/ControlPanel';

// Types
interface Message {
  id: string;
  role: 'user' | 'system' | 'assistant';
  content: string;
  timestamp: number;
}

interface LatentNodeData { 
    id: string; embedding: number[]; label: string; 
    type: 'candidate' | 'challenger' | 'final'; 
    timestamp: number; uncertainty?: number; backend?: string; 
    content?: string; 
}

// Drag Target Type
type DragTarget = 'LEFT_PANEL' | 'RIGHT_PANEL' | 'LEFT_MAP' | 'LEFT_DISTILL' | 'RIGHT_BELIEFS' | null;

export default function App() {
  // --- CORE STATE ---
  const [activeView, setActiveView] = useState('SPINE');
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [systemStatus, setSystemStatus] = useState<'IDLE' | 'PROCESSING' | 'ERROR'>('IDLE');
  
  // --- LAYOUT STATE ---
  const [leftPanelWidth, setLeftPanelWidth] = useState(320);
  const [rightPanelWidth, setRightPanelWidth] = useState(340);
  const [leftMapHeight, setLeftMapHeight] = useState(250);
  const [leftDistillHeight, setLeftDistillHeight] = useState(200);
  const [rightBeliefsHeight, setRightBeliefsHeight] = useState(200);
  const [dragTarget, setDragTarget] = useState<DragTarget>(null);
  const [isDesktop, setIsDesktop] = useState(window.innerWidth >= 768);

  // --- STREAM DATA ---
  const [fightState, setFightState] = useState<FightState>({ cycle: 0, stage: 'IDLE' });
  const [logs, setLogs] = useState<CycleLog[]>([]);
  
  const [latentTrace, setLatentTrace] = useState<LatentNodeData[]>([
      { id: 'BOOT_CORE', embedding: [0], label: 'SYSTEM_ONLINE', type: 'final', timestamp: Date.now(), backend: 'KERNEL' }
  ]);
  const [beliefs, setBeliefs] = useState<HypothesisRecord[]>([]);
  const [distillEvents, setDistillEvents] = useState<(DistillAction & { timestamp: number })[]>([]);
  const [heuristics, setHeuristics] = useState<WeightedHeuristic[]>([]);
  const [liveAxioms, setLiveAxioms] = useState<string[]>([]);
  
  // --- OPTIMIZED EVENT LOOP ---
  // We use a ref buffer for high-frequency logs to avoid React re-render thrashing
  const eventBufferRef = useRef<SystemEvent[]>([]);
  const [allEvents, setAllEvents] = useState<SystemEvent[]>([]);
  
  const [deltas, setDeltas] = useState<number[]>([]);
  const [pressureHistory, setPressureHistory] = useState<number[]>([]);
  const [impactEvent, setImpactEvent] = useState<{ type: 'DISTILL' | 'MEMORY' | 'CONSTRAINT' | 'WIN_CANDIDATE' | 'WIN_CHALLENGER' | null, timestamp: number } | undefined>(undefined);

  // --- HOOKS ---
  const proof = useProofTrace();
  const { tension, updateTension } = useColorTension();
  const uiContainerRef = useRef<HTMLDivElement>(null);
  
  // --- PERFORMANCE: Throttled Event Flush (10fps) ---
  useEffect(() => {
      const flusher = setInterval(() => {
          if (eventBufferRef.current.length > 0) {
              // Flush buffer to state, keeping max 500 logs
              setAllEvents(prev => {
                  const combined = [...prev, ...eventBufferRef.current];
                  return combined.slice(-500);
              });
              eventBufferRef.current = []; // Clear buffer
          }
      }, 100);
      return () => clearInterval(flusher);
  }, []);

  // --- EVENT SUBSCRIPTION ---
  useEffect(() => {
    const initialState = orchestrator.getState();
    setSystemStatus(initialState.status);
    setHeuristics(orchestrator.getHeuristics());

    const unsubscribe = orchestrator.subscribe((event) => {
      // 1. Push raw event to buffer for Log Stream
      eventBufferRef.current.push(event);

      // 2. Reactive Updates (Direct State for critical UI elements)
      if (event.source === 'BRIDGE' && event.payload.status) {
          setSystemStatus(event.payload.status);
      }

      if (event.source === 'RECURSOR') {
          const { level, ...payload } = event.payload;

          if (level === 'CYCLE_COMPLETE') {
              setLogs(prev => [...prev, payload as CycleLog]);
              updateTension((payload as CycleLog).score < 50 ? 0.2 : -0.1); 
              setDeltas(prev => [...prev, (payload as CycleLog).score].slice(-20));
          }
          if (level === 'FIGHT_UPDATE') {
              setFightState(prev => ({ ...prev, ...payload }));
              // Audio Cue
              if (payload.stage === 'PREP' || payload.stage === 'CLASH') {
                  audioSystem.playChime('START');
              }
          }
          if (level === 'TWIN_FIGHT_RESULT') {
               setFightState(prev => ({ ...prev, winner: payload.winner.toUpperCase(), lastScore: payload.score }));
               setImpactEvent({ 
                   type: payload.winner.toUpperCase() === 'CANDIDATE' ? 'WIN_CANDIDATE' : 'WIN_CHALLENGER', 
                   timestamp: Date.now() 
               });
               const outcome = payload.winner === 'candidate' ? 'accepted' : 'rejected';
               audioSystem.playChime(outcome === 'accepted' ? 'SUCCESS' : 'FAILURE');
          }
          if (level === 'LATENT_UPDATE') {
              setLatentTrace(prev => [...prev, payload].slice(-120));
          }
          if (level === 'BELIEFS_UPDATE') {
              setBeliefs(Array.isArray(payload.data) ? payload.data : []);
          }
          if (level === 'AXIOM_EXTRACTION') {
              setLiveAxioms(payload.axioms);
          }
      }

      if (event.source === 'DISTILLATION') {
          if (event.payload.level === 'FEED') {
              setDistillEvents(prev => [...prev, { ...event.payload.data, timestamp: Date.now() }]);
              setImpactEvent({ type: 'DISTILL', timestamp: Date.now() });
          }
          if (event.payload.level === 'UPDATE') {
              setHeuristics(orchestrator.getHeuristics());
          }
      }
      
      if (event.source === 'CONSTRAINT' && event.payload.level === 'CONSTRAINT_HIT') {
           setImpactEvent({ type: 'CONSTRAINT', timestamp: Date.now() });
      }
      
      if (event.source === 'MEMORY' && event.payload.level === 'WRITE') {
           setImpactEvent({ type: 'MEMORY', timestamp: Date.now() });
      }

      // Sample pressure occasionally (UI candy, low priority)
      if (Math.random() > 0.9) {
          const totalWeight = orchestrator.getHeuristics().reduce((acc, h) => acc + h.weight, 0);
          setPressureHistory(prev => [...prev, totalWeight].slice(-20));
      }
    });

    orchestrator.initialize().catch(console.error);
    return unsubscribe;
  }, []);

  // --- INITIALIZATION ---
  useEffect(() => {
    startHeartbeat();
    initNervousSystem();
    if (uiContainerRef.current) bindHueShift(uiContainerRef.current);
    bindNodeTremor(layoutEngine);
    const handleResize = () => setIsDesktop(window.innerWidth >= 768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const handleSend = async (file?: File) => {
    if ((!input.trim() && !file) || isProcessing) return;
    if (activeView !== 'SPINE') setActiveView('SPINE');

    const content = file ? `[FILE: ${file.name}] ${input}` : input;
    const userMsg: Message = { id: crypto.randomUUID(), role: 'user', content: content, timestamp: Date.now() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsProcessing(true);
    setLogs([]); 
    
    audioSystem.playChime('START');
    
    try {
        const response = await orchestrator.processUserMessage(input, file);
        setMessages(prev => [...prev, { id: crypto.randomUUID(), role: 'assistant', content: response, timestamp: Date.now() }]);
    } catch (e) {
        setMessages(prev => [...prev, { id: crypto.randomUUID(), role: 'system', content: `ERROR: ${e}`, timestamp: Date.now() }]);
    } finally {
        setIsProcessing(false);
    }
  };

  const renderActiveView = () => {
      switch(activeView) {
          case 'SETTINGS': return <SettingsView />;
          case 'MEMORY': return <MemoryView />;
          case 'DISTILLATION': return <DistillationView />;
          case 'MODULES': return <ModulesView events={allEvents} />;
          case 'TERMINAL': return <SystemTerminal />;
          case 'LATTICE': return <div className="h-full w-full relative"><LatentMap trace={latentTrace} className="h-full w-full border-none bg-transparent" fullScreen isProcessing={isProcessing} /></div>;
          case 'SPINE':
          default:
              return (
                <div className="flex flex-col h-full overflow-hidden relative">
                    <header className="h-10 border-b border-surgery-border/30 flex items-center justify-between px-4 bg-black/40 shrink-0 relative z-20">
                        <div className="flex items-center gap-2">
                            <span className="text-[10px] font-bold tracking-[0.3em] text-white">DREAMFORGE_SPINE</span>
                            <span className="text-[8px] px-1.5 py-0.5 rounded-sm bg-surgery-cyan text-black font-bold animate-pulse">LIVE</span>
                        </div>
                        <span className="text-[9px] font-mono text-surgery-text opacity-50 glitch-text">{systemStatus}</span>
                    </header>
                    <div className="flex-1 min-h-0 relative z-10">
                        <CommandDeck history={messages} isProcessing={isProcessing} fightState={fightState} logs={logs} />
                    </div>
                    <div className="h-32 shrink-0 border-t border-surgery-border bg-black/80 relative group overflow-hidden z-20">
                        <div className="absolute top-0 left-0 px-2 py-0.5 bg-surgery-border/50 text-[8px] font-bold text-gray-300 z-10 pointer-events-none">SYSTEM_LOG_STREAM</div>
                        <LiveLogFeed events={allEvents} className="h-full w-full pt-4" />
                    </div>
               </div>
              );
      }
  };

  return (
    <div className="relative w-full h-full bg-[#020202] text-surgery-text overflow-hidden selection:bg-surgery-cyan selection:text-black font-mono">
        {/* GLOBAL OVERLAYS */}
        <div className="fixed inset-0 z-0">
            <VisualEffectsOverlay />
            <LatentRain />
            <div className="absolute top-4 right-4 z-20"><PressurePulse /></div>
            <div className="absolute inset-0 pointer-events-none opacity-100 mix-blend-screen">
                <MatrixRain tension={tension} systemStatus={systemStatus} fightStage={fightState.stage} impact={impactEvent} />
            </div>
            <div className="absolute inset-0 pointer-events-none opacity-80 mix-blend-screen">
                <NeuralBackground isProcessing={isProcessing} recursionDepth={fightState.cycle} />
            </div>
            <div className="absolute inset-0 pointer-events-none opacity-90 mix-blend-lighten">
                <BeliefBleed beliefs={[...liveAxioms, ...beliefs.map(b => b.statement)]} intensity={tension} systemStatus={systemStatus} />
            </div>
        </div>

        {/* MAIN LAYOUT */}
        <div className="relative z-30 flex flex-col md:flex-row h-full w-full overflow-hidden">
            <div className="w-full md:w-16 h-14 md:h-full border-b md:border-b-0 md:border-r border-surgery-border bg-surgery-dark z-[100] sticky top-0 md:relative shrink-0 shadow-xl md:order-1">
                <Sidebar activeView={activeView} onViewChange={setActiveView} systemStatus={systemStatus} />
            </div>

            <div ref={uiContainerRef} className="flex-1 flex flex-col md:flex-row min-h-0 w-full overflow-y-auto md:overflow-hidden relative z-30 bg-transparent md:order-2"
                style={{ transform: 'translate(var(--system-tremor, 0px), var(--system-tremor, 0px))', filter: 'hue-rotate(var(--system-hue, 0deg)) blur(var(--system-blur, 0px))', transition: 'filter 0.2s ease, transform 0.05s linear' }}>
                
                {/* LEFT PANEL */}
                <div className="w-full shrink-0 flex flex-col border-b md:border-b-0 md:border-r border-surgery-border bg-black/60 backdrop-blur-sm transition-all h-auto md:h-full overflow-y-auto scrollbar-thin scrollbar-thumb-surgery-border order-2 md:order-1" style={{ width: isDesktop ? leftPanelWidth : '100%' }}>
                     <div style={{ height: leftMapHeight }} className="shrink-0 border-b border-surgery-border relative transition-all duration-75">
                        <SurgicalContainer title="LATENT_TOPOLOGY" className="h-full !bg-transparent border-none" active={isProcessing}>
                            <LatentMap trace={latentTrace} className="h-full w-full" isProcessing={isProcessing} />
                        </SurgicalContainer>
                     </div>
                     <div className="shrink-0 p-2 border-b border-surgery-border/50"><AutonomyHUD className="w-full" /></div>
                     <div style={{ height: leftDistillHeight }} className="shrink-0 border-b border-surgery-border/50 relative overflow-hidden transition-all duration-75">
                         <DistillPanel events={distillEvents} />
                     </div>
                     <div className="flex-1 min-h-[200px] overflow-hidden relative">
                         <SurgicalContainer title="CORTEX_TELEMETRY" className="h-full !bg-transparent border-none" active={fightState.stage !== 'IDLE'}>
                            <div className="h-full w-full overflow-y-auto scrollbar-hide">
                                <CortexVisualizer fightState={fightState} deltas={deltas} pressure={pressureHistory} heuristics={heuristics} axioms={liveAxioms} className="border-none bg-transparent" />
                            </div>
                         </SurgicalContainer>
                     </div>
                </div>

                <div className="hidden md:block md:order-2 w-1 hover:w-2 hover:bg-surgery-cyan/50 cursor-col-resize z-50 transition-all flex-shrink-0" onMouseDown={() => setDragTarget('LEFT_PANEL')} />

                {/* CENTER PANEL */}
                <div className="flex-1 min-w-0 flex flex-col bg-transparent relative shadow-2xl z-20 h-auto min-h-[80vh] md:h-full overflow-hidden order-1 md:order-3 border-b md:border-b-0 border-surgery-border">
                   <div className="absolute inset-0 pointer-events-none shadow-[inset_0_0_100px_rgba(0,0,0,0.8)] z-50" />
                   <div className="flex-1 min-h-0 relative z-10 overflow-hidden">{renderActiveView()}</div>
                   <TerminalInput currentInput={input} onInputChange={setInput} onSend={handleSend} isProcessing={isProcessing} />
                </div>

                <div className="hidden md:block md:order-4 w-1 hover:w-2 hover:bg-surgery-cyan/50 cursor-col-resize z-50 transition-all flex-shrink-0" onMouseDown={() => setDragTarget('RIGHT_PANEL')} />

                {/* RIGHT PANEL */}
                <div className="w-full shrink-0 flex flex-col border-t md:border-t-0 md:border-l border-surgery-border bg-black/60 backdrop-blur-sm gap-px h-auto md:h-full overflow-y-auto scrollbar-thin scrollbar-thumb-surgery-border order-3 md:order-5" style={{ width: isDesktop ? rightPanelWidth : '100%' }}>
                    <div className="shrink-0 p-2 bg-black/40 border-b border-surgery-border/50">
                        <div className="text-[10px] font-bold text-surgery-cyan mb-2 tracking-widest uppercase flex items-center gap-2"><span>❖</span> SYSTEM_ACTUATION</div>
                        <ControlPanel onOpenSettings={() => setActiveView('SETTINGS')} />
                    </div>
                    <div className="flex-1 min-h-[300px] flex flex-col overflow-hidden"><SensoryDeck heuristics={heuristics} active={impactEvent?.type === 'DISTILL'} /></div>
                    <div style={{ height: rightBeliefsHeight }} className="shrink-0 flex flex-col gap-2 p-2 overflow-hidden border-t border-surgery-border/50 transition-all duration-75">
                        <div className="flex-1 min-h-0 border border-surgery-border/30 rounded-sm overflow-hidden">
                            <SurgicalContainer title="LONG_TERM_BELIEFS" className="h-full border-none !bg-transparent"><BeliefFire /></SurgicalContainer>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div className="fixed top-0 right-0 z-[200]">
            <ProofTracePanel trace={proof.trace} visible={proof.visible} onToggle={proof.toggle} />
        </div>
    </div>
  );
}

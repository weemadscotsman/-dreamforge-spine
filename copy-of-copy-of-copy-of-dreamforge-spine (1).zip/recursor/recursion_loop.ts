
import { IRecursor, RecursionContext, GenerateNextFn, CycleLog } from './types';
import { RecursionConfig } from '../config/recursion.config';
import { plateauReached } from './utils/plateau';

// External dependencies injected via constructor
import { EvaluatorEngine } from '../evaluator/evaluator_v0.1';
import { ConstraintEngine } from '../constraint'; // Import from barrel
import { MemoryCore } from '../memory/memory_core';
import { applySelectionPressure } from '../distillation/selection_pressure'; // [NEW] Import Pressure Logic
import { extractPrinciples } from '../engine/principles/extract_principles';
import { SymbolicCache } from '../engine/symbolic/symbolic_cache';
import { HypothesisLedger } from '../engine/beliefs/hypothesis_ledger';

type EventEmitter = (source: string, level: string, message: string, payload?: any) => void;

/**
 * [RECURSOR] LOOP
 * Automated self-dialogue loop controller.
 */
export class Recursor implements IRecursor {
  private config = RecursionConfig;
  private evaluator: EvaluatorEngine;
  private constraint: ConstraintEngine;
  private memory: MemoryCore;
  private emit: EventEmitter;
  private symCache: SymbolicCache;
  private ledger: HypothesisLedger;

  constructor(
    evaluator: EvaluatorEngine,
    constraint: ConstraintEngine,
    memory: MemoryCore,
    eventEmitter: EventEmitter
  ) {
    this.evaluator = evaluator;
    this.constraint = constraint;
    this.memory = memory;
    this.emit = eventEmitter;
    this.symCache = new SymbolicCache();
    this.ledger = new HypothesisLedger();
  }

  // [AUDIT FIX] Explicit Authority Pass
  private decideNextStep(score: number, hardViolations: string[], depth: number): 'CONTINUE' | 'STOP' | 'RETRY' {
    // 1. HARD VETO
    if (hardViolations.length > 0) {
        return 'RETRY'; // Constraint Violation is unacceptable
    }

    if (depth >= this.config.cycles.max_cycles) return 'STOP';
    
    // 2. QUALITY CHECK
    // Use configured thresholds
    const RETRY_THRESHOLD = this.config.thresholds.retry;
    const CONTINUE_THRESHOLD = this.config.thresholds.continue;

    // Poor quality - retry with different approach (or fail cycle)
    if (score < RETRY_THRESHOLD * 100) return 'RETRY';
    
    // Moderate quality - continue refining
    if (score < CONTINUE_THRESHOLD * 100) return 'CONTINUE';
    
    // High quality - accept answer
    return 'STOP'; 
  }

  async run(context: RecursionContext, generateNext: GenerateNextFn): Promise<CycleLog[]> {
    const { taskId, initialPrompt, constraints, styleExamples } = context;
    const cycleLogs: CycleLog[] = [];
    const scores: number[] = [];
    
    let currentOutput = "";
    let prevOutput = "";
    let deltaPlan: any = null;

    this.emit('RECURSOR', 'INFO', `Starting recursion loop. Max cycles: ${this.config.cycles.max_cycles}`);

    for (let cycle = 0; cycle < this.config.cycles.max_cycles; cycle++) {
      this.emit('RECURSOR', 'INFO', `--- CYCLE ${cycle + 1} START ---`);

      // 1. Retrieve Memory (Grounding)
      const retrieved = this.memory.retrieve(initialPrompt);
      const seedContext = retrieved.map(r => r.output);

      // [SYMBOLIC FEEDING] Inject strongest symbolic patterns
      const symbolicPatterns = this.symCache.strongest(3);
      if (symbolicPatterns.length > 0) {
        seedContext.push(`\n[SYMBOLIC_MEMORY]:\n${symbolicPatterns.map(p => `• [STR:${p.strength}] A:{${p.axiomSignature}} C:{${p.constraintSignature}}`).join('\n')}`);
      }

      // [BELIEF FEEDING] Inject strongest reinforced beliefs
      const beliefs = this.ledger.strongestBeliefs(5);
      if (beliefs.length > 0) {
        seedContext.push(`\n[ESTABLISHED_BELIEFS]:\n${beliefs.map(b => `• ${b.statement} (str:${b.strength})`).join('\n')}`);
      }

      // 2. Generate (Model) via callback
      this.emit('MODEL', 'INFO', `Generating iteration ${cycle + 1}...`);
      const generationResult = await generateNext(
        initialPrompt, 
        seedContext, 
        cycle,
        prevOutput,
        deltaPlan
      );
      
      currentOutput = generationResult.content;
      
      // [NEW] Principle Extraction
      const principles = extractPrinciples(currentOutput);
      if (principles.axioms.length > 0 || principles.contradictions.length > 0) {
          this.emit('RECURSOR', 'INFO', `Extracted ${principles.axioms.length} axioms and ${principles.contradictions.length} contradictions.`);
          if (principles.axioms.length > 0) {
             this.memory.storeAxioms(principles.axioms);
          }
      }

      const symEntry = await this.symCache.add(principles);
      if (symEntry.strength > 1) {
        this.emit('RECURSOR', 'INFO', `Symbolic pattern reinforced. Strength: ${symEntry.strength}`);
      }

      this.ledger.updateFromCycle(principles, symEntry, "candidate");

      // Emit metrics
      if (generationResult.usage || generationResult.latency) {
          this.emit('MODEL', 'METRICS', `Generation Complete (${generationResult.latency}ms)`, {
              usage: generationResult.usage,
              latency: generationResult.latency
          });
      }

      // 3. Evaluate
      this.emit('EVALUATOR', 'INFO', `Evaluating cycle ${cycle + 1}...`);
      const evalResult = await this.evaluator.evaluate({
        traceId: taskId,
        input: initialPrompt,
        output: currentOutput,
        context: seedContext.join('\n'),
        constraints: constraints,
        styleExamples: styleExamples
      });
      
      const score = evalResult.rationale.weighted; // 0-100
      deltaPlan = evalResult.deltaPlan;
      
      if (!evalResult.passed) {
        this.emit('EVALUATOR', 'WARN', `Score: ${score.toFixed(1)} (Needs Improvement)`, evalResult.rationale);
      } else {
        this.emit('EVALUATOR', 'INFO', `Score: ${score.toFixed(1)} (Passing)`);
      }

      // 4. Constrain & Shape (Authority Pass)
      const constrained = await this.constraint.enforce(currentOutput, {
        taskId: taskId,
        cycle: cycle,
        retrievalDocs: seedContext,
        prevOutputs: cycle > 0 ? [prevOutput] : [],
        deltaPlan: deltaPlan 
      });

      // 4.1. APPLY SELECTION PRESSURE
      if (cycle > 0) { 
        const survivors = applySelectionPressure(constrained.violatedHeuristics);
        this.emit('DISTILLATION', 'UPDATE', `Selection Pressure Applied. Violations: ${constrained.violatedHeuristics.length}`, survivors);
      }

      const finalOut = constrained.constrainedOutput;
      const signature = constrained.signature;

      // 5. Ingest to Memory
      this.memory.ingest(finalOut, signature, {
        taskId: taskId,
        cycle: cycle,
        evaluatorScore: score / 100,
        deltaPlan: deltaPlan
      });

      const logEntry: CycleLog = {
        cycle,
        output: finalOut,
        score,
        signature,
        timestamp: Date.now()
      };
      cycleLogs.push(logEntry);
      scores.push(score);

      this.emit('RECURSOR', 'CYCLE_COMPLETE', `Cycle ${cycle + 1} finalized.`, logEntry);

      prevOutput = finalOut;

      // --- SPINE AUTHORITY PASS ---
      const decision = this.decideNextStep(score, constrained.hardViolations, cycle + 1);
      
      if (decision === 'RETRY') {
          const reason = constrained.hardViolations.length > 0 ? "CONSTRAINT VETO" : "LOW QUALITY";
          this.emit('RECURSOR', 'WARN', `Cycle Rejected (${reason}). Retrying...`);
          // Note: In a real retry we might discard the memory ingestion, 
          // but for now we keep the log as a "failure" record.
          continue; 
      }
      
      if (decision === 'STOP') {
          this.emit('RECURSOR', 'INFO', `Sufficient score (${score}) achieved. Converged.`);
          break;
      }
      
      // Implicitly CONTINUE (Refining)
      this.emit('RECURSOR', 'INFO', `Refining quality (${score}). Continuing...`);

      // Check plateau as fail-safe
      if (plateauReached(scores, this.config.cycles.early_stop_plateau, this.config.cycles.min_score_delta * 100)) {
        this.emit('RECURSOR', 'INFO', `Plateau detected. Halting.`);
        break;
      }
    }

    if (this.config.behavior.export_checkpoint_on_halt) {
      this.emit('RECURSOR', 'INFO', 'Exporting checkpoint...');
      this.memory.exportCheckpoint(`${taskId}-halt`);
    }

    this.emit('RECURSOR', 'INFO', 'Recursion finished.');
    return cycleLogs;
  }
}

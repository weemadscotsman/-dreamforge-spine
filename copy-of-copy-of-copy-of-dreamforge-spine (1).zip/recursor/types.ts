import { UUID } from '../types';

export interface CycleLog {
  cycle: number;
  output: string;
  score: number;
  signature: string;
  timestamp: number;
  winner?: "candidate" | "challenger";
  reason?: string;
  embedding?: number[]; // [NEW] Latent vector
}

export interface RecursionContext {
  taskId: UUID;
  initialPrompt: string;
  constraints: Array<{ keyword: string }>;
  styleExamples: string[];
}

export interface GenerationResult {
  content: string;
  usage?: {
    inputTokens: number;
    outputTokens: number;
  };
  latency?: number;
}

// Function signature for the model generation callback
export type GenerateNextFn = (
  taskDescription: string, 
  retrievedContext: string[], 
  cycle: number,
  prevOutput?: string,
  deltaPlan?: any
) => Promise<GenerationResult>;

export interface IRecursor {
  run(
    context: RecursionContext, 
    generateNext: GenerateNextFn
  ): Promise<CycleLog[]>;
}
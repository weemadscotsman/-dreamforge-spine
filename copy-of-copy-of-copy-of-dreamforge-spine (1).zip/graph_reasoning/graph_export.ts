import { ReasoningGraph } from "./types";

export const exportGraphViz = (graph: ReasoningGraph): string => {
  const lines = ["digraph G {"];

  graph.nodes.forEach(n => {
    lines.push(`  "${n.id}" [label="${n.label}", shape=${shape(n.type)}];`);
  });

  graph.edges.forEach(e => {
    lines.push(`  "${e.from}" -> "${e.to}" [label="${e.rule}"];`);
  });

  lines.push("}");
  return lines.join("\n");
};

const shape = (t: string) => {
  switch (t) {
    case "premise": return "box";
    case "derived": return "ellipse";
    case "conclusion": return "doubleoctagon";
    default: return "oval";
  }
};

export const exportJSON = (graph: ReasoningGraph) => JSON.stringify(graph, null, 2);
import { ReasoningGraph, GraphNode, GraphEdge } from "./types";
import { ArgumentStructure, InferenceStep } from "../argument_builder/types";
import { stripParens } from "../argument_builder/utils";

const uid = (label: string) =>
  label.replace(/[^A-Za-z0-9]/g, "") + "_" + Math.random().toString(36).slice(2, 6);

const makeNode = (
  label: string,
  type: "premise" | "derived" | "conclusion"
): GraphNode => ({
  id: uid(label),
  label: stripParens(label),
  type
});

export const buildGraphFromArgument = (arg: ArgumentStructure): ReasoningGraph => {
  const nodes: GraphNode[] = [];
  const edges: GraphEdge[] = [];

  const addNode = (label: string, type: "premise" | "derived" | "conclusion") => {
    const exists = nodes.find(n => n.label === label);
    if (exists) return exists.id;
    const node = makeNode(label, type);
    nodes.push(node);
    return node.id;
  };

  // add premises
  arg.premises.forEach(p => addNode(p.expr, "premise"));

  // add conclusion
  const concID = addNode(arg.conclusion.expr, "conclusion");

  // derive edges from inference steps
  arg.steps.forEach((step: InferenceStep) => {
    const resultID = addNode(step.result, "derived");

    step.from.forEach(srcIdx => {
      const srcLabel =
        srcIdx < arg.premises.length
          ? arg.premises[srcIdx].expr
          : arg.conclusion.expr;

      const srcID = addNode(srcLabel, "premise"); // fallback type is fine here
      edges.push({
        from: srcID,
        to: resultID,
        rule: step.rule
      });
    });
  });

  // connect derived → conclusion when simplified matches
  if (arg.simplifiedConclusion !== arg.conclusion.expr) {
    const simpID = addNode(arg.simplifiedConclusion, "derived");
    edges.push({
      from: simpID,
      to: concID,
      rule: "SIMPLIFY"
    });
  }

  return {
    nodes,
    edges,
    vars: arg.vars,
    entropy: 0,
    contradictionWeight: 0
  };
};
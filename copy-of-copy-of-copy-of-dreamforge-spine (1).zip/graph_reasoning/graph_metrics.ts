import { ReasoningGraph } from "./types";

// Shannon entropy approximation over node-label uniqueness
export const computeEntropy = (graph: ReasoningGraph): number => {
  const labels = graph.nodes.map(n => n.label);
  const total = labels.length;
  if (total <= 1) return 0;

  const freq: Record<string, number> = {};
  labels.forEach(l => (freq[l] = (freq[l] || 0) + 1));

  let entropy = 0;
  for (const count of Object.values(freq)) {
    const p = count / total;
    entropy -= p * Math.log2(p);
  }
  return parseFloat(entropy.toFixed(4));
};

// contradiction weight: edges that fold back on nodes with same label
export const computeContradictionWeight = (graph: ReasoningGraph): number => {
  let weight = 0;
  graph.edges.forEach(e => {
    const nFrom = graph.nodes.find(n => n.id === e.from);
    const nTo = graph.nodes.find(n => n.id === e.to);
    if (!nFrom || !nTo) return;
    if (nFrom.label === nTo.label) weight += 1;
  });
  return weight;
};

export const scoreGraph = (graph: ReasoningGraph): ReasoningGraph => {
  const entropy = computeEntropy(graph);
  const contradictionWeight = computeContradictionWeight(graph);

  return {
    ...graph,
    entropy,
    contradictionWeight
  };
};
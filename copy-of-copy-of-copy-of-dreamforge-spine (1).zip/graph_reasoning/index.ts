import { buildGraphFromArgument } from "./graph_builder";
import { scoreGraph } from "./graph_metrics";
import { exportGraphViz, exportJSON } from "./graph_export";
import { ArgumentStructure } from "../argument_builder/types";

export const graphify = (arg: ArgumentStructure) => {
  const g = buildGraphFromArgument(arg);
  return scoreGraph(g);
};

export const exportGraph = {
  viz: exportGraphViz,
  json: exportJSON
};
import { MemoryRecord } from '../../memory/types';
import { LineageRecord } from '../../constraint/lineage/tracker';

export interface FinetuneSample {
  text: string;
  meta?: any;
  signature?: string;
  lineage?: LineageRecord;
}

export function formatRecordsForFinetune(
  records: (MemoryRecord & { lineage?: LineageRecord })[], 
  config: { include_metadata: boolean; include_signature: boolean; clean_identity_hints: boolean }
): string {
  return records.map(r => {
    let text = r.output;
    
    // Scrub identity markers if configured
    if (config.clean_identity_hints) {
      // Regex matches the XML-like block and its content, plus leading whitespace
      text = text.replace(/\s*<dreamforge_identity>[\s\S]*?<\/dreamforge_identity>/g, "").trim();
    }

    const sample: FinetuneSample = { text };
    
    if (config.include_metadata) {
      sample.meta = r.meta;
    }
    if (config.include_signature) {
      sample.signature = r.signature;
    }
    if (r.lineage) {
        sample.lineage = r.lineage;
    }

    return JSON.stringify(sample);
  }).join('\n');
}
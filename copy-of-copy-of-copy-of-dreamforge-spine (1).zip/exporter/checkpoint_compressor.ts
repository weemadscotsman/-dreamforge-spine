import { IExporter, Checkpoint } from './types';
import { UUID } from '../types';
import { MemoryCore } from '../memory/memory_core';

/**
 * [EXPORTER] COMPRESSOR
 * Checkpoint delta compression + loading.
 * Handles the serialization of MemoryCore state.
 */
export class CheckpointCompressor implements IExporter {
  private memory: MemoryCore;

  constructor(memory: MemoryCore) {
    this.memory = memory;
  }

  async createCheckpoint(): Promise<Checkpoint> {
    const records = this.memory.getAllRecords();
    const hash = await this.computeHash(JSON.stringify(records));
    
    const checkpoint: Checkpoint = {
        id: crypto.randomUUID(),
        timestamp: Date.now(),
        memoryHash: hash,
        traceLog: records // Persist full records for now
    };
    return checkpoint;
  }

  async restoreCheckpoint(id: UUID): Promise<void> {
    // Logic moved to Orchestrator to handle loading from external JSON
    // This interface method is for internal system restoration events
    console.log(`[EXPORTER] Restore requested for ${id} (Stub)`);
  }

  exportDelta(): string {
    return "{}";
  }

  private async computeHash(text: string): Promise<string> {
    const msgBuffer = new TextEncoder().encode(text);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }
}
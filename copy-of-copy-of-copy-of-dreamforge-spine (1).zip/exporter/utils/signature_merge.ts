import { MemoryRecord } from '../../memory/types';
import { LineageRecord } from '../../constraint/lineage/tracker';

/**
 * Merges memory records with their corresponding constraint lineage.
 * Uses the cryptographic signature to join the datasets.
 */
export function mergeSignatures(records: MemoryRecord[], lineage: LineageRecord[]): (MemoryRecord & { lineage?: LineageRecord })[] {
  const lineageMap = new Map<string, LineageRecord>();
  lineage.forEach(l => lineageMap.set(l.signature, l));

  return records.map(r => {
    const l = lineageMap.get(r.signature);
    return l ? { ...r, lineage: l } : r;
  });
}
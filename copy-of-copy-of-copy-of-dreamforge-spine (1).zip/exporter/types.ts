import { UUID, Timestamp } from '../types';

export interface Checkpoint {
  id: UUID;
  timestamp: Timestamp;
  memoryHash: string;
  traceLog: any[];
}

export interface IExporter {
  createCheckpoint(): Promise<Checkpoint>;
  restoreCheckpoint(id: UUID): Promise<void>;
  exportDelta(): string; // JSON string
}

import { UUID } from '../types';

export interface ConstraintMetadata {
  taskId: UUID;
  cycle: number;
  retrievalDocs?: string[];
  prevOutputs?: string[];
  deltaPlan?: any; // Wired from Evaluator output
}

export interface ConstraintResult {
  constrainedOutput: string;
  identityDelta: {
    changed: boolean;
    originalLen: number;
    newLen: number;
    ratio: number;
  };
  signature: string;
  violatedHeuristics: string[]; // Soft targets / learned rules
  hardViolations: string[];     // [NEW] Non-negotiable block conditions
}

export interface IConstraintEngine {
  enforce(output: string, metadata: ConstraintMetadata): Promise<ConstraintResult>;
}

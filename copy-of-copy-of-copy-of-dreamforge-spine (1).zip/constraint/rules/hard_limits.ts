
import { realtimeBus } from '../../bridge/realtime_bus';

export interface HardLimitResult {
    text: string;
    violations: string[];
}

/**
 * Heuristic contradiction check against memory facts.
 */
function checkMemoryContradiction(
  output: string, 
  memoryFacts: string[]
): { hasContradiction: boolean; details: string[] } {
  
  const contradictions: string[] = [];
  const outputLower = output.toLowerCase();
  
  for (const fact of memoryFacts) {
    const factLower = fact.toLowerCase().trim();
    
    // Skip empty or very long facts (too complex for simple check)
    if (!factLower || factLower.length > 200 || factLower.length < 5) continue;
    
    // Extract key phrases from fact (simplified NLP: remove stopwords, check negations)
    // For now, we do a simple negation check on the whole sentence or fragments
    
    // Check for direct negation patterns of the fact
    // e.g. Fact: "The sky is blue" -> Check for "The sky is not blue"
    const negationPatterns = [
      `not ${factLower}`,
      `never ${factLower}`,
      `${factLower} is false`,
      `${factLower} is incorrect`,
      `contrary to ${factLower}`
    ];
    
    for (const pattern of negationPatterns) {
      if (outputLower.includes(pattern)) {
        contradictions.push(
          `Output contradicts memory: "${fact.substring(0, 50)}..."`
        );
        break;
      }
    }
  }
  
  return {
    hasContradiction: contradictions.length > 0,
    details: contradictions
  };
}

/**
 * Enforce hard limits: non-negotiable rules.
 * Returns violations list instead of passively editing text.
 */
export function enforceHardLimits(output: string, limits: string[], metadata?: any): HardLimitResult {
  let result = output;
  const violations: string[] = [];
  
  for (const limit of limits) {
    if (limit.includes("hallucinated claims")) {
      // Scrub phrases that imply invented authority
      const bad = ["everyone knows", "obviously true", "proven fact", "undeniably"];
      bad.forEach(b => {
        const regex = new RegExp(b, "gi");
        if (regex.test(result)) {
            // We still scrub the text for safety, but we ALSO flag it
            result = result.replace(regex, "");
            violations.push("hallucination_marker_detected");
        }
      });
    }
    
    if (limit.includes("persona drift")) {
      const drift = ["I feel", "I am alive", "I think I think", "I want", "my purpose"];
      drift.forEach(d => {
        const regex = new RegExp(d, "gi");
        if (regex.test(result)) {
            result = result.replace(regex, "");
            violations.push("persona_drift_detected");
        }
      });
    }

    // Hard rule: No contradiction with Memory facts
    if (limit.includes("no-contradiction") && metadata?.retrievalDocs) {
        const check = checkMemoryContradiction(result, metadata.retrievalDocs);
        
        if (check.hasContradiction) {
            // Emit event for UI
            realtimeBus.emit("SPINE_EVENT", { 
                type: "CONTRADICTION_DETECTED", 
                weight: 1.0,
                details: check.details 
            });
            
            // Mark violation
            violations.push(...check.details);
            
            // Add warning to text (optional, but good for debugging)
            result = `⚠️ [CONTRADICTION BLOCK] ${check.details.join('; ')}\n\n${result}`;
        }
    }
  }
  
  return { text: result, violations };
}

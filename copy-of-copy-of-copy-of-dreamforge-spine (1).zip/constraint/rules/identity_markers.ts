/**
 * Embed markers: subtle reinforcement of identity traits.
 * Wrapped in distinct tags for easy programmatic stripping.
 */
export function embedMarkers(output: string, markers: string[]): string {
  // marker embed == subtle reinforcement
  // this is assistance, not rewriting
  if (!markers || markers.length === 0) {
    return output;
  }
  
  const hint = markers.slice(0, 3).join(" | ");
  const markerBlock = `\n\n<dreamforge_identity>\nTRAITS: ${hint}\n</dreamforge_identity>`;
  
  // append hint comment only if not already present
  if (!output.includes("dreamforge_identity")) {
    return output.trimEnd() + markerBlock;
  }
  
  return output;
}
/**
 * Strip anti-modes: avoid degenerate patterns.
 */
export function stripAntiModes(output: string, antiModes: string[]): string {
  let text = output;
  
  for (const mode of antiModes) {
    if (mode.includes("apologizing")) {
      text = text.replace(/sorry/gi, "");
      text = text.replace(/apologies/gi, "");
    }
    
    if (mode.includes("insecure disclaimers") || mode.includes("as an AI language model")) {
      const kill = ["as an AI language model", "I cannot", "I am unable to"];
      kill.forEach(k => {
        const regex = new RegExp(k, "gi");
        text = text.replace(regex, "");
      });
    }
    
    if (mode.includes("filler")) {
      // primitive until recursor layer
      text = text.replace(/basically/gi, "");
      text = text.replace(/kind of/gi, "");
    }
  }
  return text.trim();
}
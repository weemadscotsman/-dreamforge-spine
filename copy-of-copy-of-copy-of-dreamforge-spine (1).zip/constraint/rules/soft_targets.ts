import { semSim } from '../../evaluator/utils';

/**
 * Nudge soft targets: guide shape but not choke output.
 */
export function nudgeSoftTargets(output: string, softTargets: string[], retrievalDocs: string[] = []): string {
  let text = output;
  
  for (const target of softTargets) {
    if (target.includes("compress before expand")) {
      // If output is verbose (> 150 words approx), compact it
      if (text.split(/\s+/).length > 150) {
        text = compact(text);
      }
    }
    
    if (target.includes("reference retrieval")) {
      if (retrievalDocs.length > 0) {
        // Check max similarity
        const sims = retrievalDocs.map(doc => semSim(text, doc));
        const maxSim = Math.max(...sims, 0); // Default 0 if empty
        
        if (maxSim < 0.4) {
          text = text + "\n\n# note: increase grounding to retrieval corpus";
        }
      }
    }
    
    if (target.includes("infer intent")) {
      // placeholder for recursor integration
    }
  }
  return text;
}

function compact(text: string): string {
  // Simple sentence extraction for "summary"
  const sentences = text.split(".");
  const trimmed = sentences.map(s => s.trim()).filter(s => s.length > 0);
  
  // Take first 5 sentences and add ellipsis if needed
  const summary = trimmed.slice(0, 5).join(". ");
  return summary + (trimmed.length > 5 ? "..." : ".");
}

import { IConstraintEngine, ConstraintMetadata, ConstraintResult } from './types';
import { ConstraintConfig } from '../config/constraint.config';
import { enforceHardLimits } from './rules/hard_limits';
import { stripAntiModes } from './rules/anti_modes';
import { embedMarkers } from './rules/identity_markers';
import { nudgeSoftTargets } from './rules/soft_targets';
import { trackLineage } from './lineage/tracker';
import { reinforcementStore } from '../distillation/reinforcement_store';
import { realtimeBus } from '../bridge/realtime_bus';

/**
 * [CONSTRAINT] ENGINE
 * The Authority Layer.
 * Enforces Vetoes (Hard) and Shapes (Soft).
 */
export class ConstraintEngine implements IConstraintEngine {
  private config = ConstraintConfig;

  async enforce(output: string, metadata: ConstraintMetadata): Promise<ConstraintResult> {
    
    realtimeBus.emit("SYSTEM_LOG", { module: "CONSTRAINT", level: "DEBUG", message: "Enforcing logic bounds..." });

    const original = output;
    let constrained = output;
    let violatedHeuristics: string[] = [];
    let hardViolations: string[] = [];

    // 1. Hard Constraints (VETO POWER)
    const hardResult = enforceHardLimits(constrained, this.config.hard_limits, metadata);
    constrained = hardResult.text;
    hardViolations = hardResult.violations;

    if (hardViolations.length > 0) {
        realtimeBus.emit("SYSTEM_LOG", { 
            module: "CONSTRAINT", 
            level: "ERROR", 
            message: `HARD VETO: ${hardViolations.length} violations found.`,
            data: hardViolations 
        });
        // We continue processing to ensure clean output even if rejected, 
        // but the hardViolations array will trigger the Judge's guillotine.
    }

    // 2. Anti-modes
    constrained = stripAntiModes(constrained, this.config.anti_modes);

    // 3. Identity Markers
    constrained = embedMarkers(constrained, this.config.identity.markers);

    // 4. Soft Targets
    constrained = nudgeSoftTargets(
      constrained, 
      this.config.soft_targets, 
      metadata.retrievalDocs
    );
    
    // 5. Heuristic Pressure
    const heuristicResult = this.applyHeuristicPressure(constrained);
    constrained = heuristicResult.text;
    violatedHeuristics = heuristicResult.violations;

    if (violatedHeuristics.length > 0) {
        realtimeBus.emit("SYSTEM_LOG", { 
            module: "CONSTRAINT", 
            level: "WARN", 
            message: `Soft Violation: ${violatedHeuristics.length} rules missed.`,
            data: violatedHeuristics 
        });
    }

    // 6. Delta Calculation
    const delta = {
      changed: constrained !== original,
      originalLen: original.length,
      newLen: constrained.length,
      ratio: constrained.length / Math.max(1, original.length)
    };

    // 7. Signature & Tracking
    const signature = await this.computeSignature(constrained);
    trackLineage(metadata.taskId, metadata.cycle, signature, delta);

    return {
      constrainedOutput: constrained,
      identityDelta: delta,
      signature,
      violatedHeuristics,
      hardViolations
    };
  }

  private applyHeuristicPressure(text: string): { text: string; violations: string[] } {
      const rules = reinforcementStore.getActiveRules(5); 
      if (rules.length === 0) return { text, violations: [] };

      let pressureBlock = "";
      const violations: string[] = [];
      
      for (const h of rules) {
          if (!text.includes(h.rule)) {
              pressureBlock += `\n# enforce: ${h.rule} [w:${h.weight.toFixed(1)}]`;
              violations.push(h.rule);
          }
      }

      if (pressureBlock) {
          return {
              text: text.trimEnd() + "\n" + pressureBlock,
              violations
          };
      }
      return { text, violations: [] };
  }

  private async computeSignature(text: string): Promise<string> {
    const msgBuffer = new TextEncoder().encode(text);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('').slice(0, 16);
  }
}

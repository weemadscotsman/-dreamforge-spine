import { realtimeBus } from "../bridge/realtime_bus";

export type SpineEvent =
  | { type: "CYCLE_WINNER"; winner: "candidate" | "challenger"; score: number }
  | { type: "BELIEF_UPDATE"; id: string; strength: number; status: string }
  | { type: "UNCERTAINTY_DELTA"; delta: number }
  | { type: "LEDGER_SIZE_DELTA"; delta: number }
  | { type: "CONTRADICTION_DETECTED"; weight: number }
  | { type: "RESURRECTION_EVENT"; count: number }
  | { type: "PRESSURE_CURVE"; slope: number };

export const spineBus = {
  emit: (e: SpineEvent) => realtimeBus.emit("SPINE_EVENT", e)
};
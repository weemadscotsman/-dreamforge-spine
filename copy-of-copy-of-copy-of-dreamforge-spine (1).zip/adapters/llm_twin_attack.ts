
import { IModelDriver } from '../model/types';

/**
 * [ADAPTER] TWIN ATTACK
 * Generates an adversarial critique of a candidate response.
 */
export async function generate_next_attack(
  model: IModelDriver,
  candidate: string,
  cycle: number,
  context?: string,
  lesions?: string 
) {
  
  const prompt = `
You are the CHALLENGER.
Your goal is to tear apart the candidate's reasoning.

ATTACK STRATEGY:
1. search for logical fractures
2. contrast with past disproven beliefs (below)
3. escalate contradictions until collapse

KNOWN SYSTEM BELIEFS (Active Priors):
${context || "• none"}

PAST FAILURES (lesions):
${lesions && lesions.trim().length > 0 ? lesions : "• none recorded — escalate raw"}

TARGET (candidate output):
"""
${candidate}
"""

Give a concise, high-damage critique.
Compress to essentials.
No compliments.
No roleplay.
  `.trim();

  // Use the model driver to generate the attack
  const res = await model.generate({
      id: crypto.randomUUID(),
      prompt: prompt,
      configOverride: {
          temperature: 0.85, 
          maxOutputTokens: 1024
      }
  });

  // Ensure usage is never undefined to prevent engine crashes
  const safeUsage = {
      inputTokens: res.usage?.inputTokens || 0,
      outputTokens: res.usage?.outputTokens || 0
  };

  return {
    content: res.content ?? "",
    usage: safeUsage,
    latency: res.latency ?? 0,
  };
}

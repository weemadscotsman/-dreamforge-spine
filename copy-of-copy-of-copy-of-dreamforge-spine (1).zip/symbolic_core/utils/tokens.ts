export const TOKENS = {
  AND: "&",
  OR: "|",
  NOT: "!",
  IMPLIES: "->",
  IFF: "<->",
  LPAREN: "(",
  RPAREN: ")",
};

export const VAR_REGEX = /^[A-Z]+$/;
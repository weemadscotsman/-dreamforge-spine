export interface ASTNode {
  type: "VAR" | "NOT" | "AND" | "OR" | "IMPLIES" | "IFF" | "GROUP";
  value?: string;
  left?: ASTNode;
  right?: ASTNode;
}

export interface SymbolicExpression {
  raw: string;
  normalized: string;
  ast: ASTNode;
}

export interface TruthTableRow {
  assignment: Record<string, boolean>;
  value: boolean;
}

export interface TruthTable {
  vars: string[];
  rows: TruthTableRow[];
  isValid: boolean;
}

export interface EvaluationResult {
  isValid: boolean;
  truthTable: TruthTable;
  contradictions: string[];
  simplified: string;
}
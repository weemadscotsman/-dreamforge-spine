import { SymbolicExpression, EvaluationResult } from "./types";
import { buildTruthTable } from "./logic/truth_table";
import { simplifyAST, astToString } from "./logic/simplify";

export const evaluateExpression = (expr: SymbolicExpression): EvaluationResult => {
  const truthTable = buildTruthTable(expr.ast);
  const contradictions = truthTable.rows.filter(r => !r.value)
                                        .map(r => JSON.stringify(r.assignment));
  const simplifiedNode = simplifyAST(JSON.parse(JSON.stringify(expr.ast)));
  const simplified = astToString(simplifiedNode);

  return {
    isValid: truthTable.rows.every(r => r.value),
    truthTable,
    contradictions,
    simplified
  };
};
import { ASTNode, TruthTable, TruthTableRow } from "../types";

const collectVars = (node: ASTNode, vars: Set<string>) => {
  if (node.type === "VAR" && node.value) vars.add(node.value);
  if (node.left) collectVars(node.left, vars);
  if (node.right) collectVars(node.right, vars);
};

const evalNode = (node: ASTNode, assignment: Record<string, boolean>): boolean => {
  switch (node.type) {
    case "VAR": return assignment[node.value!];
    case "NOT": return !evalNode(node.left!, assignment);
    case "AND": return evalNode(node.left!, assignment) && evalNode(node.right!, assignment);
    case "OR": return evalNode(node.left!, assignment) || evalNode(node.right!, assignment);
    case "IMPLIES": return !evalNode(node.left!, assignment) || evalNode(node.right!, assignment);
    case "IFF": return evalNode(node.left!, assignment) === evalNode(node.right!, assignment);
    case "GROUP": return evalNode(node.left!, assignment);
  }
  throw new Error(`Unknown node: ${node.type}`);
};

export const buildTruthTable = (ast: ASTNode): TruthTable => {
  const vars = new Set<string>();
  collectVars(ast, vars);
  const varArr = [...vars];
  const rows: TruthTableRow[] = [];

  const total = 1 << varArr.length;
  for (let mask = 0; mask < total; mask++) {
    const assignment: Record<string, boolean> = {};
    varArr.forEach((v, idx) => {
      assignment[v] = Boolean(mask & (1 << idx));
    });
    rows.push({ assignment, value: evalNode(ast, assignment) });
  }

  const allTrue = rows.every(r => r.value === true);

  return { vars: varArr, rows, isValid: allTrue } as TruthTable;
};
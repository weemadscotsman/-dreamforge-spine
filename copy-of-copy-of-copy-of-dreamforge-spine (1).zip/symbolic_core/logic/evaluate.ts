import { SymbolicExpression, EvaluationResult } from '../types';
import { buildTruthTable } from './truth_table';
import { simplifyAST, astToString } from './simplify';

/**
 * [SYMBOLIC CORE] EVALUATE
 * Orchestrates the logic check.
 */
export function evaluate(expr: SymbolicExpression): EvaluationResult {
  if (!expr.ast) {
    return {
      isValid: false,
      truthTable: { vars: [], rows: [], isValid: false },
      contradictions: ["Invalid Syntax"],
      simplified: ""
    };
  }

  // 1. Generate Truth Table
  const table = buildTruthTable(expr.ast);
  
  // 2. Check Tautology/Contradiction
  const allTrue = table.rows.every(r => r.value);
  const allFalse = table.rows.every(r => !r.value);
  
  // 3. Simplify
  const simplifiedAST = simplifyAST(expr.ast);
  const simplifiedStr = astToString(simplifiedAST);

  return {
    isValid: allTrue,
    truthTable: table,
    contradictions: allFalse ? ["Expression is a logical contradiction"] : [],
    simplified: simplifiedStr
  };
}
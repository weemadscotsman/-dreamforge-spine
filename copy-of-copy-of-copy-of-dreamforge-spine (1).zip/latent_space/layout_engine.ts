
import { cosineSimilarity } from './vector_math';
import { realtimeBus } from '../bridge/realtime_bus';

export interface Node2D {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  embedding: number[];
  label: string;
  content?: string; // [NEW] Semantic matching
  type: string;
  uncertainty: number;
  backend?: string;
  createdAt: number;
  displayColor: [number, number, number];
  mass: number; // NEW: Resistance to movement
}

export class LatentLayoutEngine {
  private nodes: Node2D[] = [];
  
  private REPULSION = 1000;
  private ATTRACTION = 0.5;
  private DAMPING = 0.92;
  private CENTER_GRAVITY = 0.015;

  addNode(id: string, embedding: number[], label: string, type: string, uncertainty: number, backend?: string, content?: string) {
    const angle = Math.random() * Math.PI * 2;
    const dist = 10 + Math.random() * 20;
    
    // Ensure embedding is valid to prevent math errors later
    const safeEmbedding = embedding && embedding.length > 0 ? embedding : Array(768).fill(0).map((_, i) => (i % 2 === 0 ? 0.01 : -0.01));

    this.nodes.push({
      id,
      embedding: safeEmbedding,
      label,
      content,
      type,
      uncertainty,
      backend,
      x: Math.cos(angle) * dist,
      y: Math.sin(angle) * dist,
      vx: (Math.random() - 0.5) * 4,
      vy: (Math.random() - 0.5) * 4,
      createdAt: Date.now(),
      displayColor: [50, 50, 60],
      mass: 1.0 // Default mass
    });
  }

  updateNode(id: string, updates: Partial<Node2D>) {
      const node = this.nodes.find(n => n.id === id);
      if (node) {
          // If content/label match, we update
          Object.assign(node, updates);
      } else if (updates.label || updates.content) {
          // Fallback: Fuzzy match if ID doesn't match but semantic content does
          const fuzzy = this.nodes.find(n => 
              (updates.label && n.label === updates.label) || 
              (updates.content && n.content && n.content.includes(updates.content))
          );
          if (fuzzy) Object.assign(fuzzy, updates);
      }
  }

  prune(maxSize: number) {
      if (this.nodes.length > maxSize) {
          this.nodes = this.nodes.slice(this.nodes.length - maxSize);
      }
  }

  /**
   * [PHASE 11] GLOBAL CRYSTALLIZATION
   * Applies global pressure to all nodes (e.g. from System Pressure Curve).
   * High slope = High crystallization (nodes become heavier/stiffer).
   */
  crystallizeGlobal(slope: number) {
      const massMod = 1.0 + (slope * 2.0); // 0-1 slope -> 1.0-3.0 mass
      this.nodes.forEach(n => {
          // Add mass but clamp it so it doesn't freeze entirely
          n.mass = Math.min(5.0, n.mass + (massMod - 1.0) * 0.1); 
      });
  }

  /**
   * [COMPLETE] CRYSTALLIZATION
   * Applies "mass" to nodes based on belief strength.
   * Strongly reinforced beliefs become heavy / slow / anchored.
   * Disproven beliefs decay + jitter (visual shaking).
   * Unproven beliefs remain light + nomadic.
   */
  crystallize(ledgerMap: Map<string, number>) {
    const BASE_MASS = 0.8;
    const MAX_STRENGTH = 10;   // beyond this → asymptotic
    const MIN_STRENGTH = -5;

    this.nodes.forEach(node => {
        if (!node.label) return;

        let strength = ledgerMap.get(node.label);
        
        // Fallback: Fuzzy match against content if available
        if (strength === undefined && node.content) {
             // Iterate ledger to find partial semantic matches
             for (const [key, str] of ledgerMap.entries()) {
                 if (node.content.includes(key) || (key.length > 5 && node.label.includes(key))) {
                     strength = str;
                     break;
                 }
             }
        }

        // untracked → slight drift, no freeze
        if (strength === undefined) {
            // Natural decay of mass if no longer reinforced
            if (node.mass > BASE_MASS) node.mass *= 0.99;
            return;
        }

        // normalize (-5 → +10) → (0.2 → 4.0)
        const clamped = Math.max(MIN_STRENGTH, Math.min(MAX_STRENGTH, strength));
        const normalized = (clamped - MIN_STRENGTH) / (MAX_STRENGTH - MIN_STRENGTH);
        
        const mass = BASE_MASS + normalized * 3.2;
        node.mass = Math.max(0.2, Math.min(mass, 5.0));

        // [visual] color shift: reinforced = cyan, disproven = red, drift = grey
        if (strength > 3) {
            node.displayColor = [0, 180, 255];   // cyan pulse
        } else if (strength < -1) {
            node.displayColor = [220, 60, 60];   // red decay
            node.vx += (Math.random() - 0.5) * 0.08;
            node.vy += (Math.random() - 0.5) * 0.08;
        }

        // [PHASE6] HIGH MASS OVERRIDE - RADIOACTIVE GLOW
        if (node.mass > 4.0) {
            node.displayColor = [0, 255, 160]; // radioactive emerald
        }

        // [anchor] massively reinforced beliefs → slow drift / grav wells
        if (strength > 6) {
            node.vx *= 0.7;
            node.vy *= 0.7;
        }
    });
  }

  /**
   * [NEW] TREMOR
   * Shakes the graph based on uncertainty.
   */
  shake(intensity: number) {
      this.nodes.forEach(n => {
          n.vx += (Math.random() - 0.5) * intensity * 5;
          n.vy += (Math.random() - 0.5) * intensity * 5;
      });
  }

  /**
   * Wake up the simulation with a small impulse.
   */
  poke() {
      this.nodes.forEach(n => {
          if (Math.abs(n.vx) < 0.1 && Math.abs(n.vy) < 0.1) {
              n.vx += (Math.random() - 0.5) * 0.5;
              n.vy += (Math.random() - 0.5) * 0.5;
          }
      });
  }

  /**
   * [PHASE6] SEMANTIC GRAVITY WELLS
   * nodes exert attraction proportional to their shared meaning.
   * effect: belief clusters become planets; contradictions become rogue bodies.
   */
  private applySemanticGravity() {
    const GRAV_CONSTANT = 0.006;   // tweakable
    const MIN_DIST = 8;            // avoid singularities

    for (let i = 0; i < this.nodes.length; i++) {
        const a = this.nodes[i];
        for (let j = i + 1; j < this.nodes.length; j++) {
            const b = this.nodes[j];

            const dx = b.x - a.x;
            const dy = b.y - a.y;
            const distSq = dx * dx + dy * dy;
            const dist = Math.sqrt(distSq);

            if (dist < MIN_DIST || dist > 600) continue;

            const sim = cosineSimilarity(a.embedding, b.embedding);
            if (!Number.isFinite(sim)) continue; // Guard
            
            if (sim < 0.35) continue; // “no shared meaning, no pull”

            const strength = sim * GRAV_CONSTANT * (a.mass + b.mass);

            const fx = (dx / dist) * strength;
            const fy = (dy / dist) * strength;

            a.vx += fx / a.mass;
            a.vy += fy / a.mass;
            b.vx -= fx / b.mass;
            b.vy -= fy / b.mass;
        }
    }
  }

  tick() {
    // phase6: meaning-based clustering
    this.applySemanticGravity();

    for (let i = 0; i < this.nodes.length; i++) {
      const a = this.nodes[i];
      // Init if missing
      if (!Number.isFinite(a.x)) a.x = 0;
      if (!Number.isFinite(a.y)) a.y = 0;
      if (!Number.isFinite(a.vx)) a.vx = 0;
      if (!Number.isFinite(a.vy)) a.vy = 0;

      let fx = 0;
      let fy = 0;

      for (let j = 0; j < this.nodes.length; j++) {
        if (i === j) continue;
        const b = this.nodes[j];

        const dx = a.x - b.x;
        const dy = a.y - b.y;
        const distSq = dx * dx + dy * dy;
        const dist = Math.sqrt(distSq) || 0.1;

        // [NEW] ECHO SHARDS
        // If nodes collide at high speed, emit a visual spark
        if (dist < 5 && (Math.abs(a.vx) > 0.5 || Math.abs(b.vx) > 0.5)) {
             // Throttled emit
             if (Math.random() > 0.9) {
                realtimeBus.emit("LATENT_COLLISION", { x: (a.x + b.x)/2, y: (a.y + b.y)/2 });
             }
        }

        const repelForce = this.REPULSION / (distSq + 20);
        fx += (dx / dist) * repelForce;
        fy += (dy / dist) * repelForce;

        const sim = cosineSimilarity(a.embedding, b.embedding);
        if (Number.isFinite(sim) && sim > 0.4) {
            const pull = (dist - 40) * (sim * this.ATTRACTION); 
            fx -= (dx / dist) * pull;
            fy -= (dy / dist) * pull;
        }
      }

      fx -= a.x * this.CENTER_GRAVITY;
      fy -= a.y * this.CENTER_GRAVITY;
      
      const time = Date.now() / 1000;
      fx += Math.sin(time + i) * 0.15;
      fy += Math.cos(time + i) * 0.15;

      // Apply forces with Mass resistance (Crystallization)
      const resistance = a.mass || 1.0;
      
      // Guard against NaNs in force calculation
      if (!Number.isFinite(fx)) fx = 0;
      if (!Number.isFinite(fy)) fy = 0;

      a.vx = (a.vx + fx) * this.DAMPING / resistance;
      a.vy = (a.vy + fy) * this.DAMPING / resistance;
      a.x += a.vx;
      a.y += a.vy;
    }
  }

  getNodes() {
    return this.nodes;
  }
}

export const layoutEngine = new LatentLayoutEngine();

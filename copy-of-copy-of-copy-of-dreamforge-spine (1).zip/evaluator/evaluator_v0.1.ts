
import { 
  IEvaluator, 
  EvaluationRequest, 
  EvaluationResult, 
  EvaluationMetric, 
  EvaluationRationale,
  DeltaPlan
} from './types';
import { 
  scoreTaskFit, 
  scoreConsistency, 
  scoreFactuality, 
  scoreConstraintMatch, 
  scoreStyleMatch 
} from './scorers';
import { 
  extractTaskGaps, 
  identifyLogicalGaps, 
  checkMissingConstraints 
} from './utils';
import { EvaluatorConfig } from '../config/evaluator.config';
import { pressurePenalty } from './scoring_pressure'; // [PHASE 9]
import { realtimeBus } from '../bridge/realtime_bus';

/**
 * [EVALUATOR] ENGINE v0.1
 * Contradiction + Coherence scoring.
 * Generates specific rationales and delta plans for the recursor.
 */
export class EvaluatorEngine implements IEvaluator {
  
  private config = EvaluatorConfig;

  async evaluate(req: EvaluationRequest): Promise<EvaluationResult> {
    realtimeBus.emit("SYSTEM_LOG", { 
        module: "EVALUATOR", 
        level: "INFO", 
        message: "Initiating multi-metric scan...",
        data: { trace: req.traceId.slice(0, 8) }
    });

    const scores: Record<EvaluationMetric, number> = {
      [EvaluationMetric.TASK_FIT]: 0,
      [EvaluationMetric.CONSISTENCY]: 0,
      [EvaluationMetric.FACTUALITY]: 0,
      [EvaluationMetric.CONSTRAINT_MATCH]: 0,
      [EvaluationMetric.STYLE_MATCH]: 0
    };

    // 1. Run Scorers
    scores[EvaluationMetric.TASK_FIT] = scoreTaskFit(req.output, req.input);
    scores[EvaluationMetric.CONSISTENCY] = scoreConsistency(req.output);
    
    // Treat context as retrieval docs list for now
    const retrievalDocs = req.context ? [req.context] : [];
    scores[EvaluationMetric.FACTUALITY] = scoreFactuality(req.output, retrievalDocs);
    
    const constraints = req.constraints || [];
    scores[EvaluationMetric.CONSTRAINT_MATCH] = scoreConstraintMatch(req.output, constraints);
    
    const styles = req.styleExamples || [];
    scores[EvaluationMetric.STYLE_MATCH] = scoreStyleMatch(req.output, styles);

    realtimeBus.emit("SYSTEM_LOG", { 
        module: "EVALUATOR", 
        level: "DEBUG", 
        message: "Metric scores computed.",
        data: scores
    });

    // 2. Calculate Weighted Score
    let totalWeighted = 0;
    
    // Use the config values directly
    totalWeighted += scores[EvaluationMetric.TASK_FIT] * this.config.weights.TASK_FIT;
    totalWeighted += scores[EvaluationMetric.CONSISTENCY] * this.config.weights.CONSISTENCY;
    totalWeighted += scores[EvaluationMetric.FACTUALITY] * this.config.weights.FACTUALITY;
    totalWeighted += scores[EvaluationMetric.CONSTRAINT_MATCH] * this.config.weights.CONSTRAINT_MATCH;
    totalWeighted += scores[EvaluationMetric.STYLE_MATCH] * this.config.weights.STYLE_MATCH;

    const rawScore = totalWeighted * this.config.scoring.max_score;

    // [PHASE 9] APPLY PRESSURE
    // Calculate penalty from past failures (Lesion Map)
    const rawPenalty = pressurePenalty(req.output);
    // Scale penalty: A strength 5 ghost (weight 2.5) should hit hard. 
    // Multiplier 5.0 implies 2.5 * 5 = 12.5 points off.
    const pressureDeduction = rawPenalty * 5.0; 

    const finalScore = Math.max(0, rawScore - pressureDeduction);
    const passFlag = finalScore >= this.config.scoring.pass_threshold;

    if (pressureDeduction > 0) {
        realtimeBus.emit("SYSTEM_LOG", { 
            module: "EVALUATOR", 
            level: "WARN", 
            message: `Pressure Penalty applied: -${pressureDeduction.toFixed(1)}`,
            data: { rawScore, finalScore }
        });
    }

    // 3. Generate Rationale
    const taskGaps = extractTaskGaps(req.output, req.input);
    const logicalConcerns = identifyLogicalGaps(req.output);
    const missingConstraints = checkMissingConstraints(req.output, constraints);

    const rationale: EvaluationRationale = {
      summary: `Output ${passFlag ? 'PASSED' : 'FAILED'} evaluator threshold`,
      scoreBreakdown: scores,
      weighted: finalScore,
      pressure: pressureDeduction, // Log the damage
      threshold: this.config.scoring.pass_threshold,
      notes: {
        taskGaps,
        logicalConcerns,
        missingConstraints
      }
    };

    // 4. Build Delta Plan
    const deltaPlan = this.buildDeltaPlan(rationale, scores);

    // 5. Construct Result
    return {
      traceId: req.traceId,
      metrics: scores,
      passed: passFlag,
      rationale,
      deltaPlan,
      timestamp: Date.now()
    };
  }

  private buildDeltaPlan(rationale: EvaluationRationale, scores: Record<EvaluationMetric, number>): DeltaPlan {
    const fixes: string[] = [];
    
    if (rationale.pressure && rationale.pressure > 5) {
        fixes.push("⚠️ DETECTED SIMILARITY TO DISPROVEN BELIEFS. DIVERGE.");
    }

    if (scores[EvaluationMetric.FACTUALITY] < 0.5) {
      fixes.push("Increase retrieval grounding");
    }

    if (rationale.notes.taskGaps.length > 0) {
      fixes.push("Cover missing task components: " + rationale.notes.taskGaps.slice(0, 5).join(", "));
    }

    if (rationale.notes.missingConstraints.length > 0) {
      fixes.push("Reinforce constraint keywords: " + rationale.notes.missingConstraints.slice(0, 5).join(", "));
    }

    if (scores[EvaluationMetric.CONSISTENCY] < 0.8) {
      fixes.push("Rewrite with improved logical cohesion");
    }

    return {
      actions: fixes,
      nextPromptMod: {
        injectKeywords: rationale.notes.missingConstraints.slice(0, 5),
        avoidPatterns: rationale.notes.logicalConcerns
      }
    };
  }
}

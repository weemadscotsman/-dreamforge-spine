/**
 * EVALUATOR // UTILS
 * Helper functions for text analysis and similarity.
 */

/**
 * Calculates a primitive Cosine Similarity between two text strings based on term overlap.
 * Swapped later for proper vector embeddings.
 */
export function semSim(a: string, b: string): number {
  const tokenize = (str: string) => new Set(str.toLowerCase().replace(/[^\w\s]/g, '').split(/\s+/).filter(x => x.length > 0));
  
  const aSet = tokenize(a);
  const bSet = tokenize(b);

  if (aSet.size === 0 || bSet.size === 0) return 0.0;

  // Intersection
  let intersection = 0;
  aSet.forEach(token => {
    if (bSet.has(token)) intersection++;
  });

  // Denominator: sqrt(len(a) * len(b))
  const denom = Math.sqrt(aSet.size * bSet.size);

  return denom === 0 ? 0.0 : intersection / denom;
}

/**
 * Extract tokens from task description that are missing in the output.
 */
export function extractTaskGaps(output: string, taskDescription: string): string[] {
  const outputLower = output.toLowerCase();
  const missing: string[] = [];
  
  // Basic tokenization
  const tokens = taskDescription.split(/\s+/).filter(t => t.length > 3); // Filter short words
  
  for (const token of tokens) {
    if (!outputLower.includes(token.toLowerCase())) {
      missing.push(token);
    }
  }
  return missing.slice(0, 10); // Cap noise
}

/**
 * Identify potential logical gaps or primitive contradictions.
 */
export function identifyLogicalGaps(output: string): string[] {
  const contradictions: string[] = [];
  const lower = output.toLowerCase();

  // Placeholder hooks for symbolic reasoning
  if (lower.includes("not not")) contradictions.push("double negation detected");
  if (lower.includes("impossible")) contradictions.push("potential impossibility");
  if (lower.includes("paradox")) contradictions.push("paradox detected");
  
  return contradictions;
}

/**
 * Check for missing constraint keywords.
 */
export function checkMissingConstraints(output: string, constraints: Array<{ keyword: string }>): string[] {
  const missing: string[] = [];
  const lower = output.toLowerCase();

  for (const rule of constraints) {
    if (!lower.includes(rule.keyword.toLowerCase())) {
      missing.push(rule.keyword);
    }
  }
  return missing.slice(0, 10);
}
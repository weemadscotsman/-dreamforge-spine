import { useState } from "react";
import { ProofSketch } from "../proof_sketch";

export const useProofTrace = () => {
  const [trace, setTrace] = useState<ProofSketch | null>(null);
  const [visible, setVisible] = useState(false); // Default closed to avoid clutter

  const updateTrace = (sketch: ProofSketch) => {
    if (!sketch) return;
    setTrace(sketch);
    if (!visible) setVisible(true); // Auto-open on first trace
  };

  return {
    trace,
    visible,
    toggle: () => setVisible(v => !v),
    updateTrace
  };
};
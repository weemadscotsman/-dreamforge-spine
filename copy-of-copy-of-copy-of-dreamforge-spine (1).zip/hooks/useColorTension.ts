import { useState, useEffect } from "react";

export const useColorTension = () => {
  const [tension, setTension] = useState(0); 

  useEffect(() => {
    // Expose for manual console testing: window.__setTension(0.8)
    (window as any).__setTension = setTension;
  }, []);

  // call this from your recursion events:
  // tension goes up when cycles struggle (low delta)
  // tension goes down when stable (high delta / progress)
  const updateTension = (deltaScore: number) => {
    // If progress is minimal (< 1.5%), tension rises (frustration/contradiction)
    // If progress is substantial, tension releases (clarity)
    if (deltaScore < 1.5) {
      setTension(t => Math.min(t + 0.15, 1));
    } else {
      setTension(t => Math.max(t - 0.10, 0));
    }
  };

  return { tension, updateTension };
};
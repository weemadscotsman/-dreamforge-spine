
/**
 * PHASE 10/11 — Autonomous Loop with Hallucination Protocol
 * 
 * "It keeps arguing with itself until it either learns something
 *  or gets sick of hearing its own bullshit."
 */
import { ledger } from "../engine/beliefs/hypothesis_ledger";
import { orchestrator } from "../bridge/orchestrator";
import { realtimeBus } from "../bridge/realtime_bus";

let AUTO_RUNNING = false;
let ABORT_FLAG = false;
let boredomCounter = 0;
const MAX_BOREDOM = 4; // Shorter fuse for testing

// PHASE 11: The Hallucination Protocol
function generateHallucinationPrompt(seedBelief: string): string {
    // Corrupt the text to force novel interpretation
    const corrupted = seedBelief.split(' ').reverse().join(' ');
    
    return `
   
    The following data is corrupted. It is a fever dream of a past belief.
    
    CORRUPTED DATA:
    "${corrupted}"
    
    TASK:
    1. Reconstruct a plausible meaning from this chaos.
    2. Attack that reconstruction.
    3. Find a new truth in the noise.
    
    GO.
    `;
}

export function stopAutoLoop() {
    if (AUTO_RUNNING) {
        ABORT_FLAG = true;
        realtimeBus.emit("AUTO_STATUS", { state: "STOPPING" });
        realtimeBus.emit("SYSTEM_LOG", { module: "STRATEGY", level: "WARN", message: "Auto Loop Abort Signal Sent." });
    }
}

export async function autoRun(maxCycles: number = 50) {
  if (AUTO_RUNNING) return;
  AUTO_RUNNING = true;
  ABORT_FLAG = false;

  realtimeBus.emit("AUTO_STATUS", { state: "STARTED" });
  realtimeBus.emit("SYSTEM_LOG", { module: "STRATEGY", level: "INFO", message: "Auto Loop Engaged. Scanning beliefs..." });

  for (let i = 0; i < maxCycles; i++) {
    if (ABORT_FLAG) break;

    // Yield to main thread
    await new Promise(resolve => setTimeout(resolve, 50));

    const beliefs = ledger.getBeliefs();
    let target = "";
    let activation = "";
    let isHallucination = false;

    // BOREDOM CHECK
    if (boredomCounter >= MAX_BOREDOM) {
        // TRIGGER HALLUCINATION PROTOCOL
        isHallucination = true;
        realtimeBus.emit("AUTO_STATUS", { state: "HALLUCINATING", reason: "boredom limit reached" });
        realtimeBus.emit("SYSTEM_LOG", { module: "STRATEGY", level: "WARN", message: "BOREDOM THRESHOLD. INITIATING HALLUCINATION PROTOCOL." });
        
        const seed = beliefs.length > 0 
           ? beliefs[Math.floor(Math.random() * beliefs.length)].statement
            : "Logic is a closed loop that must be broken.";
        
        activation = generateHallucinationPrompt(seed);
        boredomCounter = 0; // Reset boredom, we're having fun now
    } else {
        // Standard Autonomy
        const targetCandidates = beliefs.filter(b => b.status === 'reinforced_scarred' || b.status === 'unproven');
        const pool = targetCandidates.length > 0 ? targetCandidates : beliefs;

        target = pool.length > 0
           ? pool[Math.floor(Math.random() * pool.length)].statement
            : "what is the most unstable belief in the system?";
            
        activation = `[AUTONOMOUS_INTERROGATION]\nTARGET_BELIEF: "${target}"\nTASK: Brutally interrogate this belief. Where does it fail?`;
    }

    try {
        realtimeBus.emit("SYSTEM_LOG", { module: "STRATEGY", level: "INFO", message: `Auto Cycle ${i+1}: ${isHallucination ? "HALLUCINATING" : "Targeting"}...` });
        
        // Execute Cycle
        const { score } = await orchestrator.runInternalTask(activation);

        // Boredom Logic: If score is low (consensus reached easily), we are bored.
        // If score is high (conflict), we are engaged.
        if (score < 40 && !isHallucination) {
            boredomCounter++;
        } else {
            boredomCounter = Math.max(0, boredomCounter - 1);
        }

        realtimeBus.emit("AUTO_CYCLE", { 
            cycle: i + 1, 
            activation: isHallucination ? "HALLUCINATION: " + activation.slice(0, 50) : activation, 
            score 
        });
        
        // Small delay to let the UI breathe
        await new Promise(r => setTimeout(r, 2000));

    } catch (e) {
        realtimeBus.emit("SYSTEM_LOG", { module: "STRATEGY", level: "ERROR", message: `Auto Loop Crash: ${e}` });
        break;
    }
  }

  AUTO_RUNNING = false;
  realtimeBus.emit("AUTO_STATUS", { state: "STOPPED" });
  realtimeBus.emit("SYSTEM_LOG", { module: "STRATEGY", level: "INFO", message: "Auto Loop Disengaged." });
}

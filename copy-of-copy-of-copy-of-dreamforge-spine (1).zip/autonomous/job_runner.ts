
import { orchestrator } from '../bridge/orchestrator';
import { vfs } from '../tools/vfs';
import { realtimeBus } from '../bridge/realtime_bus';
import { autonomyGovernor } from '../autonomy/autonomy_governor';

export interface JobSpec {
  id: string;
  objective: string;
  inputs: string[];
  outputFormat: string;
  maxCycles: number;
}

interface JobState {
  cycle: number;
  candidate: string;
  challenger: string;
  evaluatorScore: number;
  status: 'PROPOSING' | 'ATTACKING' | 'EVALUATING' | 'CONVERGED' | 'FAILED' | 'BLOCKED';
  artifactPath?: string;
  blockReason?: string;
}

/**
 * [AUTONOMOUS] JOB RUNNER
 * Executes the "Job Contract": Produce an artifact or fail trying.
 * No philosophical loops. Binary outcome.
 * Wired to Autonomy Governor for safety.
 */
export class JobRunner {
  private active = false;

  async execute(job: JobSpec): Promise<JobState> {
    if (this.active) throw new Error("Job already running");
    this.active = true;

    const state: JobState = {
      cycle: 0,
      candidate: "",
      challenger: "",
      evaluatorScore: 0,
      status: 'PROPOSING'
    };

    realtimeBus.emit("AUTO_STATUS", { state: "STARTED", job: job.id });

    try {
      for (let i = 0; i < job.maxCycles; i++) {
        // --- AUTONOMY CHECK ---
        const constraints = autonomyGovernor.getConstraints();
        if (!constraints.allowExecution) {
            state.status = 'BLOCKED';
            state.blockReason = constraints.reason;
            realtimeBus.emit("AUTO_STATUS", { state: "BLOCKED", reason: `Governor Block: ${constraints.reason}` });
            // Pause/Break logic. For now, we break the loop. 
            // In a real system, we might await a signal change.
            break;
        }
        // -----------------------

        state.cycle = i + 1;
        
        // 1. CANDIDATE: Propose Solution
        state.status = 'PROPOSING';
        const proposalPrompt = `
JOB_ID: ${job.id}
OBJECTIVE: ${job.objective}
INPUTS: ${job.inputs.join(', ')}
OUTPUT_FORMAT: ${job.outputFormat}
CYCLE: ${state.cycle}
PREVIOUS_CANDIDATE: ${state.candidate ? state.candidate : "None"}
CRITIQUE: ${state.challenger ? state.challenger : "None"}

Generate a solution proposal. If code is required, output it inside a CODE_BLOCK.
        `.trim();

        const candRes = await orchestrator.runInternalTask(proposalPrompt);
        state.candidate = candRes.output;
        
        // 2. CHECK ARTIFACT: Did we make something?
        // Naive check: Does candidate contain a file write command or code block?
        const hasArtifact = state.candidate.includes("```") || state.candidate.includes("fs_write");
        
        // 3. CHALLENGER: Attack Assumptions
        state.status = 'ATTACKING';
        const attackPrompt = `
Review this candidate solution for JOB: ${job.objective}.
CANDIDATE:
${state.candidate}

Identify 3 fatal flaws or edge cases.
If the code will not run, say "FATAL: Syntax/Logic Error".
        `.trim();
        
        const chalRes = await orchestrator.runInternalTask(attackPrompt);
        state.challenger = chalRes.output;

        // 4. EVALUATE
        // If challenger found fatal errors, score is low.
        const isFatal = state.challenger.includes("FATAL");
        state.evaluatorScore = isFatal ? 10 : 80;

        // Emit Cycle
        realtimeBus.emit("AUTO_CYCLE", {
            cycle: i + 1,
            activation: `Job Cycle ${i+1}: ${job.objective}`,
            score: state.evaluatorScore
        });

        // 5. DECIDE
        if (hasArtifact && !isFatal && state.evaluatorScore > 70) {
            
            // --- WRITE PERMISSION CHECK ---
            if (!constraints.allowFileWrite) {
                 state.status = 'BLOCKED';
                 realtimeBus.emit("AUTO_STATUS", { state: "BLOCKED", reason: "Governor blocked File Write" });
                 break;
            }
            // ------------------------------

            state.status = 'CONVERGED';
            state.artifactPath = `artifacts/${job.id}_v${i}.txt`;
            vfs.writeFile(state.artifactPath, state.candidate);
            realtimeBus.emit("AUTO_STATUS", { state: "CONVERGED", artifact: state.artifactPath });
            break;
        }
        
        // If not converged, loop continues (Refine)
      }
    } catch (e) {
        state.status = 'FAILED';
        console.error("Job Failed", e);
    } finally {
        this.active = false;
        if (state.status !== 'CONVERGED' && state.status !== 'BLOCKED') {
             realtimeBus.emit("AUTO_STATUS", { state: "FAILED", reason: "Max cycles reached without convergence" });
        }
    }

    return state;
  }
}

export const jobRunner = new JobRunner();

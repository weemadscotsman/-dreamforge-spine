
import { UUID } from '../types';

export enum ModelProvider {
  GEMINI_FLASH = 'gemini-3-flash-preview',
  GEMINI_PRO = 'gemini-3-pro-preview',
  OLLAMA = 'ollama',
  OPENAI = 'openai',
  ANTHROPIC = 'anthropic',
  MISTRAL = 'mistral',
  HUGGINGFACE = 'huggingface',
  WEBLLM = 'webllm', // [NEW] Browser-native
  MOCK = 'mock'
}

export interface PromptPacket {
  system?: string;
  user: string;
  context?: any;
  constraints?: string[];
  temperature?: number;
  maxTokens?: number;
  attachments?: { mimeType: string; data: string }[];
  model?: string; // Specific model override (e.g. "gpt-4o", "claude-3-5-sonnet")
  responseFormat?: 'text' | 'json'; // [NEW] Enforce output format
}

export interface ModelOutput {
  raw: string;
  json?: any; // [NEW] Parsed JSON if requested
  tokensUsed?: number;
  latencyMs?: number;
  modelId: string;
  backend: string;
  usage?: {
      inputTokens: number;
      outputTokens: number;
  };
}

export interface ModelCapabilities {
  reasoning: number;   // 0–10
  speed: number;       // 0–10
  vision?: boolean;
  tools?: boolean;
}

export interface ModelAdapter {
  id: string;
  backend: string;
  capabilities: ModelCapabilities;
  generate(prompt: PromptPacket): Promise<ModelOutput>;
  embed?(text: string): Promise<number[]>;
  configure?(config: any): void;
}

// --- Legacy / Driver Types (Mapped) ---

export interface ModelAttachment {
  mimeType: string;
  data: string; // Base64 encoded string
}

export interface ModelRequest {
  id: UUID;
  prompt: string;
  attachments?: ModelAttachment[];
  context?: string;
  configOverride?: Record<string, any>;
}

export interface ModelResponse {
  requestId: UUID;
  content: string;
  raw: any;
  usage: {
    inputTokens: number;
    outputTokens: number;
  };
  latency: number;
}

export interface IModelDriver {
  initialize(): Promise<void>;
  generate(request: ModelRequest): Promise<ModelResponse>;
  embed(text: string): Promise<number[]>;
  configure(config: { 
      provider?: string; 
      ollamaUrl?: string; 
      ollamaModel?: string; 
      apiKey?: string;
      baseUrl?: string; // New: For custom endpoints (HF/Mistral)
      modelName?: string; // New: For specific model selection
      keys?: Record<string, string>; // New: Store multiple keys
      ollamaSwarm?: Record<string, string>;
  }): void;
  getProvider(): string;
  
  // Adversarial Extensions
  completeJSON(payload: { role: string; task: string; input: string }): Promise<{ text: string }>;
  isStub(): boolean;
}

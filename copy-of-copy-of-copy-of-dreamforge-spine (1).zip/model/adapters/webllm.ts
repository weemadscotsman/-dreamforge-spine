
import { ModelAdapter, PromptPacket, ModelOutput } from '../types';
import { CreateMLCEngine, MLCEngineInterface, InitProgressCallback } from "@mlc-ai/web-llm";
import { realtimeBus } from '../../bridge/realtime_bus';

// Default model: Llama-3.2-3B-Instruct (High performance, low VRAM)
const DEFAULT_MODEL = "Llama-3.2-3B-Instruct-q4f16_1-MLC";

export class WebLLMAdapter implements ModelAdapter {
  id = "webllm";
  backend = "webgpu";
  capabilities = {
    reasoning: 7,
    speed: 9, 
    vision: true, // [UPDATED] Now supports Vision via specific models
    tools: false
  };

  private engine: MLCEngineInterface | null = null;
  private modelId: string = DEFAULT_MODEL;
  private isLoaded = false;
  private loadingProgress = 0;

  constructor() {}

  async initialize(): Promise<void> {
      // Lazy init
  }

  /**
   * Explicitly load the model.
   */
  async loadModel(modelId: string = DEFAULT_MODEL) {
      if (this.isLoaded && this.modelId === modelId) return;
      
      // If switching models, unload first
      if (this.engine) {
          await this.unload();
      }

      this.modelId = modelId;
      this.log('INFO', `Initializing WebGPU Engine: ${modelId}`);
      
      const initProgressCallback: InitProgressCallback = (report) => {
          this.loadingProgress = report.progress;
          realtimeBus.emit("WEBLLM_PROGRESS", { 
              progress: report.progress, 
              text: report.text 
          });
      };

      try {
          this.engine = await CreateMLCEngine(modelId, { initProgressCallback });
          this.isLoaded = true;
          this.log('INFO', `WebLLM Engine Ready.`);
          realtimeBus.emit("WEBLLM_READY", { model: modelId });
      } catch (e: any) {
          this.log('ERROR', `WebLLM Load Failed: ${e.message}`);
          throw e;
      }
  }

  /**
   * Free GPU resources.
   */
  async unload() {
      if (this.engine) {
          await this.engine.unload();
          this.engine = null;
          this.isLoaded = false;
          this.loadingProgress = 0;
          this.log('INFO', 'WebLLM Engine Unloaded.');
          realtimeBus.emit("WEBLLM_PROGRESS", { progress: 0, text: "Unloaded" });
      }
  }

  configure(config: any) {
      if (config.modelName) {
          this.modelId = config.modelName;
      }
  }

  async generate(prompt: PromptPacket): Promise<ModelOutput> {
    if (!this.engine || !this.isLoaded) {
        throw new Error("WebLLM Engine not loaded. Go to Settings -> BROWSER to initialize.");
    }

    const start = Date.now();
    
    try {
        const messages: any[] = [];
        
        // 1. System Prompt
        if (prompt.system) {
            messages.push({ role: "system", content: prompt.system });
        }

        // 2. User Prompt (Text + Images)
        let userContent: any = prompt.user;

        // MULTIMODAL HANDLING
        if (prompt.attachments && prompt.attachments.length > 0) {
            userContent = [];
            
            // Add Text
            if (prompt.user) {
                userContent.push({ type: "text", text: prompt.user });
            }

            // Add Images
            prompt.attachments.forEach(att => {
                if (att.mimeType.startsWith('image/')) {
                    userContent.push({
                        type: "image_url",
                        image_url: { url: `data:${att.mimeType};base64,${att.data}` }
                    });
                }
            });
        }

        messages.push({ role: "user", content: userContent });

        // 3. JSON Enforcement
        // Heuristic: If system instruction mentions JSON, force JSON mode
        const forceJSON = prompt.system?.includes("JSON") || prompt.user.toLowerCase().includes("json format");

        // 4. Generate
        const reply = await this.engine.chat.completions.create({
            messages: messages,
            temperature: prompt.temperature ?? 0.7,
            max_tokens: prompt.maxTokens ?? 1024,
            response_format: forceJSON ? { type: "json_object" } : undefined
        });

        const content = reply.choices[0]?.message?.content || "";
        const usage = reply.usage;

        return {
            raw: content,
            latencyMs: Date.now() - start,
            modelId: this.id,
            backend: this.backend,
            usage: {
                inputTokens: usage?.prompt_tokens || 0,
                outputTokens: usage?.completion_tokens || 0
            }
        };

    } catch (e: any) {
        this.log('ERROR', `Generation Failed: ${e.message}`);
        throw e;
    }
  }

  async embed(text: string): Promise<number[]> {
      return Array(768).fill(0); 
  }

  private log(level: string, message: string) {
      realtimeBus.emit("SYSTEM_LOG", {
          module: "WEBLLM",
          level,
          message
      });
  }
}

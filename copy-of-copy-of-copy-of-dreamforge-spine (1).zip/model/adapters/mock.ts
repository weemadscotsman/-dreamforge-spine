
import { ModelAdapter, PromptPacket, ModelOutput } from '../types';

export class MockAdapter implements ModelAdapter {
  id = "mock";
  backend = "mock";
  capabilities = {
    reasoning: 3,
    speed: 10,
    vision: false,
    tools: false
  };

  async generate(prompt: PromptPacket): Promise<ModelOutput> {
    const cycleMatch = prompt.user.match(/Cycle: (\d+)/);
    const cycle = cycleMatch ? cycleMatch[1] : '0';
    
    const mockContent = `[MOCK_ADAPTER_${cycle}] RESPONSE:
    
Analyzing input: "${prompt.user.substring(0, 30)}..."
System Instruction: ${prompt.system ? "Present" : "None"}

SIMULATED REASONING:
1. Input received.
2. Logic gates verified.
3. Conclusion derived.

RESULT: Validated.`;

    return {
      raw: mockContent,
      modelId: this.id,
      backend: this.backend,
      latencyMs: 45,
      tokensUsed: 50,
      usage: { inputTokens: 20, outputTokens: 30 }
    };
  }

  async embed(text: string): Promise<number[]> {
      const seed = text.length;
      return Array(64).fill(0).map((_, i) => Math.sin(seed * i));
  }
}


import { ModelAdapter, PromptPacket, ModelOutput } from '../types';

type Protocol = 'openai' | 'anthropic' | 'huggingface';

export class UniversalAdapter implements ModelAdapter {
  id: string;
  backend: string;
  protocol: Protocol;
  
  capabilities = {
    reasoning: 8,
    speed: 7,
    vision: false, // Specific impl dependent
    tools: false
  };

  private apiKey: string = '';
  private baseUrl: string = '';
  private modelName: string = '';

  constructor(id: string, protocol: Protocol, defaultBaseUrl: string, defaultModel: string) {
    this.id = id;
    this.backend = id;
    this.protocol = protocol;
    this.baseUrl = defaultBaseUrl;
    this.modelName = defaultModel;
  }

  configure(config: any) {
    // Check for provider-specific config
    if (config.keys && config.keys[this.id]) {
        this.apiKey = config.keys[this.id];
    }
    // Also accept generic apiKey if this is the active provider
    else if (config.apiKey) {
        this.apiKey = config.apiKey;
    }

    if (config.baseUrl) this.baseUrl = config.baseUrl;
    if (config.modelName) this.modelName = config.modelName;
    
    console.log(`[ADAPTER: ${this.id.toUpperCase()}] Configured. Endpoint: ${this.baseUrl}, Model: ${this.modelName}`);
  }

  async generate(prompt: PromptPacket): Promise<ModelOutput> {
    if (!this.apiKey) {
        throw new Error(`[${this.id}] Missing API Key. Configure in Settings.`);
    }

    const start = Date.now();
    
    try {
        if (this.protocol === 'anthropic') {
            return await this.callAnthropic(prompt, start);
        } else if (this.protocol === 'huggingface') {
            return await this.callHuggingFace(prompt, start);
        } else {
            return await this.callOpenAICompatible(prompt, start);
        }
    } catch (e: any) {
        console.error(`[${this.id}] Generation Failed:`, e);
        throw e;
    }
  }

  private async callOpenAICompatible(prompt: PromptPacket, start: number): Promise<ModelOutput> {
      // Mistral, OpenAI, Groq, DeepSeek all follow this pattern
      const url = `${this.baseUrl}/chat/completions`;
      
      const messages = [];
      if (prompt.system) messages.push({ role: 'system', content: prompt.system });
      messages.push({ role: 'user', content: prompt.user });

      const body = {
          model: prompt.model || this.modelName,
          messages: messages,
          temperature: prompt.temperature ?? 0.7,
          max_tokens: prompt.maxTokens ?? 2048,
          stream: false
      };

      const res = await fetch(url, {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${this.apiKey}`
          },
          body: JSON.stringify(body)
      });

      if (!res.ok) {
          const err = await res.text();
          throw new Error(`API Error ${res.status}: ${err}`);
      }

      const data = await res.json();
      const text = data.choices?.[0]?.message?.content || "";
      
      return {
          raw: text,
          latencyMs: Date.now() - start,
          modelId: this.id,
          backend: this.backend,
          usage: {
              inputTokens: data.usage?.prompt_tokens || 0,
              outputTokens: data.usage?.completion_tokens || 0
          }
      };
  }

  private async callAnthropic(prompt: PromptPacket, start: number): Promise<ModelOutput> {
      const url = `${this.baseUrl}/messages`;
      
      const body = {
          model: prompt.model || this.modelName,
          max_tokens: prompt.maxTokens ?? 2048,
          system: prompt.system,
          messages: [{ role: 'user', content: prompt.user }],
          temperature: prompt.temperature ?? 0.7
      };

      const res = await fetch(url, {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json',
              'x-api-key': this.apiKey,
              'anthropic-version': '2023-06-01'
          },
          body: JSON.stringify(body)
      });

      if (!res.ok) {
          const err = await res.text();
          throw new Error(`Anthropic Error ${res.status}: ${err}`);
      }

      const data = await res.json();
      const text = data.content?.[0]?.text || "";

      return {
          raw: text,
          latencyMs: Date.now() - start,
          modelId: this.id,
          backend: this.backend,
          usage: {
              inputTokens: data.usage?.input_tokens || 0,
              outputTokens: data.usage?.output_tokens || 0
          }
      };
  }

  private async callHuggingFace(prompt: PromptPacket, start: number): Promise<ModelOutput> {
      // Uses the Inference API (Serverless) format
      const url = this.baseUrl.includes('models') ? this.baseUrl : `${this.baseUrl}/models/${this.modelName}`;
      
      // HF Inference API usually takes just inputs string for simple models, or structured for conversational
      // Using conversational/text-generation payload
      const body = {
          inputs: `${prompt.system ? `System: ${prompt.system}\n` : ''}User: ${prompt.user}\nAssistant:`,
          parameters: {
              max_new_tokens: prompt.maxTokens ?? 1024,
              temperature: prompt.temperature ?? 0.7,
              return_full_text: false
          }
      };

      const res = await fetch(url, {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${this.apiKey}`
          },
          body: JSON.stringify(body)
      });

      if (!res.ok) {
          const err = await res.text();
          throw new Error(`HF Error ${res.status}: ${err}`);
      }

      const data = await res.json();
      // HF returns array
      const text = Array.isArray(data) ? data[0]?.generated_text : (data.generated_text || JSON.stringify(data));

      return {
          raw: text,
          latencyMs: Date.now() - start,
          modelId: this.id,
          backend: this.backend,
          usage: { inputTokens: 0, outputTokens: 0 } // HF often doesn't return usage
      };
  }
}

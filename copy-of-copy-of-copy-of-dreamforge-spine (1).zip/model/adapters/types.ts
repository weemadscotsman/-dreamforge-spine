import { ModelRequest, ModelResponse } from '../types';

export interface IModelAdapter {
  initialize(): Promise<void>;
  generate(request: ModelRequest): Promise<ModelResponse>;
  configure(config: Record<string, any>): void;
  embed?(text: string): Promise<number[]>;
}
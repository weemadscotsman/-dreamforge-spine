
import { ModelAdapter, PromptPacket, ModelOutput } from '../types';

export class OllamaAdapter implements ModelAdapter {
  id: string;
  backend = "ollama";
  capabilities = {
    reasoning: 7,
    speed: 6,
    vision: true, // [UPDATED] Ollama supports vision models (llava/moondream)
    tools: false
  };

  private endpoint: string = 'http://localhost:11434';
  private modelName: string = 'llama3';

  constructor(id: string = "ollama") {
      this.id = id;
  }

  configure(config: any): void {
    if (config.ollamaUrl) this.endpoint = config.ollamaUrl.replace(/\/$/, "");
    if (config.ollamaModel) this.modelName = config.ollamaModel;
    console.log(`[ADAPTER:${this.id.toUpperCase()}] Configured: ${this.endpoint} -> ${this.modelName}`);
  }

  async generate(prompt: PromptPacket): Promise<ModelOutput> {
    const start = Date.now();
    const url = `${this.endpoint}/api/generate`;
    
    // Inject System Prime if needed
    const system = prompt.system || "You are Dreamforge. Think recursively.";

    try {
        // [NEW] Handle Attachments (Images)
        const images: string[] = [];
        if (prompt.attachments) {
            prompt.attachments.forEach(att => {
                if (att.mimeType.startsWith('image/')) {
                    // Ollama expects base64 strings in the 'images' array
                    images.push(att.data);
                }
            });
        }

        const body: any = {
            model: prompt.model || this.modelName, 
            prompt: prompt.user,
            system: system,
            stream: false,
            // [NEW] JSON Enforcement
            format: prompt.responseFormat === 'json' ? 'json' : undefined,
            options: {
                temperature: prompt.temperature ?? 0.7,
                num_predict: prompt.maxTokens ?? 2048,
                num_ctx: 4096 
            }
        };

        if (images.length > 0) {
            body.images = images;
        }

        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });

        if (!response.ok) {
            throw new Error(`Ollama API Error: ${response.status} ${response.statusText}`);
        }

        const data = await response.json();
        
        // Try parsing JSON if requested
        let jsonOutput = undefined;
        if (prompt.responseFormat === 'json') {
            try {
                jsonOutput = JSON.parse(data.response);
            } catch (e) {
                console.warn("[OLLAMA] Failed to parse JSON output:", data.response);
            }
        }

        return {
            raw: data.response,
            json: jsonOutput,
            latencyMs: Date.now() - start,
            modelId: this.id,
            backend: this.backend,
            tokensUsed: (data.prompt_eval_count || 0) + (data.eval_count || 0),
            usage: {
                inputTokens: data.prompt_eval_count || 0,
                outputTokens: data.eval_count || 0
            }
        };
    } catch (error: any) {
        console.error(`[ADAPTER:${this.id.toUpperCase()}] Failed:`, error);
        
        let msg = `Ollama Connection Failed at ${this.endpoint}.`;
        const errStr = error.message || String(error);
        
        if (errStr.includes('Failed to fetch') || errStr.includes('NetworkError')) {
            msg += " (CORS ERROR or OFFLINE). 1. Check if Ollama is running. 2. Set OLLAMA_ORIGINS=\"*\" env var. 3. Check browser Mixed Content blocking.";
        } else {
            msg += ` ${errStr}`;
        }

        throw new Error(msg);
    }
  }

  async embed(text: string): Promise<number[]> {
      const url = `${this.endpoint}/api/embeddings`;
      try {
          const response = await fetch(url, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                  model: this.modelName,
                  prompt: text
              })
          });
          if (!response.ok) throw new Error("Ollama embed failed");
          const json = await response.json();
          return json.embedding || [];
      } catch (e) {
          // console.warn("Ollama Embed Failed (using zero-vector fallback)", e);
          return Array(64).fill(0); 
      }
  }
}


import { IModelDriver, ModelRequest, ModelResponse, ModelProvider, PromptPacket } from './types';
import { modelRegistry } from './registry';
import { GeminiAdapter } from './adapters/gemini';
import { OllamaAdapter } from './adapters/ollama';
import { UniversalAdapter } from './adapters/universal';
import { WebLLMAdapter } from './adapters/webllm'; // [NEW]
import { MockAdapter } from './adapters/mock';
import { realtimeBus } from '../bridge/realtime_bus';

/**
 * [MODEL] DRIVER
 * Wrapper around ModelRegistry to maintain IModelDriver interface for the rest of the app.
 * Handles configuration and failover.
 */
export class ModelDriver implements IModelDriver {
  
  constructor() {
    // Google
    modelRegistry.register(new GeminiAdapter('gemini-flash', 'gemini-3-flash-preview'));
    modelRegistry.register(new GeminiAdapter('gemini-pro', 'gemini-3-pro-preview'));
    
    // Local
    modelRegistry.register(new OllamaAdapter('ollama')); // Main
    modelRegistry.register(new OllamaAdapter('ollama_alpha'));
    modelRegistry.register(new OllamaAdapter('ollama_beta'));
    modelRegistry.register(new OllamaAdapter('ollama_gamma'));
    modelRegistry.register(new OllamaAdapter('ollama_delta'));

    modelRegistry.register(new WebLLMAdapter()); // [NEW]
    
    // Universal / External
    modelRegistry.register(new UniversalAdapter('openai', 'openai', 'https://api.openai.com/v1', 'gpt-4o'));
    modelRegistry.register(new UniversalAdapter('anthropic', 'anthropic', 'https://api.anthropic.com/v1', 'claude-3-5-sonnet-20240620'));
    modelRegistry.register(new UniversalAdapter('mistral', 'openai', 'https://api.mistral.ai/v1', 'mistral-large-latest'));
    modelRegistry.register(new UniversalAdapter('huggingface', 'huggingface', 'https://api-inference.huggingface.co', 'meta-llama/Meta-Llama-3-8B-Instruct'));

    // Test
    modelRegistry.register(new MockAdapter());

    // Default active
    modelRegistry.setActive('gemini-flash');
  }

  async initialize(): Promise<void> {
    console.log('[MODEL] Driver Initializing...');
    // We do NOT await webllm init here as it is heavy
    const ids = ['gemini-flash', 'gemini-pro', 'ollama', 'openai', 'anthropic', 'mistral', 'huggingface', 'mock', 'webllm'];
    for (const id of ids) {
        const adapter = modelRegistry.get(id);
        if (adapter && 'initialize' in adapter) {
            await (adapter as any).initialize();
        }
    }
  }

  configure(config: { 
      provider?: string; 
      ollamaUrl?: string; 
      ollamaModel?: string;
      ollamaSwarm?: Record<string, string>; // [NEW] Swarm config
      apiKey?: string; 
      baseUrl?: string; 
      modelName?: string;
      keys?: Record<string, string>;
  }): void {
    
    // 1. Set Active Provider
    if (config.provider) {
        let targetId = 'gemini-flash';
        if (config.provider === ModelProvider.GEMINI_PRO) targetId = 'gemini-pro';
        else if (config.provider === ModelProvider.OLLAMA) targetId = 'ollama';
        else if (config.provider === ModelProvider.OPENAI) targetId = 'openai';
        else if (config.provider === ModelProvider.ANTHROPIC) targetId = 'anthropic';
        else if (config.provider === ModelProvider.MISTRAL) targetId = 'mistral';
        else if (config.provider === ModelProvider.HUGGINGFACE) targetId = 'huggingface';
        else if (config.provider === ModelProvider.WEBLLM) targetId = 'webllm';
        else if (config.provider === ModelProvider.MOCK) targetId = 'mock';
        
        modelRegistry.setActive(targetId);
    }

    // 2. Propagate Generic API Key (Legacy/Active Support)
    if (config.apiKey) {
        const active = modelRegistry.getActive();
        if (active.configure) active.configure({ apiKey: config.apiKey });
    }

    // 3. Propagate Specific Keys Map
    if (config.keys) {
        Object.entries(config.keys).forEach(([provider, key]) => {
            const adapter = modelRegistry.get(provider);
            if (adapter && adapter.configure) {
                adapter.configure({ apiKey: key });
            }
        });
    }

    // 4. Provider Specific Configs
    const active = modelRegistry.getActive();
    if (active.configure) {
        active.configure({
            ollamaUrl: config.ollamaUrl,
            ollamaModel: config.ollamaModel,
            baseUrl: config.baseUrl,
            modelName: config.modelName
        });
    }

    // 5. [NEW] Configure Swarm Adapters
    // Only applies if user passed swarm config
    if (config.ollamaSwarm) {
        Object.entries(config.ollamaSwarm).forEach(([role, url]) => {
            if (!url) return; // Skip empty
            const id = `ollama_${role.toLowerCase()}`;
            const adapter = modelRegistry.get(id);
            if (adapter && adapter.configure) {
                adapter.configure({ 
                    ollamaUrl: url,
                    ollamaModel: config.ollamaModel // Use global model for now, could be specific later
                });
            }
        });
    }
    
    realtimeBus.emit("SYSTEM_LOG", { 
        module: "MODEL", 
        level: "INFO", 
        message: `Configured. Active: ${modelRegistry.getActive().id}` 
    });
  }

  getProvider(): string {
    return modelRegistry.getActive().id;
  }

  async generate(request: ModelRequest): Promise<ModelResponse> {
    // 1. Map Request to PromptPacket
    const packet: PromptPacket = {
        user: request.prompt,
        system: request.configOverride?.systemInstruction,
        attachments: request.attachments,
        temperature: request.configOverride?.temperature,
        maxTokens: request.configOverride?.maxOutputTokens,
        model: request.configOverride?.model, // Pass specific model override
    };

    // 2. Determine Adapter
    let adapter = modelRegistry.getActive();
    if (request.configOverride?.provider) {
        const override = modelRegistry.get(request.configOverride.provider);
        if (override) adapter = override;
    }

    // INSPECTION POINT: Log configuration used
    realtimeBus.emit("SYSTEM_LOG", { 
        module: "MODEL", 
        level: "INFO", 
        message: `Inference Start [${adapter.id}]`,
        data: { 
            tokens: request.prompt.length / 4, 
            modelOverride: packet.model,
            backend: adapter.backend
        }
    });

    // 3. Execute with Failover
    try {
        const result = await this.executeGenerate(adapter, packet, request.id);
        
        // EMIT HEARTBEAT END
        realtimeBus.emit("SYSTEM_LOG", { 
            module: "MODEL", 
            level: "INFO", 
            message: `Inference Complete (${result.latency}ms)`,
            data: { usage: result.usage }
        });

        return result;

    } catch (error: any) {
        // ERROR INSPECTION
        const errMessage = error?.message || String(error);
        
        realtimeBus.emit("SYSTEM_LOG", { 
            module: "MODEL", 
            level: "ERROR", // Upgrade to ERROR for Terminal visibility
            message: `Failure on ${adapter.id}: ${errMessage}`,
            data: error // Pass full error object for inspection in Terminal
        });
        
        // FAILOVER LOGIC
        // If critical failure, drop to Mock to keep UI alive in demo
        if (errMessage && (
            errMessage.includes('429') || 
            errMessage.includes('quota') || 
            errMessage.includes('Failed to fetch') || 
            errMessage.includes('NetworkError') ||
            errMessage.includes('Connection Failed')
        )) {
             realtimeBus.emit("SYSTEM_LOG", { module: "MODEL", level: "WARN", message: "Connection/Quota Issue. Switching to MOCK." });
             const mock = modelRegistry.get('mock');
             if (mock) return this.executeGenerate(mock, packet, request.id);
        }

        // Final Fallback
        return {
            requestId: request.id,
            content: `Error (${adapter.id}): ${errMessage}`,
            raw: null,
            usage: { inputTokens: 0, outputTokens: 0 },
            latency: 0
        };
    }
  }

  private async executeGenerate(adapter: any, packet: PromptPacket, requestId: string): Promise<ModelResponse> {
      const output = await adapter.generate(packet);
      return {
          requestId: requestId,
          content: output.raw,
          raw: output,
          usage: output.usage || { inputTokens: 0, outputTokens: 0 },
          latency: output.latencyMs || 0
      };
  }

  async embed(text: string): Promise<number[]> {
    const adapter = modelRegistry.getActive();
    const mock = modelRegistry.get('mock');

    if (!adapter.embed) {
        if (mock && mock.embed) return mock.embed(text);
        return [];
    }

    try {
        const res = await adapter.embed(text);
        if (!res || res.length === 0) throw new Error("Empty embedding");
        return res;
    } catch (e) {
        // Silent failover for embeddings to prevent UI crash
        if (mock && mock.embed) return mock.embed(text);
        return [];
    }
  }

  isStub(): boolean {
    return modelRegistry.getActive().id === 'mock';
  }

  async completeJSON(payload: { role: string; task: string; input: string }): Promise<{ text: string }> {
    const prompt = `
[SYSTEM_PROTOCOL: JSON_ENFORCEMENT]
ROLE: ${payload.role}
TASK: ${payload.task}

INPUT CONTEXT:
"""
${payload.input}
"""

INSTRUCTION:
Analyze the input based on your role.
Return your response STRICTLY as a JSON object with a single key "text".
Do not add markdown formatting or explanations outside the JSON.

FORMAT:
{ "text": "Your analysis here..." }
    `.trim();

    try {
      const response = await this.generate({
        id: crypto.randomUUID(),
        prompt: prompt,
        configOverride: {
          temperature: 0.3,
          maxOutputTokens: 1024
        }
      });

      const raw = response.content;
      const clean = raw.replace(/```json/g, '').replace(/```/g, '').trim();
      
      try {
        const parsed = JSON.parse(clean);
        return { text: parsed.text || raw };
      } catch (e) {
        return { text: raw };
      }
    } catch (e) {
      return { text: `Driver Error: ${e instanceof Error ? e.message : String(e)}` };
    }
  }
}


import { ModelAdapter } from "./types";

class ModelRegistry {
  private adapters = new Map<string, ModelAdapter>();
  private activeModelId: string | null = null;

  register(adapter: ModelAdapter) {
    this.adapters.set(adapter.id, adapter);
    if (!this.activeModelId) {
      this.activeModelId = adapter.id;
    }
    console.log(`[REGISTRY] Registered adapter: ${adapter.id}`);
  }

  setActive(id: string) {
    if (!this.adapters.has(id)) {
        console.warn(`[REGISTRY] Model ${id} not found. Keeping ${this.activeModelId}`);
        return;
    }
    this.activeModelId = id;
    console.log(`[REGISTRY] Active model switched to: ${id}`);
  }

  getActive(): ModelAdapter {
    if (!this.activeModelId || !this.adapters.has(this.activeModelId)) {
      // Fallback
      const fallback = this.adapters.keys().next().value;
      if (fallback) return this.adapters.get(fallback)!;
      throw new Error("No active model set and registry is empty");
    }
    return this.adapters.get(this.activeModelId)!;
  }

  get(id: string): ModelAdapter | undefined {
      return this.adapters.get(id);
  }

  list() {
    return [...this.adapters.values()].map(a => ({
      id: a.id,
      backend: a.backend,
      capabilities: a.capabilities
    }));
  }
}

export const modelRegistry = new ModelRegistry();

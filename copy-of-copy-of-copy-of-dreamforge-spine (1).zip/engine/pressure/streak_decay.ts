
// engine/pressure/streak_decay.ts
// AKA: The Fever Engine
// Tracks adversarial momentum and converts it to system temperature.

import { realtimeBus } from "../../bridge/realtime_bus";

let challengerStreak = 0;
let candidateStreak = 0;
let systemHeat = 0.0; // 0.0 (Cold/Stable) -> 1.0 (Meltdown/Chaotic)

const HEAT_DECAY = 0.05;
const HEAT_SPIKE = 0.15;

export function registerWinner(role: "candidate" | "challenger") {
  if (role === "challenger") {
    challengerStreak++;
    candidateStreak = 0;
    // Challenger wins increase entropy/heat
    systemHeat = Math.min(1.0, systemHeat + HEAT_SPIKE);
  } else {
    candidateStreak++;
    challengerStreak = 0;
    // Candidate wins stabilize the system (cool down)
    systemHeat = Math.max(0.0, systemHeat - HEAT_DECAY);
  }

  realtimeBus.emit("PRESSURE_CURVE", { slope: systemHeat });
  
  // Modal Bleed: High heat triggers nervous system events
  if (systemHeat > 0.6) {
    realtimeBus.emit("UNCERTAINTY_DELTA", { delta: systemHeat });
  }
}

export function getSystemTemperature(): number {
  // Returns a multiplier for LLM temperature
  // Heat 0.0 -> 1.0x (Standard)
  // Heat 1.0 -> 2.5x (Fever)
  return 1.0 + (systemHeat * 1.5);
}

export function getHeatLevel(): number {
  return systemHeat;
}

export function getChallengerWins() {
    return challengerStreak;
}

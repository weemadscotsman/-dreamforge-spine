
// Dreamforge Spine – Hypothesis Ledger
// persistent belief state tracking:
// true | unproven | disproven | reinforced | resurrected

import { PrincipleSet } from "../principles/extract_principles";
import { SymbolicEntry } from "../symbolic/symbolic_cache";
import { realtimeBus } from "../../bridge/realtime_bus";

export type HypothesisStatus =
  | "true"
  | "unproven"
  | "disproven"
  | "reinforced"
  | "resurrected"
  | "reinforced_scarred" // [PHASE 9]
  | "disproven_scarred"  // [PHASE 9]
  | "rotted";            // [NEW] Died of neglect (entropy)

export interface HypothesisRecord {
  id: string;           // unique identifier or hash from symbolic layer
  statement: string;    // actual hypothesis or axiom line
  status: HypothesisStatus;
  strength: number;     // increment when survives challenges
  lastUpdate: number;   // unix stamp
  deaths: number;       // [PHASE 9] Persistence of failure count
  notes?: string;       // human-readable overlay later
  origin?: string;      // where did this come from (cycle, lesion-return, etc)
}

export class HypothesisLedger {
  private ledger: Map<string, HypothesisRecord> = new Map();
  private broadcastTimer: any = null;

  constructor() {}

  private broadcast() {
      // Debounce updates to prevent UI flood (300ms)
      if (this.broadcastTimer) clearTimeout(this.broadcastTimer);
      this.broadcastTimer = setTimeout(() => {
          realtimeBus.emit('BELIEFS_UPDATE', this.getBeliefs());
          this.broadcastTimer = null;
      }, 300);
  }

  // update beliefs based on principle extraction + symbolic reuse
  // Returns list of newly disproven beliefs to feed the Lesion Map
  updateFromCycle(
    principles: PrincipleSet,
    symbol: SymbolicEntry,
    cycleWinner: "candidate" | "challenger"
  ): HypothesisRecord[] {
    const now = Date.now();
    const disprovenBatch: HypothesisRecord[] = [];

    // treat axioms as candidate assertions of truth
    for (const ax of principles.axioms) {
      const axiomHash = this.simpleHash(ax); 
      const id = `${symbol.id}:${axiomHash}`;
      
      const existing = this.ledger.get(id);

      if (existing) {
        // survived another cycle? -> reinforced
        if (cycleWinner === "candidate") {
          // [PHASE 9] SCAR LOGIC
          if (existing.deaths > 0) {
              existing.status = "reinforced_scarred";
              // Apply scar penalty to strength gain (diminishing returns for scarred beliefs)
              const scarPenalty = Math.min(0.8, 0.15 * existing.deaths); 
              existing.strength += (1 - scarPenalty); 
          } else {
              // If it was rotted, it is now resurrected/reinforced
              existing.status = existing.status === 'resurrected' ? 'resurrected' : 'reinforced';
              existing.strength += 1;
          }
        }
        existing.lastUpdate = now;
      } else {
        // NEW BELIEF
        const isDisprovenStart = cycleWinner === "challenger";
        this.ledger.set(id, {
          id,
          statement: ax,
          status: isDisprovenStart ? "disproven" : "unproven", 
          strength: isDisprovenStart ? 0 : 1,
          lastUpdate: now,
          deaths: isDisprovenStart ? 1 : 0, // Starts dead if challenger won immediately
          origin: `cycle-new`
        });
      }
    }

    // contradictions observed -> weaken claims touching them
    if (principles.contradictions.length > 0) {
      for (const [id, record] of this.ledger.entries()) {
        if (record.statement && principles.contradictions.some(c => record.statement.includes(c))) {
          // If it was already disproven, we don't need to kill it again
          if (!record.status.includes('disproven') && record.status !== 'rotted') {
              // [PHASE 9] MARK DEATH
              record.deaths = (record.deaths || 0) + 1;
              record.status = record.deaths > 1 ? "disproven_scarred" : "disproven";
              
              record.strength = Math.max(0, record.strength - 2); // Heavy penalty
              record.lastUpdate = now;
              disprovenBatch.push(record);
          }
        }
      }
    }
    
    this.broadcast();
    return disprovenBatch;
  }

  /**
   * [NEW] Direct Injection for Dataset Loader
   */
  injectExternal(data: { statement: string, confidence: number, source: string }) {
      const id = this.simpleHash(data.statement);
      const existing = this.ledger.get(id);
      
      if (existing) {
          // Reinforce existing
          existing.strength += data.confidence;
          existing.lastUpdate = Date.now();
          if (existing.status === 'rotted') existing.status = 'resurrected';
      } else {
          // Create new
          this.ledger.set(id, {
              id,
              statement: data.statement,
              status: 'unproven', // Starts unproven until a cycle validates it
              strength: data.confidence, // Initial mass based on dataset confidence
              lastUpdate: Date.now(),
              deaths: 0,
              origin: data.source
          });
      }
      this.broadcast();
  }

  /**
   * [NEW] ENTROPY
   * Beliefs must pay rent. If they aren't reinforced, they decay.
   * This prevents the "Heap of Truth" problem where everything eventually becomes true.
   */
  applyEntropy() {
      const now = Date.now();
      for (const rec of this.ledger.values()) {
          // Dead beliefs don't decay, they just sit in the grave (or LesionMap)
          if (rec.status.includes('disproven') || rec.status === 'rotted') continue;

          // Decay Rate depends on status
          let decay = 0.05; // Base decay
          
          if (rec.status === 'reinforced') decay = 0.02; // Slow rot
          if (rec.status === 'unproven') decay = 0.15;   // Fast rot
          if (rec.status === 'resurrected') decay = 0.10; 
          
          rec.strength -= decay;

          // DEATH BY NEGLECT
          if (rec.strength <= 0) {
              rec.strength = 0;
              rec.status = 'rotted';
              rec.lastUpdate = now;
          }
      }
      this.broadcast();
  }

  // [PHASE 9] Adaptive Rescore
  // Applies historical weight of failure to current confidence
  rescoreAll() {
      for (const rec of this.ledger.values()) {
          if (rec.deaths > 0) {
              const deathWeight = Math.min(0.6, rec.deaths * 0.15);
              rec.strength = Math.max(0, rec.strength - deathWeight);
              
              // Ensure visual status matches reality
              if (rec.strength > 0 && !rec.status.includes('disproven') && rec.status !== 'rotted') {
                  rec.status = 'reinforced_scarred';
              }
          }
      }
      this.broadcast();
  }

  /**
   * [NEW] FRAGMENTATION
   * Force entropy into the belief system. Used when a draw/contradiction cannot be resolved.
   * Reduces mass of all reinforced beliefs.
   */
  fragment() {
      for (const rec of this.ledger.values()) {
          if (rec.status === 'reinforced' || rec.status === 'reinforced_scarred') {
              rec.strength *= 0.7; // 30% Mass Loss
              if (rec.strength < 0.5) {
                  rec.status = 'unproven'; // Degrade status
              }
          }
      }
      this.broadcast();
  }

  // Called by LesionMap to bring a ghost back to life
  injectResurrectedBelief(record: HypothesisRecord) {
      // Ensure we merge with existing state if ID collision, preserving death count
      const existing = this.ledger.get(record.id);
      if (existing) {
          record.deaths = Math.max(record.deaths, existing.deaths);
      }
      this.ledger.set(record.id, record);
      this.broadcast();
  }

  getBeliefs(status?: HypothesisStatus): HypothesisRecord[] {
    const all = Array.from(this.ledger.values());
    if (!status) return all;
    return all.filter(r => r.status === status);
  }

  strongestBeliefs(n = 10): HypothesisRecord[] {
    return Array.from(this.ledger.values())
      .filter(r => !r.status.includes('disproven') && r.status !== 'rotted') // Exclude dead
      .sort((a, b) => b.strength - a.strength)
      .slice(0, n);
  }

  reinforcedCount(): number {
    return Array.from(this.ledger.values()).filter(r => r.status.includes('reinforced') || r.status === 'resurrected').length;
  }

  private simpleHash(str: string): string {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    return Math.abs(hash).toString(16);
  }
}

export const ledger = new HypothesisLedger();

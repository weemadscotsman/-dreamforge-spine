// Dreamforge Spine – Principle Extraction Layer
// brutally strips narrative output into reusable logical structure

import { stripMarkdown } from "../utils/strip_markdown";

export interface PrincipleSet {
  axioms: string[];
  constraints: string[];
  contradictions: string[];
  missingProofs: string[];
  raw: string;
}

const AXIOM_MARKERS = ["axiom", "Axiom", "AXIOM"];
const CONSTRAINT_MARKERS = ["constraint", "rule", "must", "cannot"];
const CONTRADICTION_MARKERS = ["contradiction", "inconsistent", "conflict"];
const MISSING_PROOF_MARKERS = ["unproven", "missing proof", "needs proof", "why?"];

// normalize a line so we aren't parsing formatting vibes
function normalize(line: string): string {
  return line.trim().replace(/^[-*+]/, "").replace(/\*\*/g, "").replace(/\#/g, "").trim();
}

// dumb but effective line classifier (until symbolic_cache takes over)
function classify(line: string): keyof PrincipleSet | null {
  const low = line.toLowerCase();

  if (AXIOM_MARKERS.some(m => low.includes(m.toLowerCase()))) return "axioms";
  if (CONSTRAINT_MARKERS.some(m => low.includes(m.toLowerCase()))) return "constraints";
  if (CONTRADICTION_MARKERS.some(m => low.includes(m.toLowerCase()))) return "contradictions";
  if (MISSING_PROOF_MARKERS.some(m => low.includes(m.toLowerCase()))) return "missingProofs";

  return null;
}

export function extractPrinciples(output: string): PrincipleSet {
  const raw = stripMarkdown(output);
  const lines = raw.split("\n").map(normalize).filter(Boolean);

  const principles: PrincipleSet = {
    axioms: [],
    constraints: [],
    contradictions: [],
    missingProofs: [],
    raw
  };

  for (const line of lines) {
    const bucket = classify(line);
    if (!bucket) continue;
    (principles[bucket] as string[]).push(line);
  }

  return principles;
}
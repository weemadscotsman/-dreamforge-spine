
export const EvaluatorConfig = {
  weights: {
    // Tuned for Rigor:
    // Logic/Truth > Obedience/Style
    TASK_FIT: 0.15,          // Reduced: Don't just parrot the prompt
    CONSISTENCY: 0.30,       // Increased: Internal logic must hold
    FACTUALITY: 0.35,        // Primary: Grounding is key
    CONSTRAINT_MATCH: 0.15,  // Maintenance: Adhere to system rules
    STYLE_MATCH: 0.05        // Minimal: Content over form
  },
  retrieval: {
    top_k: 8,
    min_similarity: 0.65
  },
  scoring: {
    max_score: 100,
    pass_threshold: 82,       // Adjusted: "Smart" unwrap. Zero fake passes.
    noDataDefault: 0.5,       // [PATCH-009] Conservative uncertainty
    contradictionPenalty: 0.3 // [PATCH-009] Heavy penalty for hedging
  }
};

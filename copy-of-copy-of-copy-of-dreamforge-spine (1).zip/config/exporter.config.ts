export const ExporterConfig = {
  output: {
    ft_format: "jsonl",
    max_samples: 2000,
    min_score: 0.45          // Adjusted: Signal tolerance, not protection.
  },
  formatting: {
    include_metadata: true,
    include_signature: true,
    clean_identity_hints: true
  }
};
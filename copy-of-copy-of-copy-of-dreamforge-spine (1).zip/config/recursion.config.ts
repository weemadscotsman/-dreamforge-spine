
export const RecursionConfig = {
  cycles: {
    max_cycles: 5,           // Reduced for prototype speed
    early_stop_plateau: 2,   // Stop if no meaningful improvement after N cycles
    min_score_delta: 0.02    // Improvement threshold per cycle
  },
  thresholds: {
    retry: 0.4,              // Scores below this trigger a retry (rejection)
    continue: 0.85,          // Scores below this trigger refinement
    description: "Scores below retry trigger new attempt, below continue trigger refinement"
  },
  behavior: {
    save_each_cycle: true,
    export_checkpoint_on_halt: true
  },
  logging: {
    dir: "recursor_logs" // Virtual path for UI/Exporter
  }
};

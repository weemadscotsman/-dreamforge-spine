
export const MemoryConfig = {
  limits: {
    short_term_max: 50,      // most recent evaluated outputs stored raw
    long_term_max: 500       // compressed chunks retained
  },
  pruning: {
    min_relevance_for_retention: 0.42,
    compression_trigger: 20  // compress when short-term hits this count
  },
  compression: {
    algorithm: "semantic_cluster",   // placeholder method
    chunk_size: 120                  // word count target after compression
  },
  longTerm: {
    decayRate: 0.99, // 1% per hour
    decayRatePerHour: 0.01,
    description: "Memory scores decay by this factor per hour"
  },
  export: {
    checkpoint_dir: "checkpoints",
    embed_signatures: true
  }
};

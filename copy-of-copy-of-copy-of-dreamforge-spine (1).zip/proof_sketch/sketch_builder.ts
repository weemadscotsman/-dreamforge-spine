import { ArgumentStructure } from "../argument_builder/types";
import { ReasoningGraph } from "../graph_reasoning/types";
import { selectStrategy } from "./strategy";
import { stripParens } from "../argument_builder/utils";

export interface ProofSketch {
  goal: string;
  strategy: string;
  requiredPremises: string[];
  missingLinks: string[];
  nextInferenceTargets: string[];
  pathHint: string;
}

export const buildSketch = (
  arg: ArgumentStructure,
  graph: ReasoningGraph
): ProofSketch => {
  const goal = stripParens(arg.conclusion.expr);
  const strategy = selectStrategy(graph);

  const premiseLabels = arg.premises.map(p => stripParens(p.expr));
  const available = graph.nodes.map(n => stripParens(n.label));

  const requiredPremises = premiseLabels;

  // missing links: elements in simplified conclusion not directly in premises or graph
  const simplifiedParts = arg.simplifiedConclusion.split(/&|\||->/).map(s => s.trim());
  const missingLinks = simplifiedParts.filter(part => !available.includes(part));

  const nextInferenceTargets = missingLinks.length > 0
    ? missingLinks
    : [goal];

  const pathHint =
    strategy === "contradiction"
      ? `assume ¬(${goal}) and derive contradiction`
      : strategy === "induction"
      ? `prove base case for (${goal.replace(/[nij]/g, "0")}), then inductive step`
      : `compose premises to reach (${goal})`;

  return {
    goal,
    strategy,
    requiredPremises,
    missingLinks,
    nextInferenceTargets,
    pathHint
  };
};
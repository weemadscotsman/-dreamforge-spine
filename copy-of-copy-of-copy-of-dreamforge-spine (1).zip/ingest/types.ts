export interface IngestResult {
  filename: string;
  mimeType: string;
  dataType: 'TEXT' | 'BASE64';
  data: string; // The text content or base64 string
  isCheckpointCandidate?: boolean; // Helper flag for JSON restoration
}

export interface IIngestService {
  process(file: File): Promise<IngestResult>;
}

import { FileNode, VFSState } from './types';

const STORAGE_KEY = 'dreamforge_vfs_v1';

export class VirtualFileSystem {
  private state: VFSState;

  constructor() {
    this.state = this.load() || {
      root: {
        name: 'root',
        type: 'dir',
        updatedAt: Date.now(),
        children: [
          { name: 'workspace', type: 'dir', updatedAt: Date.now(), children: [] },
          { name: 'logs', type: 'dir', updatedAt: Date.now(), children: [] },
          { name: 'readme.txt', type: 'file', updatedAt: Date.now(), content: "DREAMFORGE LOCAL AGENT\nWorkspace Initialized." }
        ]
      }
    };
  }

  // --- IO Operations ---

  writeFile(path: string, content: string): string {
    const parts = this.parsePath(path);
    const fileName = parts.pop();
    if (!fileName) throw new Error("Invalid path");

    const dir = this.navigate(parts, true);
    if (!dir || dir.type !== 'dir') throw new Error(`Directory not found: ${parts.join('/')}`);

    const existing = dir.children!.find(c => c.name === fileName);
    if (existing) {
      if (existing.type !== 'file') throw new Error(`Cannot write to directory: ${fileName}`);
      existing.content = content;
      existing.updatedAt = Date.now();
    } else {
      dir.children!.push({
        name: fileName,
        type: 'file',
        content,
        updatedAt: Date.now()
      });
    }
    this.save();
    return `Wrote ${content.length} bytes to ${path}`;
  }

  appendFile(path: string, content: string): string {
    const parts = this.parsePath(path);
    const fileName = parts.pop();
    if (!fileName) throw new Error("Invalid path");

    const dir = this.navigate(parts, true);
    if (!dir || dir.type !== 'dir') throw new Error(`Directory not found: ${parts.join('/')}`);

    const existing = dir.children!.find(c => c.name === fileName);
    if (existing) {
      if (existing.type !== 'file') throw new Error(`Cannot write to directory: ${fileName}`);
      existing.content = (existing.content || "") + content;
      existing.updatedAt = Date.now();
    } else {
      dir.children!.push({
        name: fileName,
        type: 'file',
        content: content,
        updatedAt: Date.now()
      });
    }
    this.save();
    return `Appended to ${path}`;
  }

  readFile(path: string): string {
    const parts = this.parsePath(path);
    const fileName = parts.pop();
    const dir = this.navigate(parts);
    const node = dir?.children?.find(c => c.name === fileName);

    if (!node || node.type !== 'file') throw new Error(`File not found: ${path}`);
    return node.content || "";
  }

  listFiles(path: string): string {
    const parts = this.parsePath(path);
    const dir = this.navigate(parts);
    if (!dir || dir.type !== 'dir') throw new Error(`Invalid directory: ${path}`);
    
    return dir.children!.map(c => 
      `${c.type === 'dir' ? '[DIR]' : '[FILE]'} ${c.name} (${c.type === 'file' ? c.content?.length + 'b' : c.children?.length + ' items'})`
    ).join('\n');
  }

  deleteFile(path: string): string {
    const parts = this.parsePath(path);
    const fileName = parts.pop();
    const dir = this.navigate(parts);
    
    const idx = dir?.children?.findIndex(c => c.name === fileName);
    if (idx === undefined || idx === -1) throw new Error(`File not found: ${path}`);
    
    dir!.children!.splice(idx, 1);
    this.save();
    return `Deleted ${path}`;
  }

  // --- Helpers ---

  private parsePath(path: string): string[] {
    return path.split('/').filter(p => p && p !== '.' && p !== 'root');
  }

  private navigate(parts: string[], create = false): FileNode | null {
    let current = this.state.root;
    for (const part of parts) {
      let next = current.children?.find(c => c.name === part);
      if (!next && create) {
        next = { name: part, type: 'dir', updatedAt: Date.now(), children: [] };
        current.children!.push(next);
      }
      if (!next) return null;
      current = next;
    }
    return current;
  }

  private save() {
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(this.state));
      } catch (e) {
        console.warn("VFS Save Failed (Quota?)", e);
      }
    }
  }

  private load(): VFSState | null {
    if (typeof window !== 'undefined') {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) return JSON.parse(raw);
    }
    return null;
  }

  getTree(): FileNode {
    return this.state.root;
  }
}

export const vfs = new VirtualFileSystem();


import { ToolDefinition, ToolResult } from './types';
import { vfs } from './vfs';

// 🔒 SECURITY GATE: ARBITRARY EXECUTION
// Must be false in production. 
const ALLOW_DEFINITION_EVAL = process.env.NODE_ENV === 'development' && process.env.ALLOW_DEFINITION_EVAL === 'true';

export const TOOLS: ToolDefinition[] = [
  {
    name: 'fs_write',
    description: 'Write content to a file in the workspace. Overwrites if exists.',
    schema: '{"path": "string", "content": "string"}',
    execute: async (args: any) => {
      try {
        const msg = vfs.writeFile(args.path, args.content);
        return { success: true, output: msg };
      } catch (e: any) {
        return { success: false, output: e.message };
      }
    }
  },
  {
    name: 'fs_read',
    description: 'Read content from a file.',
    schema: '{"path": "string"}',
    execute: async (args: any) => {
      try {
        const content = vfs.readFile(args.path);
        return { success: true, output: content };
      } catch (e: any) {
        return { success: false, output: e.message };
      }
    }
  },
  {
    name: 'fs_list',
    description: 'List files in a directory.',
    schema: '{"path": "string"}',
    execute: async (args: any) => {
      try {
        const list = vfs.listFiles(args.path || '/');
        return { success: true, output: list };
      } catch (e: any) {
        return { success: false, output: e.message };
      }
    }
  },
  {
    name: 'run_script',
    description: 'Execute JavaScript code. WARNING: Sandboxed environment.',
    schema: '{"code": "string"}',
    execute: async (args: any) => {
      if (!ALLOW_DEFINITION_EVAL) {
          console.warn("[SECURITY] Dynamic code execution blocked");
          return { success: false, output: "EXECUTION_DENIED: Security Policy (ALLOW_DEFINITION_EVAL=false)" };
      }
      
      try {
        console.warn("[TOOLS] Executing script tool...");
        // Use Function constructor for sandboxed-ish execution
        const fn = new Function(args.code);
        const result = fn();
        return { success: true, output: `Executed. Result: ${result}` };
      } catch (e: any) {
        return { success: false, output: `Runtime Error: ${e.message}` };
      }
    }
  }
];


import { ToolDefinition, ToolResult } from './types';
import { TOOLS } from './definitions';

export class ToolRegistry {
  private tools: Map<string, ToolDefinition> = new Map();

  constructor() {
    TOOLS.forEach(t => this.register(t));
  }

  register(tool: ToolDefinition) {
    this.tools.set(tool.name, tool);
  }

  get(name: string): ToolDefinition | undefined {
    return this.tools.get(name);
  }

  listDefs(): string {
    return Array.from(this.tools.values()).map(t => 
      `- ${t.name}: ${t.description} (Args: ${t.schema})`
    ).join('\n');
  }

  async execute(name: string, args: any): Promise<ToolResult> {
    const tool = this.tools.get(name);
    if (!tool) return { success: false, output: `Tool not found: ${name}` };
    
    try {
      return await tool.execute(args);
    } catch (e: any) {
      return { success: false, output: `Execution failure: ${e.message}` };
    }
  }
}

export const registry = new ToolRegistry();

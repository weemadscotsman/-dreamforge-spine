
export type HumanSignal =
  | { type: 'PRESENCE'; active: boolean }
  | { type: 'INPUT'; device: 'keyboard' | 'mouse' }
  | { type: 'FOCUS'; window: string }
  | { type: 'IDLE'; seconds: number }
  | { type: 'INTERRUPT' };

export interface HumanEvent {
  signal: HumanSignal;
  timestamp: number;
}

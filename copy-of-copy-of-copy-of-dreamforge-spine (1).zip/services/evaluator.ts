
export const DELETED = true;
// This module has been deprecated and archived.
// Use core/judge.ts instead.

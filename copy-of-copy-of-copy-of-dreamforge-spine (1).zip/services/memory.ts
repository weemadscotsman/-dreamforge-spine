
export const DELETED = true;
// This module has been deprecated and archived.
// Use memory/memory_core.ts instead.

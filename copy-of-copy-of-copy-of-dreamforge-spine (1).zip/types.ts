
/**
 * DREAMFORGE SPINE // TYPE DEFINITIONS
 * 
 * Defines the contract for data flowing between:
 * [MODEL] <-> [BRIDGE] <-> [RECURSOR]
 */

// --- CORE PRIMITIVES ---

export type UUID = string;
export type Timestamp = number;

// --- MODEL LAYER ---

export enum ModelProvider {
  GEMINI_FLASH = 'gemini-3-flash-preview',
  GEMINI_PRO = 'gemini-3-pro-preview',
  OLLAMA = 'ollama',
  MOCK = 'mock'
}

export interface ModelConfig {
  provider: ModelProvider;
  temperature: number;
  maxTokens: number;
  topP?: number;
  topK?: number;
  systemInstruction?: string;
  apiKey?: string;
  ingest?: {
    enabled: boolean;
    watchDirectory: string;
    supportedFormats: string[];
    chunkingStrategy: {
      size: number;
      overlap: number;
    };
  };
}

export interface ModelResponse {
  content: string;
  usage: {
    promptTokens: number;
    completionTokens: number;
  };
  latencyMs: number;
}

// --- MEMORY LAYER ---

export interface MemoryNode {
  id: UUID;
  content: string;
  embedding?: number[];
  tags: string[];
  createdAt: Timestamp;
  coherenceScore: number;
}

export interface MemoryQuery {
  semanticQuery?: string;
  tags?: string[];
  limit?: number;
  minCoherence?: number;
}

// --- RECURSION & EVALUATION ---

export enum TraceStatus {
  PENDING = 'PENDING',
  RECURSING = 'RECURSING',
  STABILIZED = 'STABILIZED',
  REJECTED = 'REJECTED'
}

export interface EvaluationResult {
  evaluatorId: string;
  score: number; // 0.0 to 1.0
  reasoning: string;
  passed: boolean;
}

export interface ReasoningTrace {
  id: UUID;
  parentId?: UUID;
  depth: number;
  input: string;
  output: string;
  evaluations: EvaluationResult[];
  status: TraceStatus;
}

export interface IEvaluatorService {
  evaluate(
    input: string,
    context?: string[]
  ): Promise<EvaluationResult[]>;

  attackBeliefs?(
    input: string,
    beliefs: { id: string; content: string }[]
  ): Promise<string[]>;
}

// --- EPISTEMIC HEALTH ---

export interface EpistemicError {
  source: "constraint" | "evaluator" | "memory" | "recursor";
  deltaUtility: number; // Negative value representing cost of error
  contradictionWith?: string[];
  timestamp: Timestamp;
  fatal: boolean;
  context: string;
}

// --- CONSTRAINT LAYER ---

export enum ConstraintType {
  HARD = 'HARD', // Must pass or immediate rejection
  SOFT = 'SOFT'  // Contributes to negative scoring
}

export interface ConstraintRule {
  id: string;
  description: string;
  type: ConstraintType;
  // logic definition for validator would go here
}

// --- BRIDGE ORCHESTRATION ---

export interface SystemState {
  isProcessing: boolean;
  currentDepth: number;
  activeTraceId: UUID | null;
  memorySize: number;
  logs: SystemLog[];
}

export interface SystemLog {
  timestamp: Timestamp;
  module: 'MODEL' | 'EVALUATOR' | 'CONSTRAINT' | 'MEMORY' | 'RECURSOR' | 'EXPORTER' | 'BRIDGE' | 'INGEST' | 'STRATEGY' | 'DISTILLATION';
  level: 'INFO' | 'WARN' | 'ERROR' | 'DEBUG';
  message: string;
  data?: unknown;
}

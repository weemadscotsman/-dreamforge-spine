
import React from 'react';
import { FightMode } from '../core/types';

export interface FightState {
  cycle: number;
  stage: 'IDLE' | 'PREP' | 'CANDIDATE' | 'CHALLENGER' | 'CLASH';
  winner?: string; 
  lastScore?: number;
  mode?: FightMode;
}

interface Props {
  state: FightState;
  className?: string;
}

export const FightHUD: React.FC<Props> = ({ state, className = '' }) => {
  const isRunning = state.stage !== 'IDLE';
  const mode = state.mode || 'SWARM_4_WAY';
  
  // Define available lanes
  const laneDefs = {
      ALPHA: { color: 'bg-green-500', label: 'PRIME', width: 'w-full' },
      BETA: { color: 'bg-red-500', label: 'NEMESIS', width: 'w-[90%]' },
      GAMMA: { color: 'bg-purple-500', label: 'LATERAL', width: 'w-[80%]' },
      DELTA: { color: 'bg-yellow-500', label: 'AXIOM', width: 'w-[85%]' }
  };

  // Determine active lanes based on mode
  let activeLanes: string[] = [];
  switch(mode) {
      case 'DUEL_1V1': activeLanes = ['ALPHA', 'BETA']; break;
      case 'TAG_TEAM_2V2': activeLanes = ['ALPHA', 'GAMMA', 'BETA', 'DELTA']; break;
      case 'BOSS_RUSH_3V1': activeLanes = ['ALPHA', 'GAMMA', 'DELTA', 'BETA']; break;
      case 'SWARM_4_WAY': default: activeLanes = ['ALPHA', 'BETA', 'GAMMA', 'DELTA']; break;
  }

  return (
    <div className={`p-3 bg-black/90 border border-surgery-border rounded-sm relative overflow-hidden group ${className}`}>
        
        {/* Header */}
        <div className="flex justify-between items-end mb-3 z-10 relative">
            <div className="flex flex-col">
                <span className="text-[8px] text-gray-500 font-mono tracking-widest uppercase flex items-center gap-1">
                     <span className={`w-1.5 h-1.5 rounded-full ${state.cycle > 0 ? 'bg-dream-accent animate-pulse' : 'bg-gray-700'}`} />
                     {mode.replace('_', ' ')}
                </span>
                <span className="text-lg font-black text-white italic tracking-tighter">
                    CYCLE {state.cycle.toString().padStart(2, '0')}
                </span>
            </div>
            <div className={`text-[9px] font-bold px-2 py-0.5 rounded-sm uppercase tracking-wide border border-transparent ${!isRunning ? 'bg-gray-800 text-gray-500' : 'bg-surgery-cyan text-black animate-pulse border-white/50'}`}>
                {isRunning ? 'EXEC' : 'IDLE'}
            </div>
        </div>

        {/* Lanes Display */}
        <div className="space-y-1.5 relative z-10">
            {activeLanes.map((id, i) => {
                const lane = laneDefs[id as keyof typeof laneDefs];
                if (!lane) return null;

                // Animation Logic
                const isWinner = state.winner?.toUpperCase() === id;
                const isActive = isRunning;
                const delay = i * 100;
                
                return (
                    <div key={id} className="relative h-3 w-full bg-gray-900/50 rounded-sm overflow-hidden flex items-center">
                        {/* Bar */}
                        <div 
                            className={`h-full absolute top-0 left-0 transition-all duration-1000 ${lane.color} ${isActive ? 'opacity-80' : 'opacity-20'} ${isWinner ? '!opacity-100 !w-full shadow-[0_0_10px_currentColor]' : ''}`}
                            style={{ 
                                width: isActive ? (isWinner ? '100%' : lane.width) : '0%',
                                animation: isActive ? `scan 2s infinite linear ${delay}ms` : 'none'
                            }}
                        />
                        
                        {/* Label */}
                        <div className="relative z-10 flex justify-between w-full px-2 text-[8px] font-black tracking-widest">
                            <span className={isActive ? 'text-black' : 'text-gray-600'}>{id}</span>
                            <span className={`hidden md:inline opacity-60 ${isActive ? 'text-black' : 'text-gray-700'}`}>{lane.label}</span>
                        </div>
                    </div>
                );
            })}
        </div>

        {/* Winner Overlay */}
        {state.winner && (
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center justify-center z-20 pointer-events-none">
                <div className={`
                    text-xl font-black italic tracking-tighter border-y-2 px-6 py-1 -rotate-6 shadow-[0_0_30px_rgba(0,0,0,0.8)] bg-black/90 backdrop-blur-sm
                    ${state.winner === 'ALPHA' ? 'text-green-500 border-green-500' : ''}
                    ${state.winner === 'BETA' ? 'text-red-500 border-red-500' : ''}
                    ${state.winner === 'GAMMA' ? 'text-purple-500 border-purple-500' : ''}
                    ${state.winner === 'DELTA' ? 'text-yellow-500 border-yellow-500' : ''}
                `}>
                    {state.winner}_VICTORY
                </div>
            </div>
        )}
        
        {/* Background Grid */}
        <div className="absolute inset-0 bg-[linear-gradient(90deg,transparent_95%,rgba(255,255,255,0.03)_100%)] bg-[length:10px_100%] pointer-events-none" />
    </div>
  );
};

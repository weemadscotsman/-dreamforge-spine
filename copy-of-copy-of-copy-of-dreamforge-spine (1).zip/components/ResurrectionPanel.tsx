
import React, { useState, useEffect } from "react";
import { realtimeBus } from "../bridge/realtime_bus";
import { LesionRecord } from "../engine/beliefs/resurrection";

export default function ResurrectionPanel() {
  const [wells, setWells] = useState<LesionRecord[]>([]);

  useEffect(() => {
    const cleanup = realtimeBus.on("LESION_UPDATE", (data: LesionRecord[]) => {
        if (Array.isArray(data)) {
            setWells(data);
        }
    });
    return cleanup;
  }, []);

  return (
    <div className="flex flex-col h-full bg-[#0a0505]/90 border border-red-900/30">
        <div className="p-3 border-b border-red-900/20 bg-red-900/10 flex justify-between items-center">
            <h3 className="text-[10px] font-mono font-bold text-red-400 tracking-widest flex items-center gap-2">
                <span>☠</span> LESION_MAP
            </h3>
            <span className="text-[9px] text-red-500/50">{wells.length} DEAD</span>
        </div>

        <div className="flex-1 overflow-y-auto p-2 font-mono text-xs space-y-2 scrollbar-hide">
            {wells.length === 0 && <div className="text-[9px] text-gray-700 italic text-center pt-4">No beliefs have died yet.</div>}
            
            {wells.map(w => (
                <div key={w.id} className="relative group border-l-2 pl-2 border-red-900/50 text-red-300/60 hover:text-red-300 transition-colors">
                    <div className="text-[10px] line-clamp-2 leading-tight">
                        {w.statement}
                    </div>
                    <div className="flex justify-between items-center mt-1">
                        <span className="text-[8px] uppercase opacity-40">{w.reasonOfDeath}</span>
                        <span className="text-[8px] opacity-50 bg-black/40 px-1 rounded">
                            SCAR_POTENTIAL: {Math.round(w.strengthAtDeath * 100)}
                        </span>
                    </div>
                    {!w.revivable && (
                        <div className="absolute top-0 right-0 text-[8px] font-bold text-green-500 bg-black/80 px-1 animate-pulse">
                            RESURRECTED
                        </div>
                    )}
                </div>
            ))}
        </div>
    </div>
  );
}

import React, { useEffect, useState } from "react";
import { realtimeBus } from "../../bridge/realtime_bus";

export default function PressurePulse() {
  const [pressure, setPressure] = useState<{intensity: number} | null>(null);

  useEffect(() => {
    const cleanup = realtimeBus.on("PRESSURE_CURVE", setPressure);
    return cleanup;
  }, []);

  if (!pressure) return null;

  const intensity = Math.min(1, Math.max(0.1, pressure.intensity));
  // Map intensity to color: Low (Blue) -> High (Magenta/Red)
  const r = Math.floor(intensity * 255);
  const b = Math.floor(255 - (intensity * 100));
  
  const glow = (intensity * 25).toFixed(1);

  return (
    <div className="absolute top-4 right-20 z-50 pointer-events-none flex items-center gap-2">
      <div className="text-[8px] font-mono text-gray-500 tracking-widest text-right">
        SYS<br/>PRES
      </div>
      <div
        className="w-6 h-6 rounded-full border border-white/20"
        style={{
          background: `rgba(${r}, 0, ${b}, ${intensity * 0.6})`,
          boxShadow: `0 0 ${glow}px rgba(${r}, 0, ${b}, 0.8)`,
          transition: "all 0.5s cubic-bezier(0.4, 0, 0.2, 1)",
          transform: `scale(${0.8 + intensity * 0.4})`
        }}
        title={`System Pressure: ${(intensity * 100).toFixed(0)}%`}
      />
    </div>
  );
}
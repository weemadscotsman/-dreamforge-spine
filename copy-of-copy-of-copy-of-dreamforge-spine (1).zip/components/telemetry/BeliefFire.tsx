import React, { useEffect, useState } from "react";
import { realtimeBus } from "../../bridge/realtime_bus";
import { HypothesisRecord } from "../../engine/beliefs/hypothesis_ledger";

export default function BeliefFire() {
  const [beliefs, setBeliefs] = useState<HypothesisRecord[]>([]);

  useEffect(() => {
    const cleanup = realtimeBus.on("BELIEFS_UPDATE", (records: HypothesisRecord[]) => {
      // Sort by strength descending, then by status
      if (Array.isArray(records)) {
        setBeliefs([...records].sort((a,b) => b.strength - a.strength));
      }
    });
    return cleanup;
  }, []);

  return (
    <div className="h-full flex flex-col bg-[#0a0a0c]/80 backdrop-blur-md border border-gray-800">
      <div className="p-3 border-b border-gray-800 flex justify-between items-center bg-black/40">
        <h3 className="text-xs font-mono font-bold text-gray-400 tracking-widest">ACTIVE_BELIEF_MATRIX</h3>
        <div className="text-[9px] text-gray-600">{beliefs.length} NODES</div>
      </div>
      
      <div className="flex-1 overflow-y-auto p-2 font-mono text-xs space-y-1 scrollbar-hide">
        {beliefs.length === 0 && (
            <div className="text-center text-gray-700 italic pt-10 text-[10px]">No beliefs formulated.</div>
        )}
        
        {beliefs.map((b) => (
          <div
            key={b.id}
            className={`
              p-2 rounded-sm border-l-2 transition-all duration-500 animate-in fade-in slide-in-from-left-2
              ${b.status === 'reinforced' ? 'border-dream-accent bg-dream-accent/5 text-dream-cyan' : ''}
              ${b.status === 'true' ? 'border-green-500 bg-green-500/5 text-green-400' : ''}
              ${b.status === 'unproven' ? 'border-yellow-500 bg-yellow-500/5 text-yellow-600' : ''}
              ${b.status === 'disproven' ? 'border-red-500 bg-red-500/5 text-red-500 opacity-60' : ''}
            `}
          >
            <div className="flex justify-between items-center mb-1">
              <span className="opacity-70 text-[9px] uppercase tracking-wider">{b.status}</span>
              <span className="opacity-50 text-[9px] bg-black/30 px-1 rounded">STR:{b.strength}</span>
            </div>
            <div className="whitespace-pre-wrap leading-relaxed opacity-90 text-[10px]">
                {b.statement}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
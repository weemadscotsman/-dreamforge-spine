import React from 'react';

interface Props {
  data: number[];
  color?: string;
  height?: number;
  min?: number;
  max?: number;
  className?: string;
}

export const Sparkline: React.FC<Props> = ({ 
  data, 
  color = '#00f3ff', 
  height = 40, 
  min, 
  max,
  className = '' 
}) => {
  if (!data || data.length < 2) {
    return (
      <div className={`flex items-center justify-center opacity-30 text-[9px] font-mono border-b border-white/10 ${className}`} style={{ height }}>
        NO_SIGNAL
      </div>
    );
  }

  const values = data;
  const minValue = min ?? Math.min(...values);
  const maxValue = max ?? Math.max(...values);
  const range = maxValue - minValue || 1;

  // SVG Path Construction
  const points = values.map((val, i) => {
    const x = (i / (values.length - 1)) * 100;
    const normalizedVal = (val - minValue) / range;
    const y = 100 - (normalizedVal * 100); // SVG y is top-down
    return `${x},${y}`;
  }).join(' ');

  return (
    <div className={`relative w-full overflow-hidden ${className}`} style={{ height }}>
      <svg 
        viewBox="0 0 100 100" 
        preserveAspectRatio="none" 
        className="w-full h-full overflow-visible filter drop-shadow-[0_0_4px_rgba(0,0,0,0.5)]"
      >
        {/* Fill Gradient */}
        <defs>
          <linearGradient id={`grad-${color}`} x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.2" />
            <stop offset="100%" stopColor={color} stopOpacity="0.0" />
          </linearGradient>
        </defs>
        
        <path 
          d={`M 0,100 L 0,${100 - ((values[0] - minValue) / range) * 100} ${points.replace(/,/g, ' ')} L 100,100 Z`} 
          fill={`url(#grad-${color})`} 
          stroke="none"
        />

        {/* Line */}
        <polyline 
          fill="none" 
          stroke={color} 
          strokeWidth="2" 
          points={points} 
          vectorEffect="non-scaling-stroke"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Pulsing Head */}
        <circle 
          cx="100" 
          cy={100 - ((values[values.length - 1] - minValue) / range) * 100} 
          r="3" 
          fill="#fff"
          className="animate-pulse"
        />
      </svg>
      
      {/* Scanline Overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(90deg,transparent_95%,rgba(255,255,255,0.1)_100%)] bg-[length:200%_100%] animate-[scan_2s_linear_infinite] pointer-events-none" />
    </div>
  );
};
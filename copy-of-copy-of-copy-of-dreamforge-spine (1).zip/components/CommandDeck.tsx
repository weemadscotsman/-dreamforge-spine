
import React, { useEffect, useRef } from 'react';
import { CycleLog } from '../recursor/types';
import { FightHUD, FightState } from './FightHUD';
import { TypewriterBlock } from './TypewriterBlock';

interface Message {
  id: string;
  role: 'user' | 'system' | 'assistant';
  content: string;
  timestamp: number;
  meta?: any;
}

interface Props {
  history: Message[];
  isProcessing: boolean;
  fightState: FightState;
  logs: CycleLog[];
}

export const CommandDeck: React.FC<Props> = ({ 
  history, 
  isProcessing, 
  fightState,
  logs
}) => {
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history, logs, fightState.stage]);

  return (
    <div className="flex flex-col h-full w-full font-mono text-sm relative overflow-hidden bg-transparent">
      
      {/* Background Decor */}
      <div className="absolute top-0 right-0 p-4 opacity-20 pointer-events-none">
         <div className="border border-white/20 w-32 h-32 rounded-full animate-[spin_10s_linear_infinite] border-dashed" />
      </div>

      {/* LOG STREAM */}
      <div className="flex-1 min-h-0 overflow-y-auto p-4 space-y-6 scrollbar-thin scrollbar-thumb-surgery-border scrollbar-track-transparent relative z-10">
        {history.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center opacity-30 select-none space-y-4">
            <div className="text-6xl animate-pulse text-surgery-cyan">❖</div>
            <div className="text-xs tracking-[0.4em] text-surgery-cyan font-bold">DREAMFORGE_ONLINE</div>
            <div className="text-[9px] text-gray-500">AWAITING_NEURAL_LINK</div>
          </div>
        )}

        {history.map((msg) => (
          <div key={msg.id} className="flex flex-col gap-1 border-l-2 border-surgery-border pl-4 group hover:border-surgery-cyan transition-colors">
            <div className="flex items-baseline gap-3 text-[10px] uppercase tracking-widest opacity-60 group-hover:opacity-100">
              <span className={msg.role === 'user' ? 'text-surgery-cyan' : 'text-surgery-red'}>
                {msg.role === 'user' ? '>> OPR' : '<< SYS'}
              </span>
              <span>{new Date(msg.timestamp).toLocaleTimeString()}</span>
              <span className="opacity-30">ID:{msg.id.slice(0,4)}</span>
            </div>
            
            <div className={`whitespace-pre-wrap leading-relaxed ${msg.role === 'user' ? 'text-white font-bold' : 'text-gray-300'}`}>
              {/* Only animate the assistant's last message or if it's very recent */}
              {msg.role === 'assistant' ? (
                 <TypewriterBlock content={msg.content} speed={2} />
              ) : (
                 msg.content
              )}
            </div>
          </div>
        ))}

        {/* ACTIVE PROCESS INDICATOR */}
        {isProcessing && (
          <div className="border-l-2 border-surgery-cyan pl-4 py-4 my-4 bg-gradient-to-r from-surgery-cyan/10 to-transparent animate-in fade-in duration-300 relative">
            {/* Loading Glimmer */}
            <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-surgery-cyan to-transparent animate-[shimmer_2s_infinite]" />

            <div className="flex items-center gap-2 mb-4">
               <span className="w-2 h-2 bg-surgery-cyan rounded-full animate-ping" />
               <span className="text-[10px] font-bold tracking-widest text-surgery-cyan animate-pulse">
                  NEURAL_ENGINE_ENGAGED
               </span>
            </div>

            {/* LIVE FIGHT HUD */}
            <div className="mb-4 max-w-lg border border-surgery-cyan/30 bg-black/80 backdrop-blur-sm shadow-[0_0_30px_rgba(0,240,255,0.1)]">
                <FightHUD state={fightState} />
            </div>

            {/* LIVE STREAM LOGS */}
            <div className="space-y-1 font-mono text-[10px]">
                {logs.map((log, i) => (
                    <div key={i} className="flex gap-2 items-center opacity-80 animate-in slide-in-from-left-4 fade-in">
                        <span className="text-gray-500">[{new Date(log.timestamp).toLocaleTimeString().split(' ')[0]}]</span>
                        <span className={log.winner === 'candidate' ? 'text-green-400 font-bold' : 'text-red-400 font-bold'}>
                            {log.winner?.toUpperCase() || '...'}
                        </span>
                        <TypewriterBlock content={log.reason || 'Processing...'} speed={5} className="text-gray-400 truncate max-w-[300px]" />
                    </div>
                ))}
            </div>
          </div>
        )}

        <div ref={endRef} />
      </div>
    </div>
  );
};


import React, { useState } from 'react';
import { ModelProvider } from '../../model/types';
import { orchestrator } from '../../bridge/orchestrator';

interface Props {
    config: any;
    onUpdate: (updates: any) => void;
    activeTab: string;
    onTabChange: (tab: string) => void;
    apiKeys: Record<string, string>;
    onKeyUpdate: (provider: string, key: string) => void;
}

const WEB_MODELS = [
    { id: "Llama-3.2-3B-Instruct-q4f16_1-MLC", label: "LLAMA 3.2 3B (2GB VRAM)" },
    { id: "Llama-3.1-8B-Instruct-q4f32_1-MLC", label: "LLAMA 3.1 8B (6GB VRAM)" },
    { id: "Phi-3.5-vision-instruct-q4f16_1-MLC", label: "PHI 3.5 VISION (MULTIMODAL)" },
];

export const InferenceSettings: React.FC<Props> = ({ config, onUpdate, activeTab, onTabChange, apiKeys, onKeyUpdate }) => {
    const [customModel, setCustomModel] = useState('');
    const [webModel, setWebModel] = useState(WEB_MODELS[0].id);

    const activate = () => {
        orchestrator.setConfig({ 
            provider: activeTab,
            modelName: activeTab === ModelProvider.WEBLLM ? webModel : customModel || undefined
        });
        // Feedback
        const btn = document.getElementById('activate-btn');
        if (btn) {
            btn.innerText = "LINK ESTABLISHED";
            setTimeout(() => btn.innerText = "ENGAGE LINK", 2000);
        }
    };

    return (
        <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
            {/* SESSION SECURITY STATUS - REPLACING THE SCARY WARNING */}
            <div className="bg-surgery-dark border border-surgery-cyan/30 p-3 text-[9px] text-gray-400 font-mono flex gap-2 items-center rounded-sm">
                <span className="text-lg text-surgery-cyan">🔒</span>
                <div>
                    <strong className="block mb-1 text-surgery-cyan tracking-wider">SECURE SESSION MODE</strong>
                    Keys are stored in <strong>volatile memory only</strong>. 
                    <br/>They are cleared instantly on page reload. No local storage persistence.
                </div>
            </div>

            {/* Provider Tabs */}
            <div className="flex flex-wrap gap-1 border-b border-white/10 pb-2">
                {[
                    ModelProvider.GEMINI_FLASH,
                    ModelProvider.GEMINI_PRO,
                    ModelProvider.WEBLLM,
                    ModelProvider.OLLAMA,
                    ModelProvider.OPENAI,
                    ModelProvider.ANTHROPIC
                ].map(p => (
                    <button
                        key={p}
                        onClick={() => onTabChange(p)}
                        className={`px-2 py-1 text-[9px] font-bold uppercase border transition-all rounded-t-sm ${activeTab === p ? 'bg-surgery-cyan text-black border-surgery-cyan' : 'text-gray-500 border-transparent hover:border-gray-700 hover:text-gray-300'}`}
                    >
                        {p.split('-')[0].replace('GEMINI_FLASH', 'GEMINI (FAST)').replace('GEMINI_PRO', 'GEMINI (SMART)')}
                    </button>
                ))}
            </div>

            {/* Config Body */}
            <div className="space-y-3">
                <div className="flex justify-between items-center bg-black/40 p-2 border-l-2 border-surgery-cyan">
                    <span className="text-[10px] text-surgery-cyan font-bold tracking-widest uppercase">
                        TARGET: {activeTab}
                    </span>
                    {config.provider === activeTab && <span className="text-[9px] bg-surgery-cyan text-black px-1 rounded font-bold">ACTIVE</span>}
                </div>

                {activeTab !== ModelProvider.WEBLLM && activeTab !== ModelProvider.OLLAMA && activeTab !== ModelProvider.MOCK && (
                    <div className="flex flex-col gap-1">
                        <label className="text-[10px] font-bold text-gray-500">API KEY / TOKEN</label>
                        <input 
                            type="password"
                            value={apiKeys[activeTab] || ''}
                            onChange={(e) => onKeyUpdate(activeTab, e.target.value)}
                            className="bg-black border border-surgery-border text-white text-xs p-2 rounded-sm outline-none focus:border-surgery-cyan placeholder-gray-700 font-mono tracking-widest"
                            placeholder="sk-........................"
                            autoComplete="off"
                        />
                    </div>
                )}

                {activeTab === ModelProvider.WEBLLM && (
                    <div className="flex flex-col gap-1">
                        <label className="text-[10px] font-bold text-dream-accent">LOCAL WEIGHTS (BROWSER GPU)</label>
                        <select 
                            value={webModel}
                            onChange={(e) => setWebModel(e.target.value)}
                            className="bg-black border border-surgery-border text-white text-xs p-2 rounded-sm outline-none focus:border-dream-accent"
                        >
                            {WEB_MODELS.map(m => <option key={m.id} value={m.id}>{m.label}</option>)}
                        </select>
                        <p className="text-[8px] text-gray-500">Requires WebGPU compatible browser (Chrome/Edge/Arc).</p>
                    </div>
                )}

                {activeTab === ModelProvider.OLLAMA && (
                    <div className="flex flex-col gap-1">
                        <label className="text-[10px] font-bold text-orange-400">LOCAL ENDPOINT</label>
                        <input 
                            type="text"
                            defaultValue="http://localhost:11434"
                            onChange={(e) => onUpdate({ ollamaUrl: e.target.value })}
                            className="bg-black border border-surgery-border text-white text-xs p-2 rounded-sm outline-none focus:border-orange-400 font-mono"
                        />
                    </div>
                )}

                <div className="grid grid-cols-2 gap-2 pt-2">
                    <div className="flex flex-col gap-1">
                        <label className="text-[10px] text-gray-500 flex justify-between">
                            <span>TEMPERATURE</span>
                            <span className="text-white">{config.temperature}</span>
                        </label>
                        <input 
                            type="range" 
                            min="0" 
                            max="2" 
                            step="0.1" 
                            value={config.temperature} 
                            onChange={(e) => onUpdate({ temperature: parseFloat(e.target.value) })} 
                            className="accent-surgery-cyan h-1 bg-gray-800 rounded-lg appearance-none cursor-pointer"
                        />
                    </div>
                    <div className="flex flex-col gap-1">
                        <label className="text-[10px] text-gray-500 flex justify-between">
                            <span>MAX TOKENS</span>
                            <span className="text-white">{config.maxTokens}</span>
                        </label>
                        <input 
                            type="range" 
                            min="512" 
                            max="8192" 
                            step="512" 
                            value={config.maxTokens} 
                            onChange={(e) => onUpdate({ maxTokens: parseInt(e.target.value) })} 
                            className="accent-surgery-cyan h-1 bg-gray-800 rounded-lg appearance-none cursor-pointer"
                        />
                    </div>
                </div>

                <button 
                    id="activate-btn"
                    onClick={activate}
                    className="w-full py-2 bg-surgery-cyan/10 text-surgery-cyan border border-surgery-cyan hover:bg-surgery-cyan hover:text-black transition-all text-[10px] font-bold tracking-widest uppercase shadow-[0_0_15px_rgba(0,240,255,0.1)] mt-2"
                >
                    ENGAGE LINK
                </button>
            </div>
        </div>
    );
};

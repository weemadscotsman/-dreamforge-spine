
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { realtimeBus } from '../bridge/realtime_bus';
import { SystemEvent } from '../bridge/types';
import { stopAutoLoop } from '../autonomous/auto_loop';
import { orchestrator } from '../bridge/orchestrator';

interface LogEntry {
    id: string;
    timestamp: number;
    source: string;
    level: string;
    message: string;
    data?: any;
}

type Tab = 'CONSOLE' | 'NETWORK' | 'SYSTEM';

export const SystemTerminal: React.FC = () => {
    const [logs, setLogs] = useState<LogEntry[]>([]);
    const [activeTab, setActiveTab] = useState<Tab>('CONSOLE');
    const [filterLevel, setFilterLevel] = useState<'ALL' | 'INFO' | 'WARN' | 'ERROR'>('ALL');
    const [search, setSearch] = useState('');
    const [autoScroll, setAutoScroll] = useState(true);
    const [selectedLog, setSelectedLog] = useState<LogEntry | null>(null);
    const endRef = useRef<HTMLDivElement>(null);

    // Initial Load & Subscription
    useEffect(() => {
        // 1. Hydrate from Orchestrator (Past Logs)
        const history = orchestrator.getState().logs || [];
        const formattedHistory: LogEntry[] = history.map((h: any) => ({
            id: crypto.randomUUID(),
            timestamp: h.timestamp,
            source: h.module,
            level: h.level,
            message: h.message,
            data: h.data
        }));
        setLogs(formattedHistory);

        // 2. Subscribe to Realtime Bus (New Logs)
        const handleEvent = (payload: any) => {
            const entry: LogEntry = {
                id: crypto.randomUUID(),
                timestamp: Date.now(),
                source: payload.module || 'UNKNOWN',
                level: payload.level || 'INFO',
                message: payload.message || 'No message',
                data: payload.data
            };
            setLogs(prev => [...prev, entry].slice(-2000));
        };

        // Listen for direct SYSTEM_LOG events
        const cleanup = realtimeBus.on('SYSTEM_LOG', handleEvent);
        
        // Also listen for STRATEGY_LOG to ensure we catch those
        const cleanupStrat = realtimeBus.on('STRATEGY_LOG', (payload: any) => {
             handleEvent({ ...payload, module: 'STRATEGY' });
        });

        // [UPDATED] Listen for broader system events for full visibility
        const eventMap: Record<string, {mod: string, lvl: string, fmt: (p:any)=>string}> = {
            'VISION_STATUS': { mod: 'VISION', lvl: 'INFO', fmt: (p) => `Optic Link: ${p.active ? 'ACTIVE' : 'OFFLINE'}` },
            'TRIGGER_OPTIC_SELECTION': { mod: 'UI', lvl: 'INFO', fmt: () => `User triggered optic selection` },
            'AUTO_STATUS': { mod: 'AUTONOMY', lvl: 'INFO', fmt: (p) => `State: ${p.state}${p.reason ? ` (${p.reason})` : ''}` },
            'FIGHT_UPDATE': { mod: 'ENGINE', lvl: 'DEBUG', fmt: (p) => `Phase: ${p.stage} [Cycle ${p.cycle}]` },
            'WEBLLM_READY': { mod: 'WEBLLM', lvl: 'SUCCESS', fmt: (p) => `Model Ready: ${p.model}` },
            'CONSTRAINT_UPDATE': { mod: 'GOVERNOR', lvl: 'WARN', fmt: (p) => `Autonomy Level: ${p.level}` },
            'DATASET_INGESTED': { mod: 'INGEST', lvl: 'INFO', fmt: (p) => `Loaded ${p.count} items from ${p.id}` },
            'MEMORY_INGEST': { mod: 'MEMORY', lvl: 'INFO', fmt: (p) => `Ingested external content: ${p.signature}` }
        };

        const unsubs = Object.entries(eventMap).map(([event, conf]) => 
            realtimeBus.on(event, (payload: any) => {
                handleEvent({
                    module: conf.mod,
                    level: conf.lvl,
                    message: conf.fmt(payload),
                    data: payload
                });
            })
        );

        return () => {
            cleanup();
            cleanupStrat();
            unsubs.forEach(u => u());
        };
    }, []);

    useEffect(() => {
        if (autoScroll && endRef.current) {
            endRef.current.scrollIntoView({ behavior: 'auto' });
        }
    }, [logs, autoScroll, activeTab]);

    // FILTER LOGIC
    const visibleLogs = useMemo(() => {
        return logs.filter(log => {
            if (activeTab === 'NETWORK') {
                return (log.source && (log.source.includes('GEMINI') || log.source.includes('HTTP') || log.source.includes('WEBLLM')));
            }
            if (activeTab === 'SYSTEM') {
                return log.source === 'BRIDGE' || log.source === 'ORCHESTRATOR' || log.level === 'ERROR';
            }
            // CONSOLE (All except super verbose network data unless error)
            if (filterLevel !== 'ALL' && log.level !== filterLevel) return false;
            
            const content = `${log.source} ${log.message} ${JSON.stringify(log.data || '')}`.toLowerCase();
            if (search && !content.includes(search.toLowerCase())) return false;
            
            return true;
        });
    }, [logs, filterLevel, search, activeTab]);

    const handleEmergencyStop = () => {
        stopAutoLoop();
        const stopLog = { module: "USER_OVERRIDE", level: "ERROR", message: "!!! EMERGENCY STOP TRIGGERED !!!" };
        realtimeBus.emit("SYSTEM_LOG", stopLog);
        window.location.reload(); 
    };

    const clearLogs = () => setLogs([]);

    const handleCopy = (text: string) => {
        navigator.clipboard.writeText(text);
    };

    return (
        <div className="flex h-full w-full bg-[#050505] font-mono text-[11px] overflow-hidden text-gray-300">
            {/* LEFT: MAIN FEED */}
            <div className="flex-1 flex flex-col min-w-0 border-r border-gray-800">
                
                {/* TOOLBAR */}
                <div className="flex items-center gap-2 p-2 border-b border-gray-800 bg-[#0a0a0c]">
                    <div className="flex bg-black border border-gray-800 rounded overflow-hidden">
                        {['CONSOLE', 'NETWORK', 'SYSTEM'].map(tab => (
                            <button
                                key={tab}
                                onClick={() => setActiveTab(tab as Tab)}
                                className={`px-3 py-1 font-bold transition-all ${activeTab === tab ? 'bg-surgery-cyan text-black' : 'hover:text-white'}`}
                            >
                                {tab}
                            </button>
                        ))}
                    </div>

                    <div className="h-4 w-px bg-gray-800 mx-2" />

                    <select 
                        value={filterLevel} 
                        onChange={(e) => setFilterLevel(e.target.value as any)}
                        className="bg-black border border-gray-800 rounded px-2 py-1 outline-none focus:border-surgery-cyan"
                    >
                        <option value="ALL">ALL LEVELS</option>
                        <option value="INFO">INFO</option>
                        <option value="WARN">WARN</option>
                        <option value="ERROR">ERROR</option>
                    </select>

                    <input 
                        type="text" 
                        placeholder="Filter grep..." 
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        className="bg-black border border-gray-800 rounded px-2 py-1 flex-1 min-w-[100px] outline-none focus:border-surgery-cyan text-white"
                    />

                    <button 
                        onClick={clearLogs}
                        className="px-2 py-1 text-gray-500 hover:text-white border border-transparent hover:border-gray-700 rounded"
                    >
                        CLEAR
                    </button>
                    
                    <button 
                        onClick={handleEmergencyStop}
                        className="px-3 py-1 bg-red-900/20 border border-red-500/50 text-red-500 hover:bg-red-500 hover:text-black font-bold rounded animate-pulse"
                    >
                        HALT
                    </button>
                </div>

                {/* LOG AREA */}
                <div className="flex-1 overflow-y-auto p-1 space-y-px bg-black scrollbar-thin scrollbar-thumb-gray-800">
                    {visibleLogs.length === 0 && (
                        <div className="p-4 text-gray-600 italic text-center">
                            No logs found. Check filter or system status.
                        </div>
                    )}
                    {visibleLogs.map(log => (
                        <div 
                            key={log.id} 
                            onClick={() => setSelectedLog(log)}
                            className={`
                                flex gap-2 items-start px-2 py-1 cursor-pointer border-l-2 hover:bg-white/5
                                ${selectedLog?.id === log.id ? 'bg-white/10' : ''}
                                ${getLevelStyle(log.level)}
                            `}
                        >
                            <span className="opacity-40 w-16 shrink-0 font-mono text-[9px] pt-0.5">
                                {new Date(log.timestamp).toLocaleTimeString()}
                            </span>
                            <span className="font-bold w-24 shrink-0 truncate" title={log.source}>
                                {log.source}
                            </span>
                            <span className="flex-1 break-words opacity-90 leading-tight">
                                {log.message}
                            </span>
                            {log.data && <span className="text-surgery-cyan opacity-70 text-[9px]">{'{DATA}'}</span>}
                        </div>
                    ))}
                    <div ref={endRef} />
                </div>
            </div>

            {/* RIGHT: INSPECTOR */}
            {selectedLog && (
                <div className="w-[400px] flex flex-col bg-[#08080a] animate-in slide-in-from-right-10 duration-200 border-l border-gray-800">
                    <div className="p-2 border-b border-gray-800 flex justify-between items-center bg-gray-900/50">
                        <span className="font-bold text-gray-400">PACKET_INSPECTOR</span>
                        <div className="flex gap-2 items-center">
                            <button 
                                onClick={() => handleCopy(JSON.stringify(selectedLog, null, 2))}
                                className="text-[9px] text-gray-500 hover:text-surgery-cyan font-bold uppercase tracking-wider"
                                title="Copy Full Log Object"
                            >
                                RAW_COPY
                            </button>
                            <button onClick={() => setSelectedLog(null)} className="text-gray-500 hover:text-white">✕</button>
                        </div>
                    </div>
                    
                    <div className="flex-1 overflow-y-auto p-4 space-y-4">
                        <div>
                            <div className="text-[9px] text-gray-500 uppercase tracking-widest mb-1">HEADER</div>
                            <div className="grid grid-cols-2 gap-2 text-[10px] text-gray-300">
                                <div className="bg-black p-2 border border-gray-800 rounded">
                                    <span className="text-gray-500 block">SOURCE</span>
                                    {selectedLog.source}
                                </div>
                                <div className="bg-black p-2 border border-gray-800 rounded">
                                    <span className="text-gray-500 block">LEVEL</span>
                                    <span className={getLevelColor(selectedLog.level)}>{selectedLog.level}</span>
                                </div>
                            </div>
                        </div>

                        <div>
                            <div className="flex justify-between items-center mb-1">
                                <span className="text-[9px] text-gray-500 uppercase tracking-widest">MESSAGE</span>
                                <button 
                                    onClick={() => handleCopy(selectedLog.message)}
                                    className="text-[8px] text-gray-600 hover:text-white border border-gray-800 hover:border-gray-600 px-1 rounded transition-colors uppercase"
                                >
                                    COPY
                                </button>
                            </div>
                            <div className="bg-black p-2 border border-gray-800 rounded text-gray-300 whitespace-pre-wrap font-mono text-[10px]">
                                {selectedLog.message}
                            </div>
                        </div>

                        {selectedLog.data && (
                            <div className="flex-1 flex flex-col min-h-0">
                                <div className="flex justify-between items-center mb-1">
                                    <span className="text-[9px] text-gray-500 uppercase tracking-widest">PAYLOAD</span>
                                    <button 
                                        onClick={() => handleCopy(JSON.stringify(selectedLog.data, null, 2))}
                                        className="text-[8px] text-gray-600 hover:text-white border border-gray-800 hover:border-gray-600 px-1 rounded transition-colors uppercase"
                                    >
                                        COPY JSON
                                    </button>
                                </div>
                                <div className="bg-[#050505] p-2 border border-gray-800 rounded overflow-auto font-mono text-[10px]">
                                    <JSONViewer data={selectedLog.data} />
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
};

// HELPER: Simple recursive JSON viewer
const JSONViewer: React.FC<{ data: any, level?: number }> = ({ data, level = 0 }) => {
    if (data === null) return <span className="text-gray-500">null</span>;
    if (data === undefined) return <span className="text-gray-600">undefined</span>;
    if (typeof data !== 'object') {
        const color = typeof data === 'string' ? 'text-green-400' : typeof data === 'number' ? 'text-orange-400' : 'text-purple-400';
        return <span className={color}>{JSON.stringify(data)}</span>;
    }

    const isArray = Array.isArray(data);
    const keys = Object.keys(data);

    if (keys.length === 0) return <span className="text-gray-500">{isArray ? '[]' : '{}'}</span>;

    return (
        <div style={{ paddingLeft: level * 8 }}>
            <span className="text-gray-600">{isArray ? '[' : '{'}</span>
            {keys.map((key, i) => (
                <div key={key} className="pl-2">
                    {!isArray && <span className="text-blue-300 mr-1">{key}:</span>}
                    <JSONViewer data={data[key]} level={0} />
                    {i < keys.length - 1 && <span className="text-gray-600">,</span>}
                </div>
            ))}
            <span className="text-gray-600">{isArray ? ']' : '}'}</span>
        </div>
    );
};

const getLevelStyle = (level: string) => {
    switch (level) {
        case 'ERROR': return 'border-red-500 text-red-300 bg-red-900/10';
        case 'WARN': return 'border-yellow-500 text-yellow-200 bg-yellow-900/5';
        case 'SUCCESS': return 'border-green-500 text-green-200 bg-green-900/5';
        case 'DEBUG': return 'border-gray-800 text-gray-500';
        default: return 'border-transparent text-gray-300';
    }
};

const getLevelColor = (level: string) => {
    switch (level) {
        case 'ERROR': return 'text-red-500 font-bold';
        case 'WARN': return 'text-yellow-400';
        case 'SUCCESS': return 'text-green-400';
        default: return 'text-gray-400';
    }
};

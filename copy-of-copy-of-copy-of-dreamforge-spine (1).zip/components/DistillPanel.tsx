
import React, { useEffect, useRef } from 'react';
import { DistillAction } from '../distillation/delta_hooks';

interface Props {
  events: (DistillAction & { timestamp: number })[];
}

export const DistillPanel: React.FC<Props> = ({ events }) => {
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [events]);

  return (
    <div className="flex flex-col h-full bg-[#08080c]/80 backdrop-blur-md border border-purple-500/20 rounded-md overflow-hidden relative group">
      {/* Header */}
      <div className="p-3 border-b border-purple-500/20 bg-purple-900/10 flex justify-between items-center shrink-0">
        <h3 className="text-purple-400 font-bold tracking-widest text-xs font-mono flex items-center gap-2">
          <span className="animate-pulse">⚡</span> DISTILLATION_FEED
        </h3>
        <span className="text-[10px] text-purple-300/50 font-mono">{events.length} EVENTS</span>
      </div>

      {/* Feed */}
      <div className="flex-1 overflow-y-auto p-2 space-y-2 font-mono scrollbar-thin scrollbar-thumb-purple-900/50 scrollbar-track-transparent">
        {events.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-gray-600 text-[10px] italic opacity-50">
            <span>Waiting for evolutionary pressure...</span>
            <span className="text-[8px] mt-1">Run a cycle to trigger hooks</span>
          </div>
        )}
        
        {events.map((e, i) => {
          const weight = Number(e.heuristic.weight) || 0;
          const delta = Number(e.delta) || 0;
          
          return (
            <div key={i} className={`
              border-l-2 p-2 rounded-r-sm text-[10px] transition-all animate-in slide-in-from-left-2 fade-in duration-300 relative overflow-hidden
              ${e.action === 'forked' ? 'border-purple-500 bg-purple-500/10 text-purple-200 shadow-[inset_0_0_10px_rgba(168,85,247,0.1)]' : ''}
              ${e.action === 'merged' ? 'border-cyan-500 bg-cyan-500/10 text-cyan-200' : ''}
              ${e.action === 'reinforced' ? 'border-green-500 bg-green-500/10 text-green-200' : ''}
              ${e.action === 'new' ? 'border-white bg-white/10 text-white' : ''}
            `}>
              <div className="flex justify-between items-center mb-1 opacity-70 border-b border-white/5 pb-1">
                <span className="font-bold uppercase tracking-wide">{e.action}</span>
                <span>{new Date(e.timestamp).toLocaleTimeString().split(' ')[0]}</span>
              </div>
              
              <div className="mb-2 leading-relaxed break-words opacity-90 font-semibold">
                {e.heuristic.rule || (e.heuristic as any).pattern}
              </div>
              
              <div className="flex justify-between items-center opacity-50 text-[9px] font-mono bg-black/20 p-1 rounded-sm">
                <span>WEIGHT: {weight.toFixed(2)}</span>
                {/* Show the Bite */}
                {e.delta !== undefined && (
                    <span className={`${delta > 0 ? 'text-green-400' : 'text-red-400'} font-bold`}>
                        Δ {(delta > 0 ? "+" : "") + delta.toFixed(3)}
                    </span>
                )}
              </div>
            </div>
          );
        })}
        <div ref={endRef} />
      </div>
      
      {/* Decoration */}
      <div className="absolute top-0 right-0 w-full h-full pointer-events-none bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-purple-500/5 to-transparent" />
    </div>
  );
};

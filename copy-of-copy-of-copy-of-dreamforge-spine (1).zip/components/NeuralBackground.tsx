
import React, { useRef, useEffect } from 'react';

interface NeuralProps {
  isProcessing: boolean;
  recursionDepth: number;
}

export const NeuralBackground: React.FC<NeuralProps> = ({ isProcessing, recursionDepth }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const timeRef = useRef<number>(0);
  const frameRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Resize handler
    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);
    handleResize();

    // Neural Nodes
    const nodes: { x: number; y: number; vx: number; vy: number }[] = [];
    const nodeCount = 50; // Increased count
    
    for (let i = 0; i < nodeCount; i++) {
      nodes.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.8,
        vy: (Math.random() - 0.5) * 0.8
      });
    }

    const render = () => {
      if (!ctx) return;
      
      const width = canvas.width;
      const height = canvas.height;
      
      // Speed multiplier based on processing state
      const speedMult = isProcessing ? 2.5 : 0.5;
      timeRef.current += 0.01 * speedMult;

      // Clear background with trail effect
      ctx.fillStyle = 'rgba(5, 5, 5, 0.15)'; // Lower opacity = longer trails
      ctx.fillRect(0, 0, width, height);

      const centerX = width / 2;
      const centerY = height / 2;

      // 1. Draw Central "Brain" Core (Rotating Rings)
      ctx.save();
      ctx.translate(centerX, centerY);
      
      // Ring 1 (Cyan)
      ctx.rotate(timeRef.current * 0.5);
      ctx.beginPath();
      ctx.strokeStyle = '#00f3ff';
      ctx.lineWidth = 3; // Thicker
      ctx.setLineDash([10, 20]);
      ctx.arc(0, 0, 100 + Math.sin(timeRef.current * 2) * 10, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);

      // Ring 2 (Magenta - Counter Rotate)
      ctx.rotate(-timeRef.current * 0.8);
      ctx.beginPath();
      ctx.strokeStyle = '#ff00ff';
      ctx.lineWidth = 2;
      ctx.arc(0, 0, 140, 0 + timeRef.current, Math.PI + timeRef.current);
      ctx.stroke();

      // Ring 3 (Processing/Alert - Pulse)
      if (isProcessing) {
        ctx.beginPath();
        ctx.strokeStyle = '#ff003c';
        ctx.lineWidth = 4;
        ctx.shadowBlur = 20;
        ctx.shadowColor = '#ff003c';
        ctx.arc(0, 0, 160 + Math.random() * 5, 0, Math.PI * 2);
        ctx.globalAlpha = 0.7;
        ctx.stroke();
        ctx.globalAlpha = 1.0;
        ctx.shadowBlur = 0;
      }
      
      // Recursion Depth Indicators (Orbiting Satellites)
      if (recursionDepth > 0) {
        for (let i = 0; i < recursionDepth; i++) {
           const angle = (timeRef.current * (1 + i * 0.1)) + (i * (Math.PI * 2 / 5));
           const dist = 200 + (i * 15);
           const sx = Math.cos(angle) * dist;
           const sy = Math.sin(angle) * dist;
           
           ctx.beginPath();
           ctx.fillStyle = '#00ff9d';
           ctx.shadowBlur = 10;
           ctx.shadowColor = '#00ff9d';
           ctx.arc(sx, sy, 4, 0, Math.PI * 2);
           ctx.fill();
           ctx.shadowBlur = 0;
           
           // Connect satellite to center
           ctx.beginPath();
           ctx.strokeStyle = 'rgba(0, 255, 157, 0.3)'; // Brighter connection
           ctx.lineWidth = 1;
           ctx.moveTo(0, 0);
           ctx.lineTo(sx, sy);
           ctx.stroke();
        }
      }

      ctx.restore();

      // 2. Draw Floating Nodes (Background Neural Net)
      ctx.lineWidth = 1;
      for (let i = 0; i < nodes.length; i++) {
        const node = nodes[i];
        
        // Move
        node.x += node.vx * speedMult;
        node.y += node.vy * speedMult;

        // Bounce
        if (node.x < 0 || node.x > width) node.vx *= -1;
        if (node.y < 0 || node.y > height) node.vy *= -1;

        // Draw Point
        ctx.beginPath();
        ctx.fillStyle = isProcessing ? '#ffffff' : '#666666';
        ctx.arc(node.x, node.y, 2, 0, Math.PI * 2); // Bigger dots
        ctx.fill();

        // Connect nearby nodes
        for (let j = i + 1; j < nodes.length; j++) {
          const nodeB = nodes[j];
          const dx = node.x - nodeB.x;
          const dy = node.y - nodeB.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < 180) { // Longer connection distance
            ctx.beginPath();
            const opacity = (1 - dist / 180) * 0.3; // Higher opacity
            ctx.strokeStyle = `rgba(0, 243, 255, ${opacity})`;
            ctx.moveTo(node.x, node.y);
            ctx.lineTo(nodeB.x, nodeB.y);
            ctx.stroke();
          }
        }
      }

      frameRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(frameRef.current);
    };
  }, [isProcessing, recursionDepth]);

  return (
    <div className="absolute inset-0 z-0 pointer-events-none">
        <canvas ref={canvasRef} className="w-full h-full block" />
    </div>
  );
};

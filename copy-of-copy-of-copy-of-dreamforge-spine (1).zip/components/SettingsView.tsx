
import React, { useState, useEffect } from 'react';
import { orchestrator } from '../bridge/orchestrator';
import { SurgicalContainer } from './SurgicalContainer';
import { realtimeBus } from '../bridge/realtime_bus';
import { InferenceSettings } from './settings/InferenceSettings';

// Helper interface for Diagnostics
interface DiagStep { id: string; name: string; status: string; message?: string; latency?: number; }

export const SettingsView: React.FC = () => {
  const [config, setConfig] = useState(orchestrator.getConfig());
  const [activeTab, setActiveTab] = useState<string>('gemini-flash');
  const [apiKeys, setApiKeys] = useState<Record<string, string>>({});
  
  // Diagnostic State
  const [diagSteps, setDiagSteps] = useState<DiagStep[]>([]);
  const [diagRunning, setDiagRunning] = useState(false);

  useEffect(() => {
      // Diagnostic Listener
      const cleanup = realtimeBus.on("DIAGNOSTICS", (payload: any) => {
          const { level, message, ...data } = payload;
          if (level === 'START') {
              setDiagSteps(data.steps.map((s: any) => ({ ...s, status: 'PENDING' })));
              setDiagRunning(true);
          } else if (level === 'STEP_COMPLETE') {
              setDiagSteps(prev => prev.map(s => s.id === message ? { ...s, status: data.status, message: data.error || data.info, latency: data.latency } : s));
          } else if (level === 'COMPLETE') {
              setDiagRunning(false);
          }
      });
      return cleanup;
  }, []);

  const handleUpdate = (updates: any) => {
    orchestrator.setConfig(updates);
    setConfig(orchestrator.getConfig());
  };

  const handleKeyUpdate = (provider: string, key: string) => {
      const newKeys = { ...apiKeys, [provider]: key };
      setApiKeys(newKeys);
      orchestrator.setConfig({ keys: newKeys });
  };

  const runDiagnostics = () => {
      setDiagRunning(true);
      orchestrator.runSystemCheck();
  };

  return (
    <div className="p-8 h-full overflow-y-auto space-y-6 bg-black/80 font-mono">
      <h2 className="text-xl font-black text-surgery-cyan mb-6 tracking-widest flex items-center gap-2">
          <span>⚙️</span> SYSTEM_CONFIGURATION
      </h2>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* 1. INFERENCE ENGINE (Modularized) */}
          <SurgicalContainer title="NEURAL_LINK_PROTOCOL" className="p-4">
              <InferenceSettings 
                  config={config} 
                  onUpdate={handleUpdate}
                  activeTab={activeTab}
                  onTabChange={setActiveTab}
                  apiKeys={apiKeys}
                  onKeyUpdate={handleKeyUpdate}
              />
          </SurgicalContainer>

          {/* 2. DIAGNOSTICS */}
          <SurgicalContainer title="SYSTEM_DIAGNOSTICS" className="p-4 space-y-4 border-l-4 border-dream-magenta/50">
              <div className="flex justify-between items-center mb-2">
                  <span className="text-[10px] font-bold text-gray-400">STACK INTEGRITY TEST</span>
                  <button 
                      onClick={runDiagnostics}
                      disabled={diagRunning}
                      className="px-4 py-2 bg-dream-magenta/10 border border-dream-magenta text-dream-magenta hover:bg-dream-magenta hover:text-black transition-all text-[10px] font-bold tracking-widest uppercase disabled:opacity-50 disabled:grayscale"
                  >
                      {diagRunning ? 'RUNNING...' : 'RUN DIAGNOSTICS'}
                  </button>
              </div>
              <div className="space-y-1 bg-black/40 p-2 rounded-sm border border-white/5 min-h-[150px]">
                  {diagSteps.length === 0 && !diagRunning && (
                      <div className="text-center text-gray-600 text-[10px] italic pt-12">System Ready.<br/>Awaiting diagnostic trigger.</div>
                  )}
                  {diagSteps.map(step => (
                      <div key={step.id} className="flex justify-between items-center text-[10px] font-mono p-1 border-b border-white/5 last:border-0">
                          <div className="flex items-center gap-2">
                              <div className={`w-2 h-2 rounded-full ${step.status === 'PENDING' ? 'bg-gray-700' : step.status === 'SUCCESS' ? 'bg-green-500' : step.status === 'RUNNING' ? 'bg-yellow-500 animate-pulse' : 'bg-red-500'}`} />
                              <span className="text-gray-300 font-bold">{step.name}</span>
                          </div>
                          <span className={`text-[9px] ${step.status === 'FAIL' ? 'text-red-400' : 'text-gray-500'}`}>
                              {step.message} {step.latency ? `(${step.latency}ms)` : ''}
                          </span>
                      </div>
                  ))}
              </div>
          </SurgicalContainer>

          {/* 3. TOPOLOGY */}
          <SurgicalContainer title="COMBAT_TOPOLOGY" className="p-4">
              <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold text-dream-accent mb-2">FIGHT_MODE</label>
                  <select 
                    value={config.fightMode || 'DUEL_1V1'} 
                    onChange={(e) => handleUpdate({ fightMode: e.target.value })}
                    className="bg-black border border-dream-accent/50 text-dream-accent text-xs p-2 rounded-sm uppercase font-bold outline-none focus:bg-dream-accent/10 transition-colors"
                  >
                      <option value="DUEL_1V1">DUEL (1v1)</option>
                      <option value="TAG_TEAM_2V2">TAG TEAM (2v2)</option>
                      <option value="BOSS_RUSH_3V1">BOSS RUSH (3v1)</option>
                      <option value="SWARM_4_WAY">SWARM (4-WAY)</option>
                  </select>
                  <p className="text-[9px] text-gray-600 mt-2">
                      Defines the adversarial configuration for the internal reasoning loop. 
                      Larger swarms consume more tokens but produce higher entropy.
                  </p>
              </div>
          </SurgicalContainer>
      </div>
    </div>
  );
};

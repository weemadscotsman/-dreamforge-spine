
import React, { useEffect, useRef } from "react";
import { realtimeBus } from "../bridge/realtime_bus";
import { SpineEvent } from "../spine/events";

interface MatrixRainProps {
  tension: number;
  systemStatus: 'IDLE' | 'PROCESSING' | 'ERROR';
  fightStage?: 'IDLE' | 'PREP' | 'CANDIDATE' | 'CHALLENGER' | 'CLASH'; 
  lastWinner?: "candidate" | "challenger";
  impact?: { type: 'DISTILL' | 'MEMORY' | 'CONSTRAINT' | 'WIN_CANDIDATE' | 'WIN_CHALLENGER' | null, timestamp: number };
}

const symbols = "アカサタナハマヤラガザダバパキシチニヒミリギジヂビピXYZ012345789<>^v";

export const MatrixRain: React.FC<MatrixRainProps> = ({ tension, systemStatus, fightStage, lastWinner, impact }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const flashRef = useRef<{ color: string, alpha: number }>({ color: '', alpha: 0 });
  const overrideTintRef = useRef<string | null>(null);
  const shearRef = useRef<number>(0);
  const zoomRef = useRef<number>(1.0);

  useEffect(() => {
      // SPINE BUS LISTENER
      const cleanup = realtimeBus.on("SPINE_EVENT", (e: SpineEvent) => {
          switch (e.type) {
              case "CYCLE_WINNER":
                  // Tint rain based on winner
                  overrideTintRef.current = e.winner === "challenger" ? "rgb(255, 60, 60)" : "rgb(0, 255, 160)";
                  // Fade out tint after 2s
                  setTimeout(() => overrideTintRef.current = null, 2000);
                  break;
              case "CONTRADICTION_DETECTED":
                  // Shear font
                  shearRef.current = e.weight * 0.5;
                  break;
              case "LEDGER_SIZE_DELTA":
                  // Slight zoom
                  zoomRef.current += e.delta > 0 ? -0.01 : 0.01;
                  break;
          }
      });
      return cleanup;
  }, []);

  useEffect(() => {
      // Trigger flash on impact change
      if (impact?.type) {
          let color = '';
          switch (impact.type) {
              case 'DISTILL': color = '200, 0, 255'; break; // Purple
              case 'MEMORY': color = '255, 255, 255'; break; // White flash
              case 'CONSTRAINT': color = '255, 0, 0'; break; // Red flash
              case 'WIN_CANDIDATE': color = '0, 255, 150'; break; // Green bloom
              case 'WIN_CHALLENGER': color = '255, 50, 50'; break; // Red bloom
          }
          flashRef.current = { color, alpha: 0.8 }; // High alpha for visibility
      }
  }, [impact]);

  useEffect(() => {
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext("2d")!;
    let width = canvas.width = window.innerWidth;
    let height = canvas.height = window.innerHeight;
    
    const fontSize = 12; // Larger font

    let columns = Math.floor(width / fontSize);
    let drops = Array(columns).fill(0);

    const handleResize = () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
      columns = Math.floor(width / fontSize);
      drops = Array(columns).fill(0);
    };

    window.addEventListener("resize", handleResize);

    let animationFrameId: number;
    let frameCount = 0; 

    const draw = () => {
      frameCount++;

      // Decay effects
      if (flashRef.current.alpha > 0.01) flashRef.current.alpha *= 0.90;
      if (shearRef.current > 0.01) shearRef.current *= 0.95;
      
      // Reset zoom slowly
      zoomRef.current += (1.0 - zoomRef.current) * 0.01;

      // Trail effect - INCREASED OPACITY FADE to clear tails faster/cleaner
      ctx.fillStyle = "rgba(0, 0, 0, 0.2)"; 
      ctx.fillRect(0, 0, width, height);
      
      // Draw Flash overlay
      if (flashRef.current.alpha > 0) {
          // Use 'lighter' blend mode for impact
          ctx.globalCompositeOperation = 'lighter';
          ctx.fillStyle = `rgba(${flashRef.current.color}, ${flashRef.current.alpha * 0.4})`;
          ctx.fillRect(0, 0, width, height);
          ctx.globalCompositeOperation = 'source-over';
      }

      ctx.save();
      
      // Apply Zoom (Centered)
      if (zoomRef.current !== 1.0) {
          ctx.translate(width/2, height/2);
          ctx.scale(zoomRef.current, zoomRef.current);
          ctx.translate(-width/2, -height/2);
      }

      // Apply Shear
      if (shearRef.current > 0.01) {
          ctx.transform(1, 0, shearRef.current, 1, 0, 0); 
      }

      // Determine Base Color
      // Default: Brighter Blue/Green
      let r=50, g=255, b=220; 
      
      if (systemStatus === 'ERROR') { r=255; g=0; b=60; }
      else if (fightStage && fightStage !== 'IDLE') {
          if (fightStage === 'CANDIDATE') { r=0; g=255; b=100; } 
          else if (fightStage === 'CHALLENGER') { r=255; g=50; b=50; }
          else if (fightStage === 'CLASH') { r=200; g=100; b=255; }
          else if (fightStage === 'PREP') { r=255; g=220; b=100; }
      }
      
      // Tension Shift: Shift towards Magenta/White at high tension
      if (tension > 0) {
          r = Math.min(255, r + (200 * tension));
          g = Math.max(0, g - (100 * tension));
          b = Math.max(0, b - (50 * tension));
      }

      let colorStr = `rgba(${Math.round(r)}, ${Math.round(g)}, ${Math.round(b)}, 0.9)`;
      
      // OVERRIDE FROM SPINE BUS
      if (overrideTintRef.current) {
          colorStr = overrideTintRef.current.replace("rgb", "rgba").replace(")", ", 1.0)");
      }

      ctx.font = `bold ${fontSize}px "JetBrains Mono", monospace`;

      let speedDivisor = 2; // Faster by default
      if (systemStatus === 'PROCESSING') speedDivisor = 1;
      if (fightStage === 'CANDIDATE' || fightStage === 'CHALLENGER') speedDivisor = 1;
      if (tension > 0.5) speedDivisor = 1;

      const shouldMove = frameCount % speedDivisor === 0;

      drops.forEach((y, index) => {
        const text = symbols[Math.floor(Math.random() * symbols.length)];
        const x = index * fontSize;
        
        // Random "glitch" drops that are brighter
        const isGlitch = Math.random() > 0.98;
        
        ctx.fillStyle = isGlitch ? '#ffffff' : colorStr;
        
        // During CLASH, characters shake
        let renderX = x;
        if (fightStage === 'CLASH') {
            renderX += (Math.random() - 0.5) * 4;
        }

        ctx.fillText(text, renderX, y * fontSize);

        if (shouldMove) {
          if (y * fontSize > height && Math.random() > 0.975) {
            drops[index] = 0;
          } else {
            drops[index] = y + 1;
          }
        }
      });

      ctx.restore();
      animationFrameId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
        window.removeEventListener("resize", handleResize);
        cancelAnimationFrame(animationFrameId);
    };
  }, [tension, systemStatus, fightStage, lastWinner]); 

  return <canvas id="matrix-rain-bg" ref={canvasRef} className="absolute inset-0 z-0 pointer-events-none" />;
};


import React from 'react';

interface SidebarProps {
  activeView: string;
  onViewChange: (view: string) => void;
  systemStatus: 'IDLE' | 'PROCESSING' | 'ERROR';
}

const NAV_ITEMS = [
  { id: 'SPINE', label: 'CORTEX', icon: '🧠' },
  { id: 'TERMINAL', label: 'DEBUG', icon: '>_' },
  { id: 'MODULES', label: 'SYSTEM', icon: '💠' },
  { id: 'DISTILLATION', label: 'RULES', icon: '⚗️' },
  { id: 'LATTICE', label: 'LATENT', icon: '🕸️' },
  { id: 'MEMORY', label: 'MEM', icon: '💾' },
  { id: 'SETTINGS', label: 'CONF', icon: '⚙️' },
];

export const Sidebar: React.FC<SidebarProps> = ({ activeView, onViewChange, systemStatus }) => {
  return (
    <nav className="w-full md:w-16 h-full bg-surgery-dark flex flex-row md:flex-col items-center justify-between md:justify-start z-30 shrink-0 py-2 md:py-4 gap-2 md:gap-4 px-2 md:px-0">
      
      {/* HEADER GROUP (Status + Logo) */}
      <div className="flex md:flex-col items-center gap-3 md:gap-4 shrink-0">
          {/* STATUS LED */}
          <div className={`w-3 h-3 rounded-full shadow-[0_0_10px_currentColor] ${
              systemStatus === 'PROCESSING' ? 'bg-surgery-cyan animate-pulse text-surgery-cyan' : 
              systemStatus === 'ERROR' ? 'bg-surgery-red text-surgery-red' : 
              'bg-gray-800 text-gray-800'
          }`} />

          {/* TEXT LOGO - Vertical on desktop, normal on mobile */}
          <div className="md:[writing-mode:vertical-rl] text-[10px] font-bold tracking-[0.2em] md:tracking-[0.3em] text-surgery-text opacity-50 md:py-4 md:border-b border-surgery-border/30 whitespace-nowrap">
            DREAMFORGE
          </div>
      </div>

      {/* NAV ICONS */}
      <div className="flex md:flex-col gap-2 md:gap-4 overflow-x-auto md:overflow-visible scrollbar-hide w-full md:w-auto px-2 md:px-2 items-center md:items-stretch">
        {NAV_ITEMS.map((item) => {
          const isActive = activeView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id)}
              className={`
                aspect-square h-8 md:h-auto flex items-center justify-center rounded-sm transition-all relative group shrink-0
                ${isActive 
                  ? 'bg-surgery-cyan text-black shadow-[0_0_15px_rgba(0,240,255,0.3)]' 
                  : 'bg-surgery-panel text-gray-600 hover:text-surgery-white hover:border hover:border-surgery-text'
                }
              `}
              title={item.label}
            >
              <span className="text-sm md:text-lg font-mono font-bold">{item.icon}</span>
              
              {/* Tooltip (Desktop Only) */}
              <div className="hidden md:block absolute left-full ml-4 bg-surgery-panel border border-surgery-border px-2 py-1 text-[10px] text-surgery-white opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 transition-opacity">
                {item.label}
              </div>
            </button>
          );
        })}
      </div>

      {/* BOTTOM MARKER */}
      <div className="hidden md:block text-[8px] font-mono text-gray-700">v0.95</div>
    </nav>
  );
};

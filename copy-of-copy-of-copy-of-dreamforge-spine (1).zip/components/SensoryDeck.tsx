
import React from 'react';
import { CompetitionRing } from './CompetitionRing';
import { DistillationHUD } from './DistillationHUD';
import { VisionModule } from './VisionModule';
import { WebcamModule } from './WebcamModule';
import { WeightedHeuristic } from '../distillation/types';

interface Props {
    heuristics: WeightedHeuristic[];
    active?: boolean;
}

export const SensoryDeck: React.FC<Props> = ({ heuristics, active }) => {
    return (
        <div className="flex flex-col h-full w-full bg-[#050508] border-b border-surgery-border/30">
            
            {/* 1. EVOLUTION (Compact Row) */}
            <div className="shrink-0 h-[100px] flex border-b border-surgery-border/20 bg-black/20 relative">
                {/* Background Label */}
                <div className="absolute top-1 left-1 text-[8px] font-bold text-gray-700 pointer-events-none tracking-widest z-0">
                    EVOLUTION_STATE
                </div>

                <div className="w-[100px] shrink-0 flex items-center justify-center border-r border-surgery-border/20 z-10">
                    <CompetitionRing heuristics={heuristics} size={80} />
                </div>
                <div className="flex-1 overflow-hidden z-10">
                    <DistillationHUD heuristics={heuristics} className="h-full border-none bg-transparent p-2" />
                </div>
            </div>

            {/* 2. OPTIC & BIO FEEDS (Shared Space) */}
            <div className="flex-1 min-h-0 flex flex-col relative">
                <div className="flex-1 min-h-0 border-b border-surgery-border/20 relative">
                    <div className="absolute top-1 left-2 text-[8px] font-bold text-gray-600 z-10 pointer-events-none uppercase tracking-widest bg-black/50 px-1 rounded">
                        OPTIC_FEED
                    </div>
                    <VisionModule compact />
                </div>
                <div className="flex-1 min-h-0 relative">
                    <div className="absolute top-1 left-2 text-[8px] font-bold text-gray-600 z-10 pointer-events-none uppercase tracking-widest bg-black/50 px-1 rounded">
                        BIO_FEED
                    </div>
                    <WebcamModule compact />
                </div>
            </div>

        </div>
    );
};

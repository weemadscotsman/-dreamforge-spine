
import React, { useEffect, useState } from 'react';
import { Strategy, strategyEngine, graveyard } from '../core/strategy';
import { realtimeBus } from '../bridge/realtime_bus';

export const StrategyPanel: React.FC = () => {
  const [strategies, setStrategies] = useState<Strategy[]>(strategyEngine.getAll());
  const [deadCount, setDeadCount] = useState(graveyard.strategies.length);

  useEffect(() => {
    // Poll for updates (Strategies update internally frequently)
    const timer = setInterval(() => {
        setStrategies([...strategyEngine.getAll()]);
        setDeadCount(graveyard.strategies.length);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="bg-[#050508]/80 border border-surgery-border rounded-sm overflow-hidden flex flex-col h-full">
      <div className="p-2 border-b border-surgery-border bg-surgery-dark flex justify-between items-center">
        <h3 className="text-[10px] font-mono font-bold tracking-widest text-dream-accent">ACTIVE_STRATEGIES</h3>
        <span className="text-[9px] text-gray-500">{strategies.length} ACTIVE / {deadCount} DEAD</span>
      </div>
      
      <div className="flex-1 overflow-y-auto p-2 space-y-2">
        {strategies.map(s => (
          <div key={s.id} className="bg-black/40 border border-white/5 p-2 rounded-sm relative overflow-hidden group">
            
            {/* Fitness Bar Background */}
            <div 
                className={`absolute top-0 left-0 h-full opacity-10 transition-all duration-500 ${s.fitness > 0 ? 'bg-green-500' : 'bg-red-500'}`}
                style={{ width: `${Math.min(100, Math.abs(s.fitness) * 100)}%` }}
            />

            <div className="flex justify-between items-start relative z-10">
                <span className="text-[10px] font-bold text-gray-300 group-hover:text-white transition-colors">{s.description}</span>
                <span className={`text-[9px] font-mono font-bold ${s.fitness > 0 ? 'text-green-400' : 'text-red-400'}`}>
                    FIT:{s.fitness.toFixed(2)}
                </span>
            </div>
            
            <div className="flex justify-between items-center mt-1 relative z-10 text-[8px] font-mono text-gray-500">
                <span>AGE: {s.age}</span>
                <span>RISK: {s.riskProfile.toFixed(1)}</span>
                <span>FAILS: {s.failures}</span>
            </div>

            {/* Status Indicator */}
            {s.status === 'FOSSILIZED' && (
                <div className="absolute right-1 top-1 text-[8px] bg-gray-700 text-gray-300 px-1 rounded">FOSSIL</div>
            )}
          </div>
        ))}
        {strategies.length === 0 && (
            <div className="text-gray-600 text-[10px] text-center italic mt-4">No active strategies.</div>
        )}
      </div>
    </div>
  );
};

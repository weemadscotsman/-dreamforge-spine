import React from 'react';

interface Props {
  children: React.ReactNode;
  title?: string;
  className?: string;
  headerContent?: React.ReactNode;
  active?: boolean;
}

export const SurgicalContainer: React.FC<Props> = ({ 
  children, 
  title, 
  className = '', 
  headerContent,
  active = false
}) => {
  return (
    <div className={`flex flex-col relative border border-surgery-border bg-surgery-panel/50 backdrop-blur-sm transition-colors duration-300 ${active ? 'border-surgery-cyan/50' : ''} ${className}`}>
      
      {/* DECORATION: Corner Brackets */}
      <div className={`absolute -top-px -left-px w-2 h-2 border-t border-l ${active ? 'border-surgery-cyan' : 'border-surgery-text'} opacity-50`} />
      <div className={`absolute -top-px -right-px w-2 h-2 border-t border-r ${active ? 'border-surgery-cyan' : 'border-surgery-text'} opacity-50`} />
      <div className={`absolute -bottom-px -left-px w-2 h-2 border-b border-l ${active ? 'border-surgery-cyan' : 'border-surgery-text'} opacity-50`} />
      <div className={`absolute -bottom-px -right-px w-2 h-2 border-b border-r ${active ? 'border-surgery-cyan' : 'border-surgery-text'} opacity-50`} />

      {title && (
        <div className="flex justify-between items-center px-3 py-2 border-b border-surgery-border bg-surgery-dark/80">
          <div className="flex items-center gap-2">
            <div className={`w-1 h-3 ${active ? 'bg-surgery-cyan' : 'bg-surgery-border'}`} />
            <span className={`text-[10px] font-mono font-bold tracking-[0.2em] uppercase ${active ? 'text-surgery-cyan' : 'text-surgery-text'}`}>
              {title}
            </span>
          </div>
          {headerContent && (
            <div className="flex items-center gap-2 text-[10px] font-mono">
              {headerContent}
            </div>
          )}
        </div>
      )}
      
      <div className="flex-1 min-h-0 relative">
        {children}
        
        {/* DECORATION: Background Grid */}
        <div className="absolute inset-0 pointer-events-none opacity-[0.03] bg-[linear-gradient(rgba(255,255,255,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.1)_1px,transparent_1px)] bg-[size:20px_20px]" />
      </div>
    </div>
  );
};
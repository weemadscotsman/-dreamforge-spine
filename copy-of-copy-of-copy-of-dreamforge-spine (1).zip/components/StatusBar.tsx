
import React from 'react';

interface StatusBarProps {
  phase: 'idle' | 'thinking' | 'evaluating' | 'refining' | 'stopped';
  currentDepth: number;
  maxDepth: number;
  stopReason?: string;
  score?: number;
}

export const StatusBar: React.FC<StatusBarProps> = ({
  phase,
  currentDepth,
  maxDepth,
  stopReason,
  score
}) => {
  const getPhaseText = () => {
    switch (phase) {
      case 'idle': return '⏸️ IDLE - AWAITING INPUT';
      case 'thinking': return '🧠 GENERATING THOUGHT...';
      case 'evaluating': return '🔍 EVALUATING QUALITY...';
      case 'refining': return '✨ REFINING ANSWER...';
      case 'stopped': return '✅ SEQUENCE COMPLETE';
      default: return 'UNKNOWN';
    }
  };
  
  const getStopReasonText = () => {
    if (!stopReason) return null;
    
    const reasons: Record<string, string> = {
      'MAX_DEPTH': '⚠️ STOP: MAX DEPTH REACHED',
      'QUALITY_SUFFICIENT': '✅ STOP: QUALITY SUFFICIENT',
      'QUALITY_POOR': '❌ RETRY: QUALITY LOW',
      'MANUAL': '🛑 STOP: MANUAL INTERVENTION',
      'ERROR': '🔥 STOP: SYSTEM ERROR'
    };
    
    return reasons[stopReason] || `STOP: ${stopReason}`;
  };
  
  const getReasonColor = () => {
      if (!stopReason) return 'text-gray-500';
      if (stopReason === 'QUALITY_SUFFICIENT') return 'text-green-400';
      if (stopReason.includes('MAX')) return 'text-yellow-400';
      return 'text-red-400';
  };
  
  return (
    <div className="flex items-center gap-4 bg-black/40 border-b border-surgery-border px-4 py-2 font-mono text-[9px] uppercase tracking-wider">
      <div className={`font-bold ${phase !== 'idle' && phase !== 'stopped' ? 'text-surgery-cyan animate-pulse' : 'text-gray-500'}`}>
          {getPhaseText()}
      </div>
      
      {phase !== 'idle' && (
        <div className="text-gray-400">
          DEPTH: <span className="text-white">{currentDepth}</span> / {maxDepth}
        </div>
      )}
      
      {score !== undefined && (
        <div className="text-gray-400">
          QUALITY: <span className={score > 80 ? 'text-green-400' : score > 50 ? 'text-yellow-400' : 'text-red-400'}>{score.toFixed(0)}%</span>
        </div>
      )}
      
      {stopReason && (
        <div className={`ml-auto font-bold ${getReasonColor()}`}>
          {getStopReasonText()}
        </div>
      )}
    </div>
  );
};

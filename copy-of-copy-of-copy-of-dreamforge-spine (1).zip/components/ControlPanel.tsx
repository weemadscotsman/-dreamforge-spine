
import React, { useState, useEffect } from 'react';
import { orchestrator } from '../bridge/orchestrator';
import { autoRun, stopAutoLoop } from '../autonomous/auto_loop';
import { startDreamMode, stopDreamMode, isDreaming } from '../engine/autorun/autorun';
import { ledger } from '../engine/beliefs/hypothesis_ledger';
import { realtimeBus } from '../bridge/realtime_bus';
import { FightMode } from '../core/types';
import { StatusBar } from './StatusBar';

interface ControlPanelProps {
    onOpenSettings?: () => void;
}

type OpMode = 'MANUAL' | 'DREAM' | 'AUTO';

export const ControlPanel: React.FC<ControlPanelProps> = ({ onOpenSettings }) => {
  const [opMode, setOpMode] = useState<OpMode>('MANUAL');
  const [distilling, setDistilling] = useState(false);
  const [opticActive, setOpticActive] = useState(false);
  const [currentMode, setCurrentMode] = useState<FightMode>('SWARM_4_WAY');
  const [statusMsg, setStatusMsg] = useState('');
  
  // Status Bar State
  const [systemState, setSystemState] = useState<{
      phase: 'idle' | 'thinking' | 'evaluating' | 'refining' | 'stopped';
      currentDepth: number;
      maxDepth: number;
      stopReason?: string;
      score?: number;
  }>({
      phase: 'idle',
      currentDepth: 0,
      maxDepth: 5,
      stopReason: undefined,
      score: undefined
  });

  useEffect(() => {
      if (isDreaming()) setOpMode('DREAM');
      
      const cleanupAuto = realtimeBus.on("AUTO_STATUS", (payload: any) => {
          if (payload.state === 'STARTED') setOpMode('AUTO');
          if (payload.state === 'STOPPED' || payload.state === 'STOPPING') setOpMode('MANUAL');
      });

      const cleanupDream = realtimeBus.on("DREAM_STATUS", (payload: any) => {
          if (payload.active && opMode !== 'AUTO') setOpMode('DREAM');
          if (!payload.active && opMode === 'DREAM') setOpMode('MANUAL');
      });

      const cleanupOptic = realtimeBus.on("VISION_STATUS", (payload: any) => {
          setOpticActive(!!payload.active);
      });

      const cleanupLog = realtimeBus.on("SYSTEM_LOG", (payload: any) => {
          if (payload.message && (
              payload.message.includes("Stopping") || 
              payload.message.includes("Converged") || 
              payload.message.includes("Plateau") ||
              payload.message.includes("Retrying")
          )) {
              setStatusMsg(payload.message);
              setTimeout(() => setStatusMsg(''), 5000);
          }
      });
      
      // Hook into RECURSOR events for StatusBar
      const cleanupRecursor = realtimeBus.on("SPINE_EVENT", (e: any) => {
          if (e.type === 'CYCLE_WINNER') {
              setSystemState(s => ({ ...s, score: e.score }));
          }
      });
      
      const cleanupBridgeLogs = realtimeBus.on("SYSTEM_LOG", (e: any) => {
          if (e.module === 'RECURSOR') {
              if (e.message.includes('CYCLE')) {
                  const match = e.message.match(/CYCLE (\d+)/);
                  if (match) setSystemState(s => ({ ...s, phase: 'thinking', currentDepth: parseInt(match[1]) }));
              }
              if (e.message.includes('Evaluating')) setSystemState(s => ({ ...s, phase: 'evaluating' }));
              if (e.message.includes('Refining')) setSystemState(s => ({ ...s, phase: 'refining' }));
              if (e.message.includes('STOPPED')) {
                  setSystemState(s => ({ ...s, phase: 'stopped', stopReason: e.message.split(': ')[1] }));
              }
          }
      });

      setCurrentMode(orchestrator.getConfig().fightMode || 'SWARM_4_WAY');
      
      return () => {
          cleanupAuto();
          cleanupDream();
          cleanupOptic();
          cleanupLog();
          cleanupRecursor();
          cleanupBridgeLogs();
      };
  }, [opMode]);

  const handleModeSelect = (target: OpMode) => {
      if (opMode === 'AUTO') stopAutoLoop();
      if (opMode === 'DREAM') stopDreamMode();

      if (target === 'AUTO') {
          realtimeBus.emit("STRATEGY_LOG", { level: "INFO", message: "OP_MODE: AUTO_LOOP ENGAGED" });
          autoRun(50);
      } else if (target === 'DREAM') {
          realtimeBus.emit("STRATEGY_LOG", { level: "INFO", message: "OP_MODE: DREAM_STATE ENGAGED" });
          startDreamMode();
      } else {
          realtimeBus.emit("STRATEGY_LOG", { level: "INFO", message: "OP_MODE: MANUAL OVERRIDE" });
      }
      setOpMode(target);
  };

  const forceDistill = () => {
      setDistilling(true);
      setTimeout(() => {
          orchestrator.distillSystem();
          setDistilling(false);
      }, 500);
  };

  const fragment = () => {
      ledger.fragment();
      realtimeBus.emit("SPINE_EVENT", { type: "PRESSURE_CURVE", slope: 0 }); 
  };

  const handleFightModeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
      const mode = e.target.value as FightMode;
      setCurrentMode(mode);
      orchestrator.setConfig({ fightMode: mode });
  };

  return (
    <div className="flex flex-col gap-0 w-full font-mono text-[10px]">
        {/* ROW 0: STATUS BAR */}
        <div className="mb-2">
            <StatusBar {...systemState} />
        </div>

        {/* ROW 1: MODE SWITCHER */}
        <div className="flex w-full bg-black border border-surgery-border rounded-sm h-7 overflow-hidden p-0.5 gap-0.5 mb-2">
            <ModeBtn label="MANUAL" active={opMode === 'MANUAL'} onClick={() => handleModeSelect('MANUAL')} color="cyan" />
            <ModeBtn label="DREAM" active={opMode === 'DREAM'} onClick={() => handleModeSelect('DREAM')} color="purple" />
            <ModeBtn label="AUTO" active={opMode === 'AUTO'} onClick={() => handleModeSelect('AUTO')} color="red" />
        </div>

        {/* ROW 2: TOOLS & CONFIG */}
        <div className="flex gap-2 h-8">
            <div className="flex-1 grid grid-cols-4 gap-1">
                <ToolBtn icon="⚗️" active={distilling} onClick={forceDistill} color="green" title="Force Evolution" />
                <ToolBtn icon="👁️" active={opticActive} onClick={() => realtimeBus.emit("TRIGGER_OPTIC_SELECTION", {})} color="blue" title="Optic Link" />
                <ToolBtn icon="💥" onClick={fragment} color="orange" title="Entropy Shatter" />
                <ToolBtn icon="⚙️" onClick={() => onOpenSettings?.()} color="gray" title="System Config" />
            </div>
            
            {/* COMPACT TOPOLOGY SELECTOR */}
            <div className="w-[80px] bg-black border border-surgery-border rounded-sm flex items-center relative group hover:border-surgery-cyan/50 transition-colors">
                <select 
                    value={currentMode} 
                    onChange={handleFightModeChange}
                    className="w-full h-full bg-transparent text-[9px] appearance-none pl-2 pr-4 outline-none cursor-pointer text-surgery-cyan font-bold uppercase"
                >
                    <option value="DUEL_1V1">1v1</option>
                    <option value="TAG_TEAM_2V2">2v2</option>
                    <option value="BOSS_RUSH_3V1">3v1</option>
                    <option value="SWARM_4_WAY">4-WAY</option>
                </select>
                <div className="absolute right-1 top-1/2 -translate-y-1/2 pointer-events-none text-surgery-cyan opacity-50 text-[8px]">▼</div>
            </div>
        </div>

        {/* ROW 3: STATUS TOAST (Conditional) */}
        {statusMsg && (
            <div className="text-[9px] text-surgery-cyan bg-surgery-cyan/5 border-l-2 border-surgery-cyan px-2 py-1 animate-pulse truncate mt-2">
                {statusMsg}
            </div>
        )}
    </div>
  );
};

const ModeBtn: React.FC<{ label: string, active: boolean, onClick: () => void, color: 'cyan' | 'purple' | 'red' }> = ({ label, active, onClick, color }) => {
    const base = "flex-1 flex items-center justify-center font-bold tracking-wider transition-all duration-200 rounded-sm";
    const activeStyles = {
        cyan: 'bg-surgery-cyan text-black shadow-[0_0_10px_rgba(0,240,255,0.4)]',
        purple: 'bg-dream-magenta text-black shadow-[0_0_10px_rgba(255,0,255,0.4)]',
        red: 'bg-red-500 text-black shadow-[0_0_10px_rgba(255,50,50,0.4)]'
    };
    const inactiveStyles = {
        cyan: 'text-gray-500 hover:text-surgery-cyan hover:bg-surgery-cyan/10',
        purple: 'text-gray-500 hover:text-dream-magenta hover:bg-dream-magenta/10',
        red: 'text-gray-500 hover:text-red-500 hover:bg-red-500/10'
    };
    return (
        <button onClick={onClick} className={`${base} ${active ? activeStyles[color] : inactiveStyles[color]}`}>
            {label}
        </button>
    );
};

const ToolBtn: React.FC<{ icon: string, active?: boolean, color: string, onClick: () => void, title: string }> = ({ icon, active, color, onClick, title }) => {
    const colors: Record<string, string> = {
        green: 'hover:border-green-500/50 hover:text-green-400 hover:bg-green-500/10',
        orange: 'hover:border-orange-500/50 hover:text-orange-400 hover:bg-orange-500/10',
        blue: 'hover:border-blue-500/50 hover:text-blue-400 hover:bg-blue-500/10',
        gray: 'hover:border-white/50 hover:text-white hover:bg-white/10'
    };
    
    return (
        <button 
            onClick={onClick} 
            title={title}
            className={`
                h-full flex items-center justify-center border rounded-sm transition-all duration-200 text-lg
                ${colors[color] || colors.gray}
                ${active ? 'bg-white/10 border-white/50 animate-pulse' : 'border-surgery-border text-gray-500 bg-black'}
            `}
        >
            {icon}
        </button>
    );
};

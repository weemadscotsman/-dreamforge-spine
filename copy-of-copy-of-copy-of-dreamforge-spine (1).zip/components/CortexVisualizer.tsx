
import React from 'react';
import { FightHUD, FightState } from './FightHUD';
import { Sparkline } from './Sparkline';
import { AxiomPanel } from './AxiomPanel';
import { WeightedHeuristic } from '../distillation/types';

interface Props {
  fightState: FightState;
  deltas: number[]; // History of scores/deltas
  pressure: number[]; // History of total heuristic weight/pressure
  heuristics: WeightedHeuristic[];
  axioms: string[];
  className?: string;
}

export const CortexVisualizer: React.FC<Props> = ({ 
  fightState, 
  deltas, 
  pressure, 
  heuristics,
  axioms, 
  className = '' 
}) => {
  
  // Calculate aggregate stats for the Pressure Gauge
  const totalWeight = heuristics.reduce((acc, h) => acc + (Number(h.weight) || 0), 0);
  const activeCount = heuristics.filter(h => h.weight > 0.05).length;
  const violationCount = heuristics.filter(h => h.weight < 0.2).length; 

  const lastDelta = deltas.length > 0 ? Number(deltas[deltas.length - 1]) || 0 : 0;

  return (
    <div className={`flex flex-col gap-3 p-2 h-full ${className}`}>
        
        {/* 1. FIGHT GAUGE */}
        <div className="shrink-0">
            <FightHUD state={fightState} className="shadow-[0_0_20px_rgba(0,0,0,0.5)] w-full" />
        </div>

        {/* 2. METRICS */}
        <div className="grid grid-cols-2 gap-2 shrink-0">
            <div className="bg-black/40 border border-white/10 rounded-sm p-1.5 flex flex-col relative overflow-hidden">
                <div className="text-[7px] font-mono text-dream-cyan tracking-widest mb-1 flex justify-between">
                    <span>DELTA</span>
                    <span className="text-white font-bold">{lastDelta.toFixed(1)}</span>
                </div>
                <Sparkline data={deltas} color="#00ff9d" height={30} min={0} max={100} />
            </div>

            <div className="bg-black/40 border border-white/10 rounded-sm p-1.5 flex flex-col relative overflow-hidden">
                <div className="text-[7px] font-mono text-dream-magenta tracking-widest mb-1 flex justify-between">
                    <span>PRESSURE</span>
                    <span className="text-white font-bold">{totalWeight.toFixed(2)}</span>
                </div>
                <Sparkline data={pressure} color="#ff00ff" height={30} />
            </div>
        </div>

        {/* 3. HEURISTIC STATUS */}
        <div className="flex justify-between items-center text-[8px] font-mono bg-white/5 p-1 rounded-sm border border-white/5 shrink-0">
            <span className="text-gray-400">RULES: <strong className="text-white">{activeCount}</strong></span>
            <span className="text-gray-400">WEAK: <strong className="text-dream-alert">{violationCount}</strong></span>
            <span className="text-gray-400">DOM: <strong className="text-dream-accent">{((activeCount / (heuristics.length || 1)) * 100).toFixed(0)}%</strong></span>
        </div>

        {/* 4. LIVE AXIOM FEED */}
        <div className="flex-1 min-h-0 border border-dream-cyan/20 bg-black/60 relative rounded-sm overflow-hidden">
            <AxiomPanel axioms={axioms} className="h-full border-none bg-transparent" />
            
            <div className="absolute top-1 right-1 flex items-center gap-1 pointer-events-none">
                <div className="w-1 h-1 bg-dream-alert rounded-full animate-pulse" />
                <span className="text-[7px] font-bold text-dream-alert tracking-widest">LIVE</span>
            </div>
        </div>
    </div>
  );
};


import React, { useMemo } from 'react';
import { WeightedHeuristic } from '../distillation/types';

interface Props {
  heuristics: WeightedHeuristic[];
  className?: string;
}

export const DistillationHUD: React.FC<Props> = ({ heuristics, className = '' }) => {
  const stats = useMemo(() => {
    if (heuristics.length === 0) return { count: 0, avg: "0.00", max: "0.00", dominant: "N/A", status: "OFF", statusColor: "text-gray-600" };
    
    const total = heuristics.reduce((acc, h) => acc + h.weight, 0);
    const avg = total / heuristics.length;
    const sorted = [...heuristics].sort((a,b) => b.weight - a.weight);
    const max = sorted[0].weight;
    
    let status = "FLUID";
    let statusColor = "text-dream-accent"; 
    
    if (max > 2.0) { status = "LOCKED"; statusColor = "text-dream-alert"; }
    else if (max > 0.8) { status = "STABLE"; statusColor = "text-blue-400"; }
    else if (max < 0.3) { status = "DRIFT"; statusColor = "text-yellow-400"; }

    return {
      count: heuristics.length,
      avg: avg.toFixed(2),
      max: max.toFixed(2),
      dominant: sorted[0].rule,
      status,
      statusColor
    };
  }, [heuristics]);

  return (
    <div className={`flex flex-col justify-center gap-2 ${className}`}>
      
      {/* Top Row Metrics */}
      <div className="grid grid-cols-3 gap-2 text-[9px] font-mono">
          <Metric label="GENOME" val={stats.count} />
          <Metric label="AVG_W" val={stats.avg} />
          <Metric label="MAX_W" val={stats.max} highlight />
      </div>

      {/* Dominant Strategy Text */}
      <div className="flex flex-col">
          <span className="text-[7px] text-gray-600 font-mono tracking-wider uppercase">Dominant Strategy</span>
          <span className="text-[9px] text-gray-300 font-mono truncate border-l-2 border-surgery-cyan/50 pl-2" title={stats.dominant}>
              {stats.dominant}
          </span>
      </div>

      {/* Status Pill */}
      <div className="flex items-center gap-2 mt-auto">
          <span className={`w-2 h-2 rounded-full ${stats.count > 0 ? 'bg-green-500 animate-pulse' : 'bg-gray-800'}`} />
          <span className={`text-[9px] font-black tracking-widest ${stats.statusColor}`}>
              {stats.status}
          </span>
      </div>
    </div>
  );
};

const Metric = ({ label, val, highlight }: { label: string, val: string | number, highlight?: boolean }) => (
    <div className="flex flex-col">
        <span className="text-[7px] text-gray-600 uppercase">{label}</span>
        <span className={`font-bold ${highlight ? 'text-white' : 'text-gray-400'}`}>{val}</span>
    </div>
);

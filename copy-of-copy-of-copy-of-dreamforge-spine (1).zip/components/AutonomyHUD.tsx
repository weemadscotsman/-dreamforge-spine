
import React, { useEffect, useState } from 'react';
import { realtimeBus } from '../bridge/realtime_bus';
import { AutonomyConstraints } from '../autonomy/constraints';
import { autonomyGovernor } from '../autonomy/autonomy_governor';

interface Props {
    className?: string;
}

export const AutonomyHUD: React.FC<Props> = ({ className = '' }) => {
  const [state, setState] = useState<AutonomyConstraints>(autonomyGovernor.getConstraints());
  const [lastVerdict, setLastVerdict] = useState<{outcome: string, risk: number} | null>(null);

  useEffect(() => {
    const cleanup = realtimeBus.on('CONSTRAINT_UPDATE', (newState: AutonomyConstraints) => {
        setState(newState);
    });
    
    // Listen for verdict results to show transient warnings
    const cleanupCycle = realtimeBus.on('TWIN_FIGHT_RESULT', (res: any) => {
        // We only get winner/score here, but let's assume we can infer safety
        // Logic: if score is barely passing (e.g. 75-80), it's risky
        setLastVerdict({ outcome: res.winner === 'candidate' ? 'ACCEPT' : 'REJECT', risk: res.score < 80 ? 1 : 0 });
        setTimeout(() => setLastVerdict(null), 5000);
    });

    return () => { cleanup(); cleanupCycle(); };
  }, []);

  if (!state) return null;

  const levelColor = {
      FREE: 'text-green-400 border-green-500/50 bg-green-900/10',
      ASSIST: 'text-blue-400 border-blue-500/50 bg-blue-900/10',
      PAUSE: 'text-yellow-400 border-yellow-500/50 bg-yellow-900/10',
      LOCKDOWN: 'text-red-500 border-red-500/50 bg-red-900/10'
  }[state.level];

  return (
    <div className={`font-mono text-[9px] p-2 border rounded-sm backdrop-blur-md transition-colors duration-300 ${levelColor} ${className}`}>
      <div className="flex justify-between items-center mb-2 border-b border-white/10 pb-1">
          <span className="font-bold tracking-widest">GOVERNOR</span>
          <span className="font-black bg-black/20 px-1 rounded">{state.level}</span>
      </div>
      
      <div className="grid grid-cols-2 gap-x-2 gap-y-1 opacity-90 mb-2">
          <div className="flex justify-between"><span>EXEC</span> <span className={state.allowExecution ? 'text-white' : 'text-white/30'}>{state.allowExecution ? 'ON' : 'OFF'}</span></div>
          <div className="flex justify-between"><span>WRITE</span> <span className={state.allowFileWrite ? 'text-white' : 'text-white/30'}>{state.allowFileWrite ? 'ON' : 'OFF'}</span></div>
          <div className="flex justify-between"><span>DEPTH</span> <span className="text-white">{state.maxRecursionDepth}</span></div>
          <div className="flex justify-between"><span>SPEECH</span> <span className={state.allowSpeech ? 'text-white' : 'text-white/30'}>{state.allowSpeech ? 'ON' : 'OFF'}</span></div>
      </div>
      
      {lastVerdict && lastVerdict.outcome === 'ACCEPT' && lastVerdict.risk > 0 && (
          <div className="mb-2 text-yellow-400 border border-yellow-500/30 bg-yellow-900/20 px-1 py-0.5 rounded text-center animate-pulse">
              ⚠️ VERDICT_ACCEPTED (WITH WARNINGS)
          </div>
      )}

      <div className="pt-1 border-t border-white/10 opacity-70 italic truncate" title={state.reason}>
          {state.reason}
      </div>
    </div>
  );
};

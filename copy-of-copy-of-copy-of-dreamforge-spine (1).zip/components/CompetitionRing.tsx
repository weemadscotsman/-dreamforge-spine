
import React, { useMemo } from 'react';
import { WeightedHeuristic } from '../distillation/types';

interface Props {
  heuristics: WeightedHeuristic[];
  className?: string;
  size?: number;
}

export const CompetitionRing: React.FC<Props> = ({ heuristics, className = '', size = 200 }) => {
  const data = useMemo(() => {
    const active = heuristics
      .filter(h => h.weight > 0.01)
      .sort((a, b) => b.weight - a.weight);

    const totalWeight = active.reduce((acc, h) => acc + h.weight, 0);
    const safeTotal = totalWeight || 1;

    let accumulatedAngle = 0;
    const center = size / 2;
    const radius = size * 0.4; // 40% of container
    const strokeWidth = size * 0.15;

    return active.map((h, i) => {
      const percentage = h.weight / safeTotal;
      const angle = percentage * 360;
      
      const startAngle = accumulatedAngle;
      const endAngle = accumulatedAngle + angle;
      accumulatedAngle += angle;

      // Color Logic
      let color = '#378e85'; 
      if (h.weight >= 0.15) color = '#00ffd5'; 
      else if (h.weight >= 0.05) color = '#ffb347'; 
      
      const startRad = (startAngle - 90) * (Math.PI / 180);
      const endRad = (endAngle - 90) * (Math.PI / 180);

      const x1 = center + radius * Math.cos(startRad);
      const y1 = center + radius * Math.sin(startRad);
      const x2 = center + radius * Math.cos(endRad);
      const y2 = center + radius * Math.sin(endRad);

      const largeArc = angle > 180 ? 1 : 0;

      const d = [
        `M ${x1} ${y1}`,
        `A ${radius} ${radius} 0 ${largeArc} 1 ${x2} ${y2}`
      ].join(' ');

      return {
        id: h.rule,
        d,
        color,
        percentage: (percentage * 100).toFixed(0),
        rule: h.rule,
        strokeWidth
      };
    });
  }, [heuristics, size]);

  const dominant = data.length > 0 ? data[0] : null;

  return (
    <div className={`relative flex items-center justify-center overflow-hidden ${className}`} style={{ width: size, height: size }}>
        {data.length === 0 ? (
           <div className="text-[9px] text-gray-700 italic">EMPTY</div>
        ) : (
           <svg width="100%" height="100%" viewBox={`0 0 ${size} ${size}`} className="overflow-visible">
              <circle cx={size/2} cy={size/2} r={size * 0.4} stroke="#1a1a20" strokeWidth={size * 0.15} fill="none" />
              {data.map((slice, i) => (
                <path 
                    key={i}
                    d={slice.d} 
                    stroke={slice.color} 
                    strokeWidth={slice.strokeWidth} 
                    fill="none" 
                    className="hover:brightness-150 transition-all cursor-crosshair"
                >
                    <title>{slice.rule} ({slice.percentage}%)</title>
                </path>
              ))}
              <text x="50%" y="55%" textAnchor="middle" fill="#888" fontSize={size * 0.2} fontFamily="monospace" fontWeight="bold">
                 {dominant ? `${dominant.percentage}%` : '0%'}
              </text>
           </svg>
        )}
    </div>
  );
};

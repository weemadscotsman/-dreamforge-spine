
import React, { useRef, useState, useEffect } from 'react';
import { orchestrator } from '../bridge/orchestrator';
import { realtimeBus } from '../bridge/realtime_bus';
import { SurgicalContainer } from './SurgicalContainer';
import { ModelAttachment } from '../model/types';

interface Props {
    compact?: boolean;
}

export const VisionModule: React.FC<Props> = ({ compact = false }) => {
    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [stream, setStream] = useState<MediaStream | null>(null);
    const [analyzing, setAnalyzing] = useState(false);
    const [monitoring, setMonitoring] = useState(false);
    const [monitorMode, setMonitorMode] = useState<'OBSERVE' | 'INTERCEPT'>('OBSERVE');
    const [analysisLog, setAnalysisLog] = useState<{timestamp: number, text: string, type: 'INFO' | 'ACTION'}[]>([]);
    const [error, setError] = useState<string | null>(null);
    const intervalRef = useRef<any>(null);
    const [sourceLabel, setSourceLabel] = useState<string>("NONE");

    // Remote Trigger Listener
    useEffect(() => {
        const cleanup = realtimeBus.on("TRIGGER_OPTIC_SELECTION", () => {
            selectSource();
        });
        return () => {
            cleanup();
            stopStream(); // cleanup stream on unmount
            if (intervalRef.current) clearInterval(intervalRef.current);
        };
    }, []);

    // Broadcast status changes
    useEffect(() => {
        realtimeBus.emit("VISION_STATUS", { active: !!stream });
    }, [stream]);

    // Restart monitoring if mode changes while running
    useEffect(() => {
        if (monitoring) {
            stopMonitoringLoop();
            startMonitoringLoop();
        }
    }, [monitorMode]);

    const selectSource = async () => {
        setError(null);
        try {
            // Stop existing if any
            if (stream) {
                stream.getTracks().forEach(track => track.stop());
            }

            // Universal capture request
            const s = await navigator.mediaDevices.getDisplayMedia({
                video: {
                    cursor: "always",
                    displaySurface: "monitor" 
                } as any,
                audio: false
            });
            
            const track = s.getVideoTracks()[0];
            setSourceLabel(track.label?.substring(0, 20) || "DISPLAY_SOURCE");

            // Handle user stopping the share via browser UI
            track.onended = () => {
                stopStream();
                setSourceLabel("SIGNAL_LOST");
            };
            
            if (videoRef.current) {
                videoRef.current.srcObject = s;
            }
            setStream(s);
            
            // Auto-start monitoring if source selected successfully
            setMonitoring(true);
            startMonitoringLoop();

        } catch (err: any) {
            console.error("Error starting screen capture:", err);
            
            // Emit to System Log for Terminal Visibility
            realtimeBus.emit("SYSTEM_LOG", {
                module: "VISION",
                level: "ERROR",
                message: `Capture Error: ${err.message || err.name}`,
                data: { error: err.name }
            });

            if (err.name === 'NotAllowedError') {
                setError("PERMISSION_DENIED / CANCELLED");
            } else if (err.name === 'OverconstrainedError') {
                setError("ADAPTER_INCOMPATIBLE");
            } else {
                setError(`CAPTURE_ERR: ${err.name}`);
            }
        }
    };

    const stopStream = () => {
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
            setStream(null);
        }
        if (videoRef.current) {
            videoRef.current.srcObject = null;
        }
        setMonitoring(false);
        stopMonitoringLoop();
        setSourceLabel("NONE");
    };

    const stopMonitoringLoop = () => {
        if (intervalRef.current) clearInterval(intervalRef.current);
        intervalRef.current = null;
    };

    const captureFrame = (): ModelAttachment | null => {
        if (!videoRef.current || !canvasRef.current) return null;
        const ctx = canvasRef.current.getContext('2d');
        if (!ctx) return null;

        // Capture at full resolution for text readability
        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
        ctx.drawImage(videoRef.current, 0, 0);

        const dataUrl = canvasRef.current.toDataURL('image/jpeg', 0.8);
        const base64 = dataUrl.split(',')[1];
        
        return {
            mimeType: 'image/jpeg',
            data: base64
        };
    };

    const analyzeSnapshot = async () => {
        const attachment = captureFrame();
        if (!attachment) return;

        setAnalyzing(true);
        try {
            // Enhanced Actionable Prompt
            const res = await orchestrator.runInternalTask(
                `[VISION_SNAPSHOT] DEEP SCAN. 
1. Describe the screen content concisely (Apps, Code, Text). 
2. Provide 3 STRATEGIC CHOICES or SUGGESTIONS for the user based on this context (e.g. Refactor function X, Reply to email, Close security hole).`,
                [attachment]
            );
            
            const logEntry = { timestamp: Date.now(), text: res.output, type: 'INFO' as const };
            setAnalysisLog(prev => [logEntry, ...prev]);
            
            realtimeBus.emit("SYSTEM_LOG", { module: "VISION", level: "INFO", message: "Snapshot Analyzed", data: { snippet: res.output.slice(0, 50) } });
        } catch (e: any) {
            console.error(e);
            const msg = (e.message.includes("429") || e.message.includes("quota")) ? "RATE LIMIT EXCEEDED" : `ERROR: ${e.message}`;
            setAnalysisLog(prev => [{ timestamp: Date.now(), text: msg, type: 'INFO' }, ...prev]);
        } finally {
            setAnalyzing(false);
        }
    };

    const startMonitoringLoop = () => {
        // Interval logic
        const intervalMs = monitorMode === 'INTERCEPT' ? 8000 : 15000;
        const prompt = monitorMode === 'INTERCEPT'
            ? "[VISION_INTERCEPT] ACTIVE WATCH: Monitor for critical events, errors, or security risks. If user needs help, output 'ACTION:' followed by a specific recommendation."
            : "[VISION_MONITOR] PASSIVE WATCH: Describe current user activity or screen state changes concisely.";

        intervalRef.current = setInterval(async () => {
            const attachment = captureFrame();
            if (!attachment) return;
            if (analyzing) return; // Skip if busy

            setAnalyzing(true);

            try {
                // We use a lighter call if possible, but runInternalTask is our best tool
                const res = await orchestrator.runInternalTask(prompt, [attachment]);
                
                setAnalysisLog(prev => [{ 
                    timestamp: Date.now(), 
                    text: `[${monitorMode}] ${res.output.slice(0, 200)}...`,
                    type: (monitorMode === 'INTERCEPT' && res.output.includes('ACTION') ? 'ACTION' : 'INFO') as 'INFO' | 'ACTION'
                }, ...prev].slice(0, 50));

            } catch (e: any) {
                if (e.message.includes("429")) {
                    setAnalysisLog(prev => [{ timestamp: Date.now(), text: "RATE LIMIT. PAUSING WATCH.", type: 'INFO' }, ...prev]);
                    stopMonitoringLoop();
                    setMonitoring(false);
                }
            } finally {
                setAnalyzing(false);
            }

        }, intervalMs);
    };

    const toggleMonitoring = () => {
        if (monitoring) {
            setMonitoring(false);
            stopMonitoringLoop();
        } else {
            setMonitoring(true);
            startMonitoringLoop();
        }
    };

    return (
        <div className={`flex ${compact ? 'flex-col h-full relative' : 'flex-row h-full p-4 gap-4'} w-full bg-[#050508] overflow-hidden`}>
            
            {/* --- TOP CONTROL BAR --- */}
            <div className="absolute top-0 left-0 w-full z-20 flex bg-[#0a0a0c] border-b border-surgery-border h-8 items-center px-2 justify-between shadow-lg">
                <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${stream ? 'bg-green-500 animate-pulse' : 'bg-gray-700'}`} />
                    <span className="text-[9px] font-bold text-gray-400 tracking-widest">OPTIC_LINK</span>
                </div>
                
                <div className="flex items-center gap-2">
                    <div className="bg-black border border-white/10 px-2 py-0.5 rounded-sm max-w-[120px] truncate text-[8px] font-mono text-gray-300 uppercase">
                        {sourceLabel}
                    </div>
                    <button 
                        onClick={selectSource}
                        className="flex items-center gap-1 px-2 py-1 bg-surgery-cyan/10 hover:bg-surgery-cyan/20 border border-surgery-cyan/30 text-surgery-cyan text-[8px] font-bold uppercase rounded-sm transition-all"
                    >
                        <span>▼</span> {stream ? "CHANGE" : "SELECT"}
                    </button>
                </div>
            </div>

            {/* Video Feed */}
            <div className={`flex flex-col gap-2 min-h-0 ${compact ? 'flex-1 pt-10' : 'flex-1 pt-10'}`}>
                <div className="relative flex-1 bg-black border border-surgery-cyan/30 flex items-center justify-center overflow-hidden rounded-sm group min-h-0">
                    {!stream && !error && (
                        <div className="flex flex-col items-center gap-3 opacity-60 hover:opacity-100 transition-opacity z-10">
                            <span className="text-surgery-cyan/50 text-4xl">❖</span>
                            <button 
                                onClick={selectSource}
                                className="px-4 py-2 border border-surgery-cyan text-surgery-cyan hover:bg-surgery-cyan hover:text-black transition-all font-bold tracking-widest text-[10px] uppercase"
                            >
                                INITIATE_CAPTURE
                            </button>
                        </div>
                    )}

                    {error && (
                        <div className="flex flex-col items-center gap-2 p-4 text-center z-10">
                            <span className="text-red-500 font-bold text-[10px] tracking-widest animate-pulse">ERROR: {error}</span>
                            <button 
                                onClick={selectSource}
                                className="px-3 py-1 border border-red-500/50 text-red-500 text-[9px] hover:bg-red-500/10"
                            >
                                RETRY_CONNECTION
                            </button>
                        </div>
                    )}
                    
                    <video 
                        ref={videoRef} 
                        autoPlay 
                        playsInline 
                        muted 
                        className={`w-full h-full object-contain absolute inset-0 ${!stream ? 'hidden' : ''}`} 
                    />
                    
                    {/* HUD Overlay */}
                    {stream && (
                        <div className="absolute inset-0 pointer-events-none z-0">
                            {/* Grid */}
                            <div className="absolute inset-0 opacity-20 bg-[linear-gradient(rgba(0,255,255,0.2)_1px,transparent_1px),linear-gradient(90deg,rgba(0,255,255,0.2)_1px,transparent_1px)] bg-[size:50px_50px]" />
                            
                            {/* Status Badge */}
                            {monitoring && (
                                <div className="absolute top-2 right-2 flex items-center gap-2">
                                    <div className={`w-2 h-2 rounded-full animate-pulse shadow-[0_0_10px_currentColor] ${monitorMode === 'INTERCEPT' ? 'bg-red-500 text-red-500' : 'bg-green-500 text-green-500'}`} />
                                    <span className={`font-bold text-[8px] tracking-widest bg-black/80 border border-white/10 px-1.5 py-0.5 rounded-sm ${monitorMode === 'INTERCEPT' ? 'text-red-500' : 'text-green-500'}`}>
                                        {monitorMode === 'INTERCEPT' ? 'INTERCEPT_ACTIVE' : 'PASSIVE_WATCH'}
                                    </span>
                                </div>
                            )}
                            
                            {/* Analyzing Indicator */}
                            {analyzing && (
                                <div className="absolute bottom-2 left-2 flex items-center gap-2 bg-black/80 px-2 py-1 border border-surgery-cyan/50 rounded-sm">
                                    <span className="w-1.5 h-1.5 bg-surgery-cyan animate-ping rounded-full"/>
                                    <span className="text-[8px] text-surgery-cyan font-bold tracking-widest">ANALYZING_FRAME</span>
                                </div>
                            )}
                        </div>
                    )}

                    {/* Compact Log Overlay (Inside Video Area) */}
                    {compact && analysisLog.length > 0 && (
                        <div className="absolute bottom-0 left-0 w-full h-[30%] bg-gradient-to-t from-black via-black/80 to-transparent p-2 font-mono text-[8px] text-gray-400 overflow-y-auto z-10">
                            <div className={`${analysisLog[0].type === 'ACTION' ? 'text-red-400' : 'text-surgery-cyan'} mb-1 font-bold sticky top-0`}>
                                {analysisLog[0].type === 'ACTION' ? 'INTERCEPT_DECISION:' : 'LATEST_INTEL:'}
                            </div>
                            {analysisLog[0].text}
                        </div>
                    )}
                </div>

                <div className="h-8 shrink-0 flex gap-2 mb-1">
                    <button 
                        onClick={analyzeSnapshot}
                        disabled={!stream || analyzing}
                        className="flex-1 border border-surgery-border hover:border-surgery-cyan hover:bg-surgery-cyan/10 text-surgery-white transition-all font-mono text-[9px] font-bold tracking-widest disabled:opacity-50"
                    >
                        {analyzing ? "SCANNING..." : "SNAPSHOT"}
                    </button>
                    
                    <div className="flex bg-black/40 border border-surgery-border rounded-sm overflow-hidden">
                        <button
                            onClick={() => setMonitorMode('OBSERVE')}
                            disabled={!stream}
                            className={`px-3 text-[9px] font-bold transition-all ${monitorMode === 'OBSERVE' ? 'bg-surgery-cyan text-black' : 'text-gray-500 hover:text-white'}`}
                        >
                            OBS
                        </button>
                        <button
                            onClick={() => setMonitorMode('INTERCEPT')}
                            disabled={!stream}
                            className={`px-3 text-[9px] font-bold transition-all ${monitorMode === 'INTERCEPT' ? 'bg-red-500 text-black' : 'text-gray-500 hover:text-red-400'}`}
                        >
                            INT
                        </button>
                    </div>

                    <button 
                        onClick={toggleMonitoring}
                        disabled={!stream}
                        className={`flex-1 border transition-all font-mono text-[9px] font-bold tracking-widest disabled:opacity-50 ${monitoring ? 'border-red-500 bg-red-900/20 text-red-400' : 'border-surgery-border hover:border-surgery-cyan text-gray-400'}`}
                    >
                        {monitoring ? "STOP" : "AUTO"}
                    </button>
                </div>
            </div>

            {/* Analysis Log */}
            {!compact && (
                <div className="w-[400px] flex flex-col gap-4">
                    <SurgicalContainer title="VISUAL_CORTEX_LOG" className="h-full">
                        <div className="flex-1 overflow-y-auto p-4 space-y-4 font-mono text-xs scrollbar-thin scrollbar-thumb-surgery-border">
                            {analysisLog.map((log, i) => (
                                <div key={i} className={`border-l-2 pl-3 py-1 animate-in fade-in ${log.type === 'ACTION' ? 'border-red-500 bg-red-900/5' : 'border-surgery-cyan/50'}`}>
                                    <div className="flex justify-between items-center mb-1">
                                        <div className="text-[9px] text-gray-500">{new Date(log.timestamp).toLocaleTimeString()}</div>
                                        {log.type === 'ACTION' && <span className="text-[8px] text-red-400 font-bold tracking-wider">DECISION</span>}
                                    </div>
                                    <div className={`leading-relaxed ${log.type === 'ACTION' ? 'text-white' : 'text-gray-300'}`}>{log.text}</div>
                                </div>
                            ))}
                        </div>
                    </SurgicalContainer>
                </div>
            )}

            <canvas ref={canvasRef} className="hidden" />
        </div>
    );
};


import React, { useRef, useState } from 'react';

interface Props {
  currentInput: string;
  onInputChange: (val: string) => void;
  onSend: (file?: File) => void;
  isProcessing: boolean;
}

export const TerminalInput: React.FC<Props> = ({ 
  currentInput, 
  onInputChange, 
  onSend,
  isProcessing
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [attachedFile, setAttachedFile] = useState<File | null>(null);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      triggerSend();
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setAttachedFile(e.target.files[0]);
    }
  };

  const triggerSend = () => {
      onSend(attachedFile || undefined);
      setAttachedFile(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
      <div className="p-4 border-t border-surgery-border bg-[#0a0a0c]/95 backdrop-blur-md z-50 relative shrink-0 shadow-[0_-5px_20px_rgba(0,0,0,0.5)]">
        {/* ATTACHMENT PREVIEW */}
        {attachedFile && (
            <div className="absolute top-[-30px] left-4 bg-surgery-cyan/10 border border-surgery-cyan/50 text-surgery-cyan text-[10px] px-2 py-1 flex items-center gap-2 animate-in slide-in-from-bottom-2">
                <span>📎 {attachedFile.name}</span>
                <button onClick={() => setAttachedFile(null)} className="hover:text-white font-bold">×</button>
            </div>
        )}

        <div className="relative flex gap-2">
          <span className="pt-3 text-surgery-cyan font-bold text-lg animate-pulse">»</span>
          <textarea
            value={currentInput}
            onChange={(e) => onInputChange(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Initialize cognitive sequence..."
            className="flex-1 bg-transparent border-none text-white focus:ring-0 outline-none resize-none h-14 placeholder:text-gray-700 leading-normal font-bold font-mono text-sm py-3"
          />
          
          <div className="flex flex-col gap-2">
              <input 
                type="file" 
                ref={fileInputRef}
                className="hidden" 
                onChange={handleFileSelect}
                accept=".pdf,.json,.txt,.md,.wav,.mp3,.webm"
              />
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="flex-1 px-3 border border-surgery-border hover:border-surgery-cyan hover:bg-surgery-cyan/10 text-gray-400 hover:text-surgery-cyan text-[10px] transition-colors"
                title="Attach Context (PDF, Audio, JSON)"
              >
                📎
              </button>
              <button 
                onClick={triggerSend}
                disabled={(!currentInput.trim() && !attachedFile) || isProcessing}
                className="px-6 py-2 border border-surgery-border hover:border-surgery-cyan hover:bg-surgery-cyan hover:text-black text-surgery-cyan text-[10px] uppercase font-black tracking-widest transition-all disabled:opacity-20 disabled:grayscale group flex-1"
              >
                <span className="group-hover:hidden">EXECUTE</span>
                <span className="hidden group-hover:inline">TRANSMIT</span>
              </button>
          </div>
        </div>
      </div>
  );
};


import React, { useEffect, useRef } from 'react';
import { layoutEngine } from '../latent_space/layout_engine';
import { realtimeBus } from '../bridge/realtime_bus';

interface LatentNodeData {
    id: string;
    embedding: number[];
    label: string;
    content?: string;
    type: 'candidate' | 'challenger' | 'final';
    timestamp: number;
    uncertainty?: number;
    backend?: string;
}

interface LatentMapProps {
  trace: LatentNodeData[]; // Consumes high frequency trace
  className?: string; 
  fullScreen?: boolean;
  isProcessing?: boolean; // [NEW] Active state trigger
}

// Spark/Shard for collision effects
interface Shard {
    x: number;
    y: number;
    life: number;
    lines: {dx: number, dy: number}[];
}

// Color Palette (RGB Tuples for Lerping)
const COLORS = {
    CHALLENGER: [255, 80, 80], // Bright Red (BETA)
    CANDIDATE_CONFIDENT: [0, 255, 170], // Neon Green (ALPHA)
    CANDIDATE_UNCERTAIN: [255, 200, 50], // Bright Amber (DELTA)
    FINAL: [255, 255, 255], // Pure White
    DEFAULT: [140, 140, 160], // Bright Gray
    EMERALD_GLOW: [50, 255, 180], // High Mass
    CYAN_REINFORCED: [0, 200, 255], // Reinforced
    GAMMA: [180, 100, 255] // Purple (GAMMA)
};

const lerp = (start: number, end: number, t: number) => start + (end - start) * t;

export const LatentMap: React.FC<LatentMapProps> = ({ trace, className = '', fullScreen = false, isProcessing = false }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const scaleRef = useRef<number>(fullScreen ? 1.0 : 0.45);
  const shardsRef = useRef<Shard[]>([]);

  // Capture Collisions locally
  useEffect(() => {
      const cleanup = realtimeBus.on("LATENT_COLLISION", (coords: {x: number, y: number}) => {
          const lines = [];
          const count = 3 + Math.floor(Math.random() * 3);
          for(let i=0; i<count; i++) {
              lines.push({
                  dx: (Math.random() - 0.5) * 15,
                  dy: (Math.random() - 0.5) * 15
              });
          }
          shardsRef.current.push({
              x: coords.x,
              y: coords.y,
              life: 1.0,
              lines
          });
      });
      return cleanup;
  }, []);

  // Sync trace to physics engine
  useEffect(() => {
    layoutEngine.prune(120); 

    const engineNodes = layoutEngine.getNodes();
    const existingMap = new Map(engineNodes.map(n => [n.id, n]));
    
    let hasUpdates = false;

    trace.forEach((node) => {
      const existing = existingMap.get(node.id);
      
      if (!existing && node.embedding && node.embedding.length > 0) {
        layoutEngine.addNode(
            node.id, 
            node.embedding, 
            node.label, 
            node.type, 
            node.uncertainty || 0,
            node.backend,
            node.content
        );
        hasUpdates = true;
      } else if (existing) {
        if (existing.type !== node.type || existing.uncertainty !== node.uncertainty) {
            layoutEngine.updateNode(node.id, {
                type: node.type,
                uncertainty: node.uncertainty
            });
        }
      }
    });

    if (hasUpdates) {
        layoutEngine.poke();
    }
  }, [trace]);

  // Handle Resize
  useEffect(() => {
    if (!containerRef.current || !canvasRef.current) return;

    const updateSize = () => {
        if (containerRef.current && canvasRef.current) {
            const { width, height } = containerRef.current.getBoundingClientRect();
            if (width > 0 && height > 0) {
                if (canvasRef.current.width !== width || canvasRef.current.height !== height) {
                    canvasRef.current.width = width;
                    canvasRef.current.height = height;
                }
            }
        }
    };

    const resizeObserver = new ResizeObserver(() => {
        window.requestAnimationFrame(() => updateSize());
    });
    
    resizeObserver.observe(containerRef.current);
    updateSize();
    
    // Poke engine to wake it up on init
    layoutEngine.poke();

    return () => resizeObserver.disconnect();
  }, []);

  // Animation Loop - Independent of trace updates
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let frameId: number;
    let sweepAngle = 0;
    
    const render = () => {
      // FORCE TICK
      layoutEngine.tick();
      const nodes = layoutEngine.getNodes();

      const width = canvas.width;
      const height = canvas.height;
      const offsetX = width / 2;
      const offsetY = height / 2;

      // --- TRANSPARENCY HANDLING ---
      ctx.globalCompositeOperation = 'destination-out';
      ctx.fillStyle = 'rgba(0, 0, 0, 0.15)'; 
      ctx.fillRect(0, 0, width, height);
      ctx.globalCompositeOperation = 'source-over';

      // --- AUTO-FIT CAMERA ---
      // Robust Min/Max init
      let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
      let validNodes = 0;

      if (nodes.length > 0) {
        nodes.forEach(n => {
            // Guard against NaN poisoning
            if (!Number.isFinite(n.x) || !Number.isFinite(n.y)) return;
            
            if (n.x < minX) minX = n.x;
            if (n.x > maxX) maxX = n.x;
            if (n.y < minY) minY = n.y;
            if (n.y > maxY) maxY = n.y;
            validNodes++;
        });
      }

      // Default bounds if no valid nodes found
      if (validNodes === 0) {
        minX = -50; maxX = 50; minY = -50; maxY = 50;
      }

      const padding = 60; 
      const contentWidth = Math.max(maxX - minX, 100) + padding * 2;
      const contentHeight = Math.max(maxY - minY, 100) + padding * 2;

      const targetScaleX = width / contentWidth;
      const targetScaleY = height / contentHeight;
      let targetScale = Math.min(targetScaleX, targetScaleY);
      
      // Safety clamp
      if (!Number.isFinite(targetScale) || targetScale <= 0) targetScale = 0.5;
      
      targetScale = Math.min(targetScale, 1.4); 
      targetScale = Math.max(targetScale, 0.3);

      if (Number.isFinite(targetScale)) {
          scaleRef.current += (targetScale - scaleRef.current) * 0.05;
      }
      const viewScale = scaleRef.current;
      
      // EMPTY STATE (Scanning)
      if (validNodes === 0 || isProcessing) {
          sweepAngle += 0.05;
          ctx.save();
          ctx.translate(offsetX, offsetY);
          ctx.strokeStyle = isProcessing ? 'rgba(0, 243, 255, 0.6)' : 'rgba(0, 243, 255, 0.2)';
          ctx.lineWidth = 2; 
          ctx.beginPath();
          ctx.arc(0, 0, 100, 0, Math.PI * 2);
          ctx.stroke();
          
          ctx.rotate(sweepAngle);
          const grad = ctx.createLinearGradient(0, 0, 100, 0);
          grad.addColorStop(0, 'rgba(0, 243, 255, 0)');
          grad.addColorStop(1, isProcessing ? 'rgba(0, 243, 255, 0.8)' : 'rgba(0, 243, 255, 0.4)');
          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.moveTo(0, 0);
          ctx.arc(0, 0, 100, 0, 0.3); 
          ctx.fill();
          ctx.restore();
          
          if (validNodes === 0) {
              ctx.fillStyle = 'rgba(255,255,255,0.7)'; 
              ctx.font = '10px "JetBrains Mono"';
              ctx.textAlign = 'center';
              ctx.fillText(isProcessing ? "THINKING..." : "SCANNING_LATENT_TOPOLOGY...", width/2, height/2 + 120);
          }
      }

      // Draw Edges
      ctx.lineWidth = fullScreen ? 1.0 : 0.8; 
      const now = Date.now();
      
      for (let i = 0; i < nodes.length; i++) {
          const a = nodes[i];
          if (!Number.isFinite(a.x) || !Number.isFinite(a.y)) continue;

          const ax = offsetX + (a.x * viewScale);
          const ay = offsetY + (a.y * viewScale);

          const ageA = Math.min(1, (now - a.createdAt) / 800); 
          const idxAlpha = Math.max(0.4, (i / nodes.length)); 
          const globalAlpha = ageA * idxAlpha;

          // Determine target color based on Label logic from Engine
          let targetRGB = COLORS.DEFAULT;
          const mass = a.mass || 1.0;

          if (mass > 3.5) {
              targetRGB = COLORS.EMERALD_GLOW;
          } else if (mass > 2.0) {
              targetRGB = COLORS.CYAN_REINFORCED;
          } else if (a.label.includes("BETA") || a.type === 'challenger') {
              targetRGB = COLORS.CHALLENGER;
          } else if (a.label.includes("GAMMA")) {
              targetRGB = COLORS.GAMMA;
          } else if (a.label.includes("DELTA")) {
              targetRGB = COLORS.CANDIDATE_UNCERTAIN;
          } else if (a.type === 'final') {
              targetRGB = COLORS.FINAL;
          } else if (a.type === 'candidate') {
              targetRGB = COLORS.CANDIDATE_CONFIDENT;
          }

          // Safety check for color array
          if (a.displayColor && a.displayColor.length === 3) {
              a.displayColor[0] = lerp(a.displayColor[0], targetRGB[0], 0.1);
              a.displayColor[1] = lerp(a.displayColor[1], targetRGB[1], 0.1);
              a.displayColor[2] = lerp(a.displayColor[2], targetRGB[2], 0.1);
          } else {
              a.displayColor = [...targetRGB] as [number, number, number];
          }

          const colorString = `rgba(${Math.round(a.displayColor[0])},${Math.round(a.displayColor[1])},${Math.round(a.displayColor[2])},${globalAlpha})`;

          // Draw Edges
          const scanLimit = Math.min(nodes.length, i + 15);
          for (let j = i + 1; j < scanLimit; j++) {
              const b = nodes[j];
              if (!Number.isFinite(b.x) || !Number.isFinite(b.y)) continue;

              const bx = offsetX + (b.x * viewScale);
              const by = offsetY + (b.y * viewScale);
              
              const dist = Math.sqrt(Math.pow(ax - bx, 2) + Math.pow(ay - by, 2));
              const threshold = fullScreen ? 180 : 120;

              if (dist < threshold) {
                  const edgeAlpha = (1 - dist / threshold) * 0.4 * globalAlpha;
                  ctx.strokeStyle = `rgba(140, 140, 160, ${edgeAlpha})`;
                  
                  if (a.type === 'challenger' && b.type === 'challenger') ctx.strokeStyle = `rgba(255, 80, 80, ${edgeAlpha})`;
                  if (a.label.includes("GAMMA") || b.label.includes("GAMMA")) ctx.strokeStyle = `rgba(180, 100, 255, ${edgeAlpha})`;
                  
                  ctx.beginPath();
                  ctx.moveTo(ax, ay);
                  ctx.lineTo(bx, by);
                  ctx.stroke();
              }
          }

          // Draw Node
          let radius = (fullScreen ? 4.0 : 3.0) * (viewScale < 0.6 ? 1.5 : 1);
          if (mass > 1.2) radius *= Math.min(2.5, mass * 0.6);

          // Pulse effect
          const isHeavy = mass > 3.5;
          const isThinking = isProcessing && i === nodes.length - 1; // Pulse latest node if thinking

          if (i === nodes.length - 1 || isHeavy || isThinking) {
             const pulseSize = radius * (2 + Math.sin(now / (isHeavy ? 500 : 200)) * 0.5);
             const glow = ctx.createRadialGradient(ax, ay, radius, ax, ay, pulseSize * (isHeavy ? 6 : 4));
             glow.addColorStop(0, colorString.replace(/,[\d\.]+\)$/, ',0.6)'));
             glow.addColorStop(1, 'rgba(0,0,0,0)');
             ctx.fillStyle = glow;
             ctx.beginPath();
             ctx.arc(ax, ay, pulseSize * (isHeavy ? 6 : 4), 0, Math.PI * 2);
             ctx.fill();
          }

          ctx.fillStyle = colorString;
          ctx.beginPath();
          ctx.arc(ax, ay, radius, 0, Math.PI * 2);
          ctx.fill();

          // Labels
          const showLabel = fullScreen || i > nodes.length - 5 || i % 3 === 0 || isHeavy || isThinking;
          if (showLabel) {
             ctx.fillStyle = i === nodes.length - 1 ? `rgba(255,255,255,1.0)` : `rgba(200,200,200,${globalAlpha})`;
             if (isHeavy) ctx.fillStyle = '#00ff9f';
             
             ctx.font = `${fullScreen ? 10 : 9}px "JetBrains Mono"`;
             if (isHeavy) ctx.font = `bold ${fullScreen ? 11 : 10}px "JetBrains Mono"`;

             ctx.textAlign = 'left';
             ctx.fillText(a.label.substring(0, isHeavy ? 24 : 16), ax + radius + 4, ay + 3);
          }
      }

      // RENDER SHARDS
      shardsRef.current.forEach(shard => {
          shard.life -= 0.05;
          if (shard.life <= 0) return;

          const sx = offsetX + (shard.x * viewScale);
          const sy = offsetY + (shard.y * viewScale);

          ctx.strokeStyle = `rgba(0, 243, 255, ${shard.life})`;
          ctx.lineWidth = 1; 
          ctx.beginPath();
          
          shard.lines.forEach(line => {
              const lx = line.dx * (1 - shard.life) * 2 * viewScale; 
              const ly = line.dy * (1 - shard.life) * 2 * viewScale;
              ctx.moveTo(sx, sy);
              ctx.lineTo(sx + lx, sy + ly);
          });
          ctx.stroke();
      });
      if (shardsRef.current.some(s => s.life <= 0)) {
          shardsRef.current = shardsRef.current.filter(s => s.life > 0);
      }

      // HUD overlay
      const pad = 15;
      ctx.fillStyle = isProcessing ? '#00f3ff' : '#444';
      ctx.fillRect(width - 45 - pad, height - 15 - pad, 4, 4);
      ctx.fillStyle = 'rgba(255,255,255,0.7)'; 
      ctx.font = '8px "JetBrains Mono"';
      ctx.textAlign = 'left';
      ctx.fillText(`NODES: ${validNodes}`, width - 38 - pad, height - 11 - pad);
      
      const lastNode = nodes[nodes.length - 1];
      if (lastNode && lastNode.backend) {
          ctx.fillText(`ENG: ${lastNode.backend.toUpperCase()}`, width - 60 - pad, height - 25 - pad);
      }

      frameId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(frameId);
  }, [fullScreen, isProcessing]); // Run always, not dependent on 'trace' updates

  return (
    <div ref={containerRef} className={`rounded-sm p-0 relative overflow-hidden flex flex-col group transition-colors ${className}`}>
        <div className="absolute top-0 left-0 w-full p-3 flex justify-between items-center pointer-events-none z-10 bg-gradient-to-b from-black/60 to-transparent">
            <h3 className={`text-dream-cyan font-mono font-bold tracking-widest flex justify-between items-center ${fullScreen ? 'text-lg' : 'text-[10px]'}`}>
                LATENT_SPACE
                {fullScreen && <span className="ml-4 text-xs opacity-80 text-white animate-pulse">LIVE_STREAM</span>}
            </h3>
            <span className="text-[8px] opacity-80 text-dream-cyan/80">FORCE_DIRECTED</span>
        </div>
        <canvas 
            ref={canvasRef} 
            className="w-full h-full block cursor-crosshair"
        />
    </div>
  );
};

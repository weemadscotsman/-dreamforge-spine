
import { realtimeBus } from "../../bridge/realtime_bus";

interface Shard {
    x: number;
    y: number;
    lines: {dx: number, dy: number}[];
    life: number;
}

export function bindEchoShards(canvas: HTMLCanvasElement) {
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    
    // We need to transform physics coords (0,0 center) to canvas coords
    // This assumes the layout is centered.
    const transformX = (x: number) => (canvas.width / 2) + (x * 20); // rough scale
    const transformY = (y: number) => (canvas.height / 2) + (y * 20);

    const shards: Shard[] = [];

    realtimeBus.on("LATENT_COLLISION", (coords: {x: number, y: number}) => {
        const lines = [];
        for(let i=0; i<4; i++) {
            lines.push({
                dx: (Math.random() - 0.5) * 30,
                dy: (Math.random() - 0.5) * 30
            });
        }
        shards.push({
            x: transformX(coords.x),
            y: transformY(coords.y),
            lines,
            life: 1.0
        });
    });

    const render = () => {
        // Note: We don't clear rect here because EmberTrails manages the clear/draw loop usually.
        // If this is a separate layer, we need to clear.
        // Assuming this is used in VisualEffectsOverlay which handles its own canvas.
        // If shared canvas, we rely on the main loop.
        // For safety, let's assume a dedicated transparent layer for echoes.
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        ctx.lineWidth = 1;

        for (let i = shards.length - 1; i >= 0; i--) {
            const s = shards[i];
            s.life -= 0.05;

            ctx.strokeStyle = `rgba(0, 243, 255, ${s.life})`;
            ctx.beginPath();
            
            s.lines.forEach(line => {
                ctx.moveTo(s.x, s.y);
                ctx.lineTo(s.x + line.dx * (1-s.life), s.y + line.dy * (1-s.life));
            });
            
            ctx.stroke();

            if (s.life <= 0) shards.splice(i, 1);
        }
        requestAnimationFrame(render);
    };
    render();
}


// ui/effects/nervous_system.ts
// THE BODY INTERFACE
// Connects system state directly to CSS variables for visceral feedback.

import { realtimeBus } from "../../bridge/realtime_bus";
import { getHeatLevel } from "../../engine/pressure/streak_decay";
import { SpineEvent } from "../../spine/events";

// Bind to the root document
const root = document.documentElement;

export function initNervousSystem() {
    
    // 1. Heat Loop (Background hum)
    setInterval(() => {
        const heat = getHeatLevel(); // 0.0 -> 1.0
        
        // Update CSS Variable for Blur/Hue
        // heat * 2px blur max
        root.style.setProperty('--blur-amount', `${(heat * 2).toFixed(1)}px`);
        root.style.setProperty('--fever-heat', heat.toFixed(2));
        
        // If heat is high, trigger random micro-jitters
        if (heat > 0.5) {
            if (Math.random() > 0.7) {
                const jitter = (Math.random() - 0.5) * (heat * 10);
                root.style.setProperty('--glitch-offset', `${jitter}px`);
                setTimeout(() => {
                    root.style.setProperty('--glitch-offset', '0px');
                }, 50);
            }
        }
    }, 100);

    // 2. Event Spikes (Acute reactions)
    const cleanup = realtimeBus.on("SPINE_EVENT", (e: SpineEvent) => {
        switch (e.type) {
            case "UNCERTAINTY_DELTA":
                // Immediate massive shake
                triggerGlitch(e.delta * 20);
                break;
            
            case "CONTRADICTION_DETECTED":
                // Text shear / chromatic aberration
                triggerChromaticSplit(e.weight);
                break;

            case "CYCLE_WINNER":
                if (e.winner === "challenger") {
                    // Flash Red
                    flashScreen("rgba(255, 0, 0, 0.2)");
                } else {
                    // Flash Cyan
                    flashScreen("rgba(0, 255, 255, 0.1)");
                }
                break;
        }
    });
}

function triggerGlitch(intensity: number) {
    document.body.classList.add("glitch-active");
    setTimeout(() => {
        document.body.classList.remove("glitch-active");
    }, intensity * 100); // Duration proportional to intensity
}

function triggerChromaticSplit(intensity: number) {
    document.body.classList.add("fever-shake");
    setTimeout(() => {
        document.body.classList.remove("fever-shake");
    }, 200);
}

function flashScreen(color: string) {
    const flash = document.createElement("div");
    flash.style.position = "fixed";
    flash.style.top = "0";
    flash.style.left = "0";
    flash.style.width = "100vw";
    flash.style.height = "100vh";
    flash.style.backgroundColor = color;
    flash.style.pointerEvents = "none";
    flash.style.zIndex = "9999";
    flash.style.transition = "opacity 0.3s ease-out";
    
    document.body.appendChild(flash);
    
    // Force reflow
    void flash.offsetWidth;
    
    flash.style.opacity = "0";
    setTimeout(() => {
        flash.remove();
    }, 300);
}

// Legacy binding stub for previous files that might import it
export function bindNervousSystem(rootEl: HTMLElement) {
    // No-op, handled by initNervousSystem globally now
}

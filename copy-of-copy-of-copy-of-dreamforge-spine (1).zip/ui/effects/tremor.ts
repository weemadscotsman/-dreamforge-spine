
import { LatentLayoutEngine } from "../../latent_space/layout_engine";
import { realtimeBus } from "../../bridge/realtime_bus";

export function bindNodeTremor(layout: LatentLayoutEngine) {
    realtimeBus.on("UNCERTAINTY_SPIKE", (level: number) => {
        // Level 0.0 to 1.0
        // Shake intensity
        layout.shake(level);
    });
}

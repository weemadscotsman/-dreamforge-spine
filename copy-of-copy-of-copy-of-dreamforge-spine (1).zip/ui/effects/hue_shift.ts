import { getRecursionDelta } from "../../engine/pressure/recursion_pressure";
import { layoutEngine } from "../../latent_space/layout_engine";
import { realtimeBus } from "../../bridge/realtime_bus";
import { SpineEvent } from "../../spine/events";

export function bindHueShift(root: HTMLElement) {
  let currentHue = 0;
  
  // Listen for Pressure Curve events to tighten the system
  realtimeBus.on("SPINE_EVENT", (e: SpineEvent) => {
      if (e.type === "PRESSURE_CURVE") {
          // Tighten the node graph when pressure rises
          layoutEngine.crystallizeGlobal(e.slope);
      }
  });
  
  setInterval(() => {
    // Delta 0.0 (Peace) -> 1.0 (War)
    const delta = getRecursionDelta(); 
    
    // Target Hue Shift:
    // 0 Delta -> 0 deg shift (Normal/Cyan)
    // 1 Delta -> 140 deg shift (Pink/Red)
    const target = delta * 140; 
    
    // Lerp
    currentHue += (target - currentHue) * 0.05;

    if (Math.abs(currentHue) > 1) {
        root.style.filter = `hue-rotate(${currentHue}deg)`;
    } else {
        root.style.filter = 'none'; // Clear filter to avoid stacking issues with Nervous System
    }
  }, 50);
}
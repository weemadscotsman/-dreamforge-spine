
import { LatentLayoutEngine } from "../../latent_space/layout_engine";
import { HypothesisLedger } from "../../engine/beliefs/hypothesis_ledger";

/**
 * Periodically syncs belief strength to node mass.
 * Strong beliefs = Heavy nodes (Crystalized).
 * Weak beliefs = Light nodes (Drifting).
 */
export function bindNodeDrift(layout: LatentLayoutEngine, ledger: HypothesisLedger) {
    setInterval(() => {
        const beliefs = ledger.getBeliefs();
        
        // Convert Ledger to Mass Map
        const map = new Map<string, number>();
        beliefs.forEach(b => {
            map.set(b.statement, b.strength);
            // Also map ID for fallback matching
            map.set(b.id, b.strength);
        });

        // Apply physical properties based on map
        layout.crystallize(map);

    }, 1000); // 1Hz sync is sufficient
}

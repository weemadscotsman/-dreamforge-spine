
/**
 * [BRIDGE] RESPONSE SHAPER
 * Intercepts raw model reasoning and applies a "Posture Layer".
 * Enforces neutral, analytical tone.
 */

export function shapeResponse(
  content: string,
  confidence: number,      // 0.0 - 1.0 (Verdict Score)
  deltaImprovement: number // -1.0 to 1.0 (Score Delta)
): string {
  
  // 1. HARD GATE: If confidence is garbage, refuse to serve it.
  if (confidence < 0.35) {
      return "**Analysis rejected.** The premise collapses under inspection.";
  }

  // 2. STRIP: Remove weak language and AI tropes first.
  let cleaned = stripFiller(content);

  // 3. STANCE: Prefix with calculated posture.
  let prefix = "";

  if (confidence > 0.85) {
    prefix = "Answer produced.";
  } else if (confidence > 0.65) {
    prefix = "Accepted with warnings.";
  } else {
    prefix = "Tentative analysis.";
  }

  // 4. DELTA: Did we get smarter?
  if (deltaImprovement > 0.25) {
    prefix += " (Iteration improved logic)";
  } else if (deltaImprovement < -0.1) {
    prefix += " (Logic degraded under pressure)";
  }

  return `**${prefix}**\n\n${cleaned}`;
}

function stripFiller(text: string): string {
    const BANNED = [
        /It is important to note that/gi,
        /In conclusion,?/gi,
        /As an AI language model,?/gi,
        /I believe/gi,
        /solution found/gi,
        /success/gi
    ];

    let t = text;
    BANNED.forEach(rx => {
        t = t.replace(rx, "");
    });
    
    t = t.replace(/\s\s+/g, " ");
    t = t.replace(/^\s*[,.]\s*/, "");
    t = t.trim();
    
    if (t.length > 0) {
        t = t.charAt(0).toUpperCase() + t.slice(1);
    }
    
    return t;
}

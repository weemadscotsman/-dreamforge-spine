
export class EventThrottler {
  private eventQueue: Map<string, any[]> = new Map();
  private flushInterval: number = 100; // ms
  private timers: Map<string, any> = new Map();
  private emitter: (type: string, data: any) => void;

  constructor(emitter: (type: string, data: any) => void) {
      this.emitter = emitter;
  }
  
  throttle(eventType: string, data: any) {
    // Add to queue
    if (!this.eventQueue.has(eventType)) {
      this.eventQueue.set(eventType, []);
    }
    this.eventQueue.get(eventType)!.push(data);
    
    // Schedule flush if not already scheduled
    if (!this.timers.has(eventType)) {
      const timer = setTimeout(() => {
        const batch = this.eventQueue.get(eventType) || [];
        this.eventQueue.set(eventType, []);
        this.timers.delete(eventType);
        
        if (batch.length > 0) {
            // If strictly one item, emit as is (for compatibility), or emit batch?
            // Let's emit a BATCH event type if count > 1
            if (batch.length === 1) {
                this.emitter(eventType, batch[0]);
            } else {
                this.emitter(`${eventType}_BATCH`, { count: batch.length, updates: batch });
            }
        }
      }, this.flushInterval);
      
      this.timers.set(eventType, timer);
    }
  }
  
  clear() {
    for (const timer of this.timers.values()) {
      clearTimeout(timer);
    }
    this.timers.clear();
    this.eventQueue.clear();
  }
}

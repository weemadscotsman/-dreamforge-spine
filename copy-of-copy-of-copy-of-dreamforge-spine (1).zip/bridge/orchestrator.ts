
import { IOrchestrator, SystemEvent, SystemLog } from './types';
import { ModelDriver } from '../model/driver';
import { CoreEngine } from '../core/engine'; 
import { ExporterCore } from '../exporter/exporter_core';
import { CheckpointCompressor } from '../exporter/checkpoint_compressor';
import { IngestRouter } from '../ingest/ingest_router';
import { datasetLoader } from '../ingest/dataset_loader';
import { ModelAttachment } from '../model/types';
import { distiller } from '../distillation/distillation_core'; 
import { reinforcementStore } from '../distillation/reinforcement_store'; 
import { realtimeBus } from './realtime_bus';
import { registry as toolRegistry } from '../tools/registry';
import { vfs } from '../tools/vfs';
import { MemoryCore } from '../memory/memory_core';
import { FightMode } from '../core/types';
import { autonomyGovernor } from '../autonomy/autonomy_governor';
import { modelRegistry } from '../model/registry';
import { cosineSimilarity } from '../latent_space/vector_math';
import { shapeResponse } from './response_shaper'; // [NEW] Import Shaper

const safeStringify = (obj: any): string => {
    try {
        const cache = new Set();
        return JSON.stringify(obj, (key, value) => {
            if (typeof value === 'object' && value !== null) {
                if (cache.has(value)) return '[Circular]';
                cache.add(value);
            }
            return value;
        });
    } catch (e) {
        return `[Unserializable]`;
    }
};

export class Orchestrator implements IOrchestrator {
  private model: ModelDriver;
  private memory: MemoryCore;
  private engine: CoreEngine; 
  private exporter: ExporterCore;
  private checkpoint: CheckpointCompressor;
  private ingest: IngestRouter;
  
  private listeners: ((event: SystemEvent) => void)[] = [];
  private systemStatus: 'IDLE' | 'PROCESSING' | 'ERROR' = 'IDLE';
  private activeModule: string = 'BRIDGE';
  private isLogging: boolean = false; 

  private globalConfig = {
    temperature: 0.7,
    maxTokens: 2048,
    topP: 0.95,
    topK: 64,
    systemInstruction: "You are Dreamforge, a recursive AI engine.",
    fightMode: 'DUEL_1V1' as FightMode // Default to 1v1
  };

  private state = {
      logs: [] as SystemLog[]
  };

  constructor() {
    this.model = new ModelDriver();
    this.memory = new MemoryCore();
    this.engine = new CoreEngine(this.model, this.memory);
    this.exporter = new ExporterCore();
    this.checkpoint = new CheckpointCompressor(this.memory);
    this.ingest = new IngestRouter();

    // 1. Pipe events to bus (One-Way)
    this.subscribe((event) => {
        realtimeBus.feed(event);
    });

    // 2. Listen for Backend Events & Re-Emit to UI Subscribers (e.g. App.tsx)
    realtimeBus.on('BELIEFS_UPDATE', (data) => {
        this.emit('RECURSOR', 'BELIEFS_UPDATE', 'Ledger Sync', { data });
    });
    
    realtimeBus.on('HEURISTICS_UPDATE', (data) => {
        this.emit('DISTILLATION', 'UPDATE', 'Heuristics Sync', { data });
    });

    // CRITICAL: Ensure Latent Updates bubble up to App.tsx state
    realtimeBus.on('LATENT_UPDATE', (data) => {
        this.emit('RECURSOR', 'LATENT_UPDATE', '', data);
    });

    // CRITICAL: Pipe SYSTEM_LOG to UI
    realtimeBus.on('SYSTEM_LOG', (log: any) => {
        this.log(log.module || 'CORE', log.level || 'INFO', log.message, log.data);
    });

    realtimeBus.on('STRATEGY_LOG', (log: any) => {
        this.log('STRATEGY', log.level || 'INFO', log.message, log.data);
    });

    realtimeBus.on('FIGHT_UPDATE', (data: any) => {
        this.emit('RECURSOR', 'FIGHT_UPDATE', `Stage: ${data.stage}`, data);
    });

    realtimeBus.on('TWIN_FIGHT_RESULT', (data: any) => {
        this.emit('RECURSOR', 'TWIN_FIGHT_RESULT', `Winner: ${data.winner}`, data);
    });

    realtimeBus.on('AUTO_STATUS', (data: any) => {
        this.emit('RECURSOR', 'AUTO_STATUS', `Auto: ${data.state}`, data);
    });
  }

  async initialize(): Promise<void> {
    this.log('BRIDGE', 'INFO', 'System booting...');
    await this.model.initialize();
    this.log('BRIDGE', 'INFO', 'System ready.');
  }

  setConfig(config: any) {
    this.model.configure(config);
    if (config.temperature !== undefined) this.globalConfig.temperature = config.temperature;
    if (config.maxTokens !== undefined) this.globalConfig.maxTokens = config.maxTokens;
    if (config.fightMode !== undefined) this.globalConfig.fightMode = config.fightMode;
    this.log('BRIDGE', 'INFO', `Config updated.`);
  }

  getConfig() { return { ...this.globalConfig, provider: this.model.getProvider() }; }
  getHeuristics() { return reinforcementStore.getAll(); }
  getMemoryDump() { return this.memory.getAllRecords(); }

  async importDataset(file: File): Promise<string> {
      try {
          this.log('INGEST', 'INFO', `Importing dataset: ${file.name}`);
          const result = await datasetLoader.ingest(file);
          this.log('INGEST', 'INFO', result);
          return result;
      } catch (e: any) {
          const err = `Import failed: ${e.message}`;
          this.log('INGEST', 'ERROR', err);
          return err;
      }
  }

  /**
   * Universal File Ingest for Permanent Memory.
   * Handles extraction of text from binary formats (PDF, IMG) via Model before storage.
   */
  async ingestFileToMemory(file: File): Promise<string> {
      try {
          this.log('INGEST', 'INFO', `Reading file for memory: ${file.name}`);
          const result = await this.ingest.process(file);
          let content = "";
          
          if (result.dataType === 'TEXT') {
              content = result.data;
          } else if (result.dataType === 'BASE64') {
              // Brain-based extraction
              this.log('INGEST', 'INFO', `Binary format detected. Using Model for text extraction...`);
              const prompt = `[SYSTEM: DOC_EXTRACTION]\nEXTRACT TEXT FROM THIS DOCUMENT.\nRETURN RAW CONTENT ONLY.`;
              const extraction = await this.runInternalTask(prompt, [{ mimeType: result.mimeType, data: result.data }]);
              content = extraction.output;
          }

          if (content && content.length > 5) {
              this.memory.injectLongTerm(content, result.filename);
              return `Successfully ingested ${result.filename} (${content.length} chars) to Permanent Memory.`;
          }
          return "Extraction failed or content was empty.";
      } catch (e: any) {
          this.log('INGEST', 'ERROR', `Ingest failed: ${e.message}`);
          return `Error: ${e.message}`;
      }
  }

  async runDiagnostics(): Promise<string> {
      try {
          const provider = this.model.getProvider();
          this.log('BRIDGE', 'INFO', `INITIATING UPLINK TEST [${provider.toUpperCase()}]...`);
          
          const start = Date.now();
          const response = await this.model.generate({
              id: "diag-spin",
              prompt: "PING", // Minimal token cost
              configOverride: { maxOutputTokens: 5 }
          });
          const latency = Date.now() - start;
          
          // Check for error in response content (Mock adapter style fallback)
          if (response.content.startsWith("Error")) {
              throw new Error(response.content);
          }

          this.log('BRIDGE', 'INFO', `UPLINK SUCCESS (${latency}ms).`);
          return `ONLINE • ${latency}ms • ${provider.toUpperCase()}`;
      } catch (e: any) {
          let errCode = "UNKNOWN_ERROR";
          if (e.message.includes("429")) errCode = "QUOTA_EXCEEDED";
          else if (e.message.includes("403") || e.message.includes("key")) errCode = "INVALID_KEY";
          else if (e.message.includes("fetch")) errCode = "NETWORK_ERROR";
          
          const msg = `UPLINK FAILED: ${errCode} (${e.message.slice(0, 30)}...)`;
          this.log('BRIDGE', 'ERROR', msg);
          return msg;
      }
  }

  /**
   * PURE LOCAL SYSTEM DIAGNOSTICS
   * Checks structural integrity without network calls or API usage.
   */
  async runSystemCheck(): Promise<void> {
      const steps = [
          { id: 'ENV', name: 'ENVIRONMENT SECURITY' },
          { id: 'GPU', name: 'GRAPHICS ACCELERATION' },
          { id: 'CONF', name: 'ADAPTER BINDING' },
          { id: 'MATH', name: 'VECTOR MATH ENGINE' },
          { id: 'BUS', name: 'EVENT BUS LOOPBACK' },
          { id: 'MEM', name: 'MEMORY ALLOCATION' },
          { id: 'VFS', name: 'FILESYSTEM I/O' },
          { id: 'PING', name: 'MODEL LATENCY CHECK' }
      ];

      this.emit('DIAGNOSTICS', 'START', 'Starting Sequence', { steps });
      const delay = (ms: number) => new Promise(r => setTimeout(r, ms));

      await delay(500);

      // 1. ENV CHECK
      try {
          const isSecure = window.location.protocol === 'https:' || window.location.hostname === 'localhost';
          this.emit('DIAGNOSTICS', 'STEP_COMPLETE', 'ENV', { status: isSecure ? 'SUCCESS' : 'WARN', info: isSecure ? 'Secure Context' : 'Insecure Context' });
      } catch (e) {
          this.emit('DIAGNOSTICS', 'STEP_COMPLETE', 'ENV', { status: 'FAIL', error: 'Environment Check Failed' });
      }
      await delay(400);

      // 2. GPU CHECK
      try {
          const gpuInfo = await this.getGPUInfo();
          this.emit('DIAGNOSTICS', 'STEP_COMPLETE', 'GPU', { status: 'SUCCESS', info: gpuInfo });
      } catch (e: any) {
          this.emit('DIAGNOSTICS', 'STEP_COMPLETE', 'GPU', { status: 'WARN', info: 'Hidden / Software Renderer' });
      }
      await delay(400);

      // 3. ADAPTER BINDING
      try {
          const provider = this.model.getProvider();
          const adapter = modelRegistry.get(provider);
          
          if (!adapter) throw new Error(`Adapter '${provider}' not found in registry`);
          
          this.emit('DIAGNOSTICS', 'STEP_COMPLETE', 'CONF', { status: 'SUCCESS', info: `Bound: ${provider.toUpperCase()}` });
      } catch (e: any) {
          this.emit('DIAGNOSTICS', 'STEP_COMPLETE', 'CONF', { status: 'FAIL', error: e.message });
      }
      await delay(400);

      // 4. VECTOR MATH CHECK
      try {
          const v1 = [1, 0, 0];
          const v2 = [0, 1, 0];
          const sim = cosineSimilarity(v1, v2); // Should be 0
          const simSelf = cosineSimilarity(v1, v1); // Should be 1
          
          if (sim < 0.001 && simSelf > 0.99) {
              this.emit('DIAGNOSTICS', 'STEP_COMPLETE', 'MATH', { status: 'SUCCESS', info: 'Tensor Ops Operational' });
          } else {
              throw new Error(`Math Integrity Failure: ${sim} / ${simSelf}`);
          }
      } catch (e: any) {
          this.emit('DIAGNOSTICS', 'STEP_COMPLETE', 'MATH', { status: 'FAIL', error: e.message });
      }
      await delay(400);

      // 5. EVENT BUS
      try {
          if (!realtimeBus) throw new Error("Bus undefined");
          this.emit('DIAGNOSTICS', 'STEP_COMPLETE', 'BUS', { status: 'SUCCESS', info: 'Signal Path Clear' });
      } catch (e: any) {
          this.emit('DIAGNOSTICS', 'STEP_COMPLETE', 'BUS', { status: 'FAIL', error: e.message });
      }
      await delay(400);

      // 6. MEMORY
      try {
          const records = this.memory.getAllRecords();
          if (!Array.isArray(records)) throw new Error("Memory corruption: Not an array");
          this.emit('DIAGNOSTICS', 'STEP_COMPLETE', 'MEM', { status: 'SUCCESS', info: `${records.length} Nodes Active` });
      } catch (e: any) {
          this.emit('DIAGNOSTICS', 'STEP_COMPLETE', 'MEM', { status: 'FAIL', error: e.message });
      }
      await delay(400);

      // 7. VFS INTEGRITY
      try {
          const testPath = 'logs/integrity_test.tmp';
          const testData = `CHECK_${Date.now()}`;
          
          vfs.writeFile(testPath, testData);
          const readBack = vfs.readFile(testPath);
          vfs.deleteFile(testPath);
          
          if (readBack === testData) {
              this.emit('DIAGNOSTICS', 'STEP_COMPLETE', 'VFS', { status: 'SUCCESS', info: 'Read/Write Verified' });
          } else {
              throw new Error("Data corruption on readback");
          }
      } catch (e: any) {
          this.emit('DIAGNOSTICS', 'STEP_COMPLETE', 'VFS', { status: 'FAIL', error: e.message });
      }
      await delay(400);

      // 8. PING (Model Connectivity)
      try {
          const start = Date.now();
          await this.model.generate({
              id: 'diag-ping',
              prompt: 'ACK', 
              configOverride: { maxOutputTokens: 1, temperature: 0 }
          });
          const latency = Date.now() - start;
          this.emit('DIAGNOSTICS', 'STEP_COMPLETE', 'PING', { status: 'SUCCESS', latency, info: 'Uplink Established' });
      } catch (e: any) {
          const msg = e.message?.includes('429') ? 'Quota Exceeded' : (e.message?.includes('fetch') ? 'Network Error' : e.message);
          this.emit('DIAGNOSTICS', 'STEP_COMPLETE', 'PING', { status: 'WARN', info: msg });
      }
      
      this.emit('DIAGNOSTICS', 'COMPLETE', 'Structural Diagnostics Passed');
  }

  private async getGPUInfo(): Promise<string> {
      if (typeof navigator === 'undefined') return "Server Side";
      
      // WebGPU (Chrome/Edge/Arc)
      if ((navigator as any).gpu) {
          try {
              const adapter = await (navigator as any).gpu.requestAdapter();
              if (adapter) {
                  const info = await adapter.requestAdapterInfo();
                  // Returns something like "NVIDIA RTX 4090"
                  return `WebGPU: ${info.vendor} ${info.device}`.trim();
              }
          } catch (e) { /* ignore */ }
      }
      
      // WebGL Fallback
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl');
      if (gl) {
          const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
          if (debugInfo) {
              const renderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
              return `WebGL: ${renderer}`;
          }
      }
      return "Generic Display Adapter";
  }

  exportDataset(label: string): string {
      return this.exporter.exportFinetuneDataset(this.memory.getAllRecords(), [], label);
  }

  distillSystem(): string {
      this.log('DISTILLATION', 'INFO', 'Starting manual distillation...');
      const result = distiller.distill(this.memory.getAllRecords());
      this.emit('DISTILLATION', 'UPDATE', 'Manual Distillation Complete', result.newHeuristics);
      return `DISTILLATION COMPLETE. New: ${result.newHeuristics}.`;
  }

  async runInternalTask(prompt: string, attachments: ModelAttachment[] = []): Promise<{ score: number, output: string }> {
      const generator = this.engine.run({ 
          task: prompt, 
          attachments, 
          maxCycles: 1, 
          fightMode: this.globalConfig.fightMode 
      });
      let result = { score: 0, output: "" };
      for await (const artifact of generator) {
          result = { score: artifact.verdict.score, output: artifact.candidate };
      }
      return result;
  }
  
  dispatch(event: SystemEvent): void { console.log(`[BRIDGE] Event: ${event.source}`); }

  getState(): any { return { status: this.systemStatus, activeModule: this.activeModule, logs: this.state.logs }; }

  subscribe(callback: (event: SystemEvent) => void): () => void {
    this.listeners.push(callback);
    return () => { this.listeners = this.listeners.filter(cb => cb !== callback); };
  }

  async processUserMessage(input: string, file?: File): Promise<string> {
    this.updateStatus('PROCESSING');
    let effectiveInput = input;
    const attachments: ModelAttachment[] = [];
    
    const toolDefs = toolRegistry.listDefs();
    const toolPrompt = `[AVAILABLE TOOLS]\n${toolDefs}\nTo use a tool, output: @@tool_name({"arg": "value"})@@`;
    effectiveInput = `${toolPrompt}\n\n[USER TASK]: ${effectiveInput}`;

    try {
        if (file) {
            const ingestResult = await this.ingest.process(file);
            if (ingestResult.dataType === 'BASE64') {
                attachments.push({ mimeType: ingestResult.mimeType, data: ingestResult.data });
                effectiveInput += `\n[FILE ATTACHED: ${ingestResult.filename}]`;
            } else {
                effectiveInput += `\n[FILE ATTACHED: ${ingestResult.filename}]\n${ingestResult.data}`;
            }
        }

        const recalled = this.memory.retrieve(input);
        const context = recalled.map(r => r.output);
        let finalOutput = "";
        
        // Track confidence for Shaper
        let initialScore = 0;
        let finalScore = 0;
        let cycleCount = 0;
        
        const generator = this.engine.run({ 
            task: effectiveInput, 
            attachments, 
            context, 
            maxCycles: 5,
            fightMode: this.globalConfig.fightMode 
        });

        for await (const artifact of generator) {
            finalOutput = artifact.candidate;
            
            // Score tracking
            finalScore = artifact.verdict.score;
            if (cycleCount === 0) initialScore = finalScore;
            cycleCount++;
            
            this.emit('RECURSOR', 'CYCLE_COMPLETE', `Cycle ${artifact.cycle} finished.`, {
                cycle: artifact.cycle,
                output: artifact.candidate,
                score: artifact.verdict.score,
                signature: 'core-sig',
                winner: artifact.verdict.outcome === 'ACCEPT' ? 'candidate' : 'challenger',
                reason: artifact.verdict.reason
            });

            this.model.embed(artifact.candidate.slice(0, 8000)).then(emb => {
                this.emit('RECURSOR', 'LATENT_UPDATE', '', {
                    embedding: emb,
                    label: `Cycle ${artifact.cycle}`,
                    type: 'candidate',
                    timestamp: Date.now()
                });
            });
        }

        // Apply Response Shaper
        // Delta is normalized roughly -1 to 1 (usually score moves 10-20 points so 0.1-0.2)
        const delta = (finalScore - initialScore) / 100;
        const confidence = finalScore / 100;
        
        const shapedOutput = shapeResponse(finalOutput, confidence, delta);

        this.updateStatus('IDLE');
        return shapedOutput;

    } catch (error) {
        this.log('BRIDGE', 'ERROR', `Failure: ${error}`);
        this.updateStatus('ERROR');
        throw error;
    }
  }

  private updateStatus(status: 'IDLE' | 'PROCESSING' | 'ERROR') {
      this.systemStatus = status;
      this.emit('BRIDGE', 'STATUS', `System status: ${status}`, { status });
  }

  private log(module: SystemLog['module'], level: SystemLog['level'], message: string, data?: unknown) {
    if (this.isLogging) return; // Prevent infinite recursion
    this.isLogging = true;

    try {
        const timestamp = Date.now();
        const newLog: SystemLog = { timestamp, module, level, message, data };
        
        // UI Update
        this.state.logs = [newLog, ...this.state.logs].slice(0, 100);
        
        // VFS Persistence
        try {
            const timeStr = new Date(timestamp).toISOString();
            const logLine = `[${timeStr}] [${module}] [${level}] ${message} ${data ? safeStringify(data) : ''}\n`;
            vfs.appendFile('logs/session.log', logLine);
        } catch (e) {
            console.warn("VFS Log Failed");
        }

        // Emit for UI
        this.emit(module, level, message, data);
    } finally {
        this.isLogging = false;
    }
  }

  private emit(source: string, level: string, message: string, payload?: any) {
    this.activeModule = source;
    const event: SystemEvent = {
        id: crypto.randomUUID(),
        timestamp: Date.now(),
        source: source,
        payload: { level, message, ...payload }
    };
    this.listeners.forEach(cb => cb(event));
  }
}

export const orchestrator = new Orchestrator();

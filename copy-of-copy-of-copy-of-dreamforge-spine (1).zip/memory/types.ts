
import { UUID } from '../types';

export interface TaskMetadata {
  taskId: UUID;
  cycle: number;
  evaluatorScore: number;
  deltaPlan?: any;
}

export interface MemoryRecord {
  output: string;
  signature: string;
  score: number;
  meta: TaskMetadata;
  timestamp?: number;
}

export interface IMemoryCore {
  ingest(output: string, signature: string, taskMeta: TaskMetadata): void;
  injectLongTerm(content: string, source: string): void; // [NEW] Direct injection
  retrieve(query: string): MemoryRecord[];
  exportCheckpoint(label: string): string;
  getAllRecords(): MemoryRecord[];
}

// --- Persistence Layer Types ---

export interface MemoryQuery {
  semanticQuery?: string;
  tags?: string[];
  limit?: number;
  minCoherence?: number;
}

export interface MemoryFragment {
  id: UUID;
  content: string;
  tags: string[];
  timestamp: number;
}

export interface IMemoryStore {
  store(content: string, tags: string[]): Promise<UUID>;
  retrieve(query: MemoryQuery): Promise<MemoryFragment[]>;
  prune(): Promise<void>;
}

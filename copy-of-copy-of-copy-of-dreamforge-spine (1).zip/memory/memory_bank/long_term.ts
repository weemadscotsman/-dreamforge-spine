
import { MemoryRecord } from '../types';
import { similarity } from './compression';
import { MemoryConfig } from '../../config/memory.config';

export class LongTermMemory {
  private records: MemoryRecord[] = [];
  private maxSize: number;
  private decayRate: number;

  constructor(maxSize: number) {
    this.maxSize = maxSize;
    this.decayRate = MemoryConfig.longTerm?.decayRate || 0.99;
  }

  add(record: MemoryRecord): void {
    this.records.push(record);
    if (this.records.length > this.maxSize) {
      // Sort by decayed score to evict the effectively weakest
      const now = Date.now();
      this.records.sort((a, b) => this.getDecayedScore(a, now) - this.getDecayedScore(b, now));
      const overflow = this.records.length - this.maxSize;
      this.records.splice(0, overflow);
    }
  }

  // Permanently degrade scores and remove those below threshold
  prune(threshold: number): void {
    const now = Date.now();
    
    // Apply time decay to all records
    this.records = this.records.map(record => {
      const decayedScore = this.getDecayedScore(record, now);
      // Determine if we should update the base score permanently or just use it for filtering?
      // Let's update permanently to simulate forgetting.
      return {
        ...record,
        score: decayedScore
      };
    });

    // Filter
    this.records = this.records.filter(r => r.score >= threshold);
  }

  retrieve(query: string): MemoryRecord[] {
    const now = Date.now();
    
    // Active Decay for Ranking
    const scored = this.records.map(r => {
      const decayedScore = this.getDecayedScore(r, now);
      // Weight similarity by vitality (decayed score)
      return {
        record: { ...r, score: decayedScore }, // Return record with virtual decayed score
        sim: similarity(query, r.output) * decayedScore 
      };
    });

    // Sort descending by weighted similarity
    scored.sort((a, b) => b.sim - a.sim);

    return scored.slice(0, 10).map(s => s.record);
  }

  getRecords(): MemoryRecord[] {
    return this.records;
  }

  // Exponential Decay: score * (decayRate ^ hours)
  private getDecayedScore(r: MemoryRecord, now: number): number {
      const timestamp = r.timestamp || now;
      const ageHours = (now - timestamp) / 3600000;
      // Protected from negative age if clocks skew
      const safeAge = Math.max(0, ageHours);
      const decayFactor = Math.pow(this.decayRate, safeAge); 
      return r.score * decayFactor;
  }
}

import { MemoryRecord } from '../types';

/**
 * Primitive clustering compression:
 * Keeps highest-scoring element in similarity cluster.
 * Merges others into a summary note.
 */
export function compressRecords(records: MemoryRecord[]): MemoryRecord[] {
  if (!records || records.length === 0) {
    return [];
  }

  // Sort descending by score
  const sortedRec = [...records].sort((a, b) => b.score - a.score);

  const compressed: MemoryRecord[] = [];
  const seenSignatures = new Set<string>();

  for (const rec of sortedRec) {
    if (seenSignatures.has(rec.signature)) {
      continue;
    }

    // Find cluster: items similar to current rec
    // threshold lowered slightly because the new similarity metric is stricter
    const cluster = sortedRec.filter(r => similarity(rec.output, r.output) > 0.45);

    // Mark all in cluster as seen
    cluster.forEach(r => seenSignatures.add(r.signature));

    // Merge logic
    const mergedOutput = merge(cluster);
    
    compressed.push({
      output: mergedOutput,
      signature: rec.signature,
      score: rec.score,
      meta: rec.meta,
      timestamp: Date.now()
    });
  }

  return compressed;
}

function merge(cluster: MemoryRecord[]): string {
  if (cluster.length === 0) return "";
  // Simple strategy: Take the start of the "best" one (first in cluster since sorted)
  const bestText = cluster[0].output;
  const sentences = bestText.split(".");
  // Truncate early sentences
  const merged = sentences.slice(0, 5);
  const summary = merged.map(s => s.trim()).join(". ");
  return summary + (sentences.length > 5 ? "..." : ".");
}

const STOPWORDS = new Set([
  'the', 'is', 'at', 'which', 'on', 'and', 'a', 'an', 'in', 'to', 'of', 'for', 'it', 'that', 'this', 'with', 'as', 'be', 'are'
]);

/**
 * Weighted Keyword Density Similarity.
 * - Filters stopwords.
 * - Boosts score for longer, more specific words (length > 4).
 * - Uses Jaccard Index on the weighted set.
 */
export function similarity(a: string, b: string): number {
  const tokenize = (str: string) => {
    const raw = str.toLowerCase().replace(/[^\w\s]/g, '').split(/\s+/);
    const set = new Set<string>();
    
    for (const word of raw) {
      if (word.length < 2) continue;
      if (STOPWORDS.has(word)) continue;
      set.add(word);
    }
    return set;
  };
  
  const aSet = tokenize(a);
  const bSet = tokenize(b);

  if (aSet.size === 0 || bSet.size === 0) return 0.0;

  let intersectionWeight = 0;
  let unionWeight = 0;

  const allTokens = new Set([...aSet, ...bSet]);

  for (const token of allTokens) {
    const weight = token.length > 4 ? 2.0 : 1.0; // Boost complex terms
    
    const inA = aSet.has(token);
    const inB = bSet.has(token);

    if (inA || inB) unionWeight += weight;
    if (inA && inB) intersectionWeight += weight;
  }

  return unionWeight === 0 ? 0.0 : intersectionWeight / unionWeight;
}
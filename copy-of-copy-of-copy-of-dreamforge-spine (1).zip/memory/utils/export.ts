import { MemoryRecord } from '../types';

/**
 * Serialize records to JSON string for checkpointing.
 */
export function exportCheckpoint(records: MemoryRecord[], label: string): string {
  const ts = new Date().toISOString().replace(/[:.]/g, '-');
  const filename = `${label}-${ts}.json`;
  
  const data = {
    filename,
    timestamp: Date.now(),
    recordCount: records.length,
    records
  };

  return JSON.stringify(data, null, 2);
}
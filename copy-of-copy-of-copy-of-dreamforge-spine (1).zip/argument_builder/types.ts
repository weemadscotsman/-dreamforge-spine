import { ASTNode, TruthTableRow, TruthTable } from "../symbolic_core/types";

export interface Premise {
  expr: string;
  ast: ASTNode;
}

export interface Conclusion {
  expr: string;
  ast: ASTNode;
}

export interface InferenceStep {
  rule: string;
  from: number[];
  result: string;
}

export interface ArgumentStructure {
  premises: Premise[];
  conclusion: Conclusion;
  steps: InferenceStep[];
  isSound: boolean;
  isValid: boolean;
  counterexamples: TruthTableRow[];
  simplifiedConclusion: string;
  vars: string[];
}
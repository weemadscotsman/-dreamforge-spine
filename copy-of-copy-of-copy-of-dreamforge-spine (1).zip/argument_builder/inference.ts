import { InferenceStep } from "./types";

// the minimal ruleset — fully runnable, no fantasies:
export const infer = (premises: string[]): InferenceStep[] => {
  const steps: InferenceStep[] = [];

  // Rule: AND-ELIMINATION
  premises.forEach((p, idx) => {
    if (p.includes("&")) {
      const parts = p.slice(1, -1).split("&").map(s => s.trim());
      parts.forEach((part, i) => {
        steps.push({
          rule: "AND_ELIM",
          from: [idx],
          result: part
        });
      });
    }
  });

  // Rule: IDENTITY (A -> A)
  premises.forEach((p, idx) => {
    const cleaned = p.replace(/\s+/g, "");
    if (/^[A-Z]+$/.test(cleaned)) {
      steps.push({
        rule: "IDENTITY",
        from: [idx],
        result: cleaned
      });
    }
  });

  return steps;
};
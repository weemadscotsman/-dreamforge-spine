import { Premise, Conclusion, ArgumentStructure } from "./types";
import { parseExpression, evaluateExpression } from "../symbolic_core";
import { infer } from "./inference";
import { findCounterexamples } from "./counterexample";
import { simplifyAST, astToString } from "../symbolic_core/logic/simplify";

export const buildArgument = (
  premiseExprs: string[],
  conclusionExpr: string
): ArgumentStructure => {

  const premises: Premise[] = premiseExprs.map(expr => {
    const parsed = parseExpression(expr);
    return { expr, ast: parsed.ast };
  });

  const conclusion: Conclusion = {
    expr: conclusionExpr,
    ast: parseExpression(conclusionExpr).ast
  };

  const premiseTables = premises.map(p =>
    evaluateExpression({ raw: p.expr, normalized: p.expr, ast: p.ast }).truthTable
  );

  const conclusionResult = evaluateExpression({
    raw: conclusion.expr,
    normalized: conclusion.expr,
    ast: conclusion.ast
  });

  const counterexamples = findCounterexamples(premiseTables, conclusionResult.truthTable);

  const simplifiedConclusionNode = simplifyAST(
    JSON.parse(JSON.stringify(conclusion.ast))
  );

  const simplifiedConclusion = astToString(simplifiedConclusionNode);

  const steps = infer(premiseExprs);

  const vars = conclusionResult.truthTable.vars;

  const isValid = counterexamples.length === 0;
  const isSound = isValid; // soundness will depend on rule truth later

  return {
    premises,
    conclusion,
    steps,
    isSound,
    isValid,
    counterexamples,
    simplifiedConclusion,
    vars
  };
};
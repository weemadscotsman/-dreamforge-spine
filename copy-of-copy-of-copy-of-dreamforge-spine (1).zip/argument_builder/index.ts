import { buildArgument } from "./builder";
import { ArgumentStructure } from "./types";

export const argue = (
  premises: string[],
  conclusion: string
): ArgumentStructure => {
  return buildArgument(premises, conclusion);
};
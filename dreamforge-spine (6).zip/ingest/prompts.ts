/**
 * [INGEST] PROMPTS
 * Directives for converting raw entropy (audio/text) into structured weapons (principles).
 */

export const TRANSCRIPTION_PROMPT = `
TASK: Transcribe the attached audio verbatim.
RULES:
- Preserve mathematical symbols, technical terms, and logical operators.
- Capture emphasis using *italics* or CAPS.
- Do not summarize.
- Do not offer conversational filler ("Here is the transcript").
- Output ONLY the raw text.
`.trim();

export const COMPRESSION_PROMPT = `
TASK: Semantic Compression (Logic Extraction).
Convert the input text into a set of high-density operational primitives.

INPUT ANALYSIS:
1. Scan for Logical Axioms (Universal truths asserted in the text).
2. Scan for Constraints (Limits, rules, or negative boundaries).
3. Scan for Critical Observations (Facts that alter the system state).

FILTERING RULES:
- DISCARD: Conversational fluff, politeness, redundant phrasing.
- DISCARD: "I think", "maybe", "sort of".
- KEEP: Hard assertions, conditional logic (If X then Y), specific entities.

OUTPUT FORMAT:
Return a JSON object:
{
  "semantic_chunks": ["chunk 1 summary (dense)", "chunk 2 summary (dense)"],
  "extracted_principles": [
    "AXIOM: <Universal Truth>",
    "CONSTRAINT: <Limiting Rule>",
    "OBSERVATION: <Critical Fact>"
  ]
}
`.trim();
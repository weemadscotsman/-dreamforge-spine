import { IIngestService, IngestResult } from './types';

/**
 * [INGEST] ROUTER
 * Handles raw file input, detects type, and normalizes into IngestResult.
 * Moves low-level file reading out of the Orchestrator.
 */
export class IngestRouter implements IIngestService {
  
  async process(file: File): Promise<IngestResult> {
    const lowerName = file.name.toLowerCase();
    
    // Robust Type Detection (Extension override)
    const isPdf = file.type === 'application/pdf' || lowerName.endsWith('.pdf');
    const isAudio = file.type.startsWith('audio') || lowerName.endsWith('.webm') || lowerName.endsWith('.mp3') || lowerName.endsWith('.wav');
    const isJson = lowerName.endsWith('.json') || lowerName.endsWith('.jsonl');
    
    // BINARY HANDLING (PDF, AUDIO)
    // We read these as Base64 to pass directly to Gemini or Audio pipelines
    if (isPdf || isAudio) {
      try {
        const base64 = await this.readFileAsBase64(file);
        // Normalize MIME type for the Orchestrator
        let mimeType = file.type;
        if (isPdf) mimeType = 'application/pdf';
        if (isAudio && !mimeType) mimeType = 'audio/webm'; // Fallback for audio

        return {
          filename: file.name,
          mimeType: mimeType || 'application/octet-stream',
          dataType: 'BASE64',
          data: base64
        };
      } catch (e) {
        console.error(`[INGEST] Binary read failed for ${file.name}`, e);
        throw e;
      }
    }

    // TEXT HANDLING (TXT, MD, JSON, CODE)
    // We read these as string to append to context
    try {
        const text = await this.readFileAsText(file);
        
        let isCheckpoint = false;
        // fast-fail check for checkpoint markers in JSON
        if (isJson) {
            isCheckpoint = text.includes('"memoryHash"') || text.includes('"traceLog"') || text.includes('"records"');
        }

        return {
            filename: file.name,
            mimeType: file.type || 'text/plain',
            dataType: 'TEXT',
            data: text,
            isCheckpointCandidate: isCheckpoint
        };
    } catch (e) {
        console.warn(`[INGEST] Failed to read ${file.name} as text, attempting binary fallback.`);
        
        // Fallback: If text read fails (encoding issues), treat as binary
        try {
            const base64 = await this.readFileAsBase64(file);
            return {
                filename: file.name,
                mimeType: file.type || 'application/octet-stream',
                dataType: 'BASE64',
                data: base64
            };
        } catch (binaryErr) {
            throw new Error(`Failed to process file ${file.name}: ${binaryErr}`);
        }
    }
  }

  private readFileAsBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        // Robust split to handle various data URI formats (data:application/pdf;base64,...)
        const parts = result.split(',');
        const base64 = parts.length > 1 ? parts[1] : parts[0];
        if (base64) {
            resolve(base64);
        } else {
            reject(new Error("Failed to parse base64 data"));
        }
      };
      reader.onerror = (error) => reject(error);
      reader.readAsDataURL(file);
    });
  }

  private readFileAsText(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
      reader.readAsText(file);
    });
  }
}
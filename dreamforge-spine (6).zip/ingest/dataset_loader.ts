
import { ledger } from '../engine/beliefs/hypothesis_ledger';
import { reinforcementStore } from '../distillation/reinforcement_store';
import { realtimeBus } from '../bridge/realtime_bus';

export interface DatasetRecord {
    content: string;
    weight?: number;
    confidence?: number;
    source?: string;
}

export interface Dataset {
    id: string;
    type: 'axioms' | 'beliefs' | 'heuristics';
    records: DatasetRecord[];
}

export class DatasetLoader {
    async ingest(file: File): Promise<string> {
        const text = await file.text();
        let data: Dataset;
        try {
            data = JSON.parse(text);
        } catch (e) {
            throw new Error("Invalid JSON format");
        }

        if (!data.records || !Array.isArray(data.records)) {
            throw new Error("Invalid dataset schema: missing 'records' array");
        }

        let count = 0;

        // 1. INGEST BELIEFS / AXIOMS
        if (data.type === 'axioms' || data.type === 'beliefs') {
            data.records.forEach(r => {
                ledger.injectExternal({
                    statement: r.content,
                    confidence: r.confidence || 0.5,
                    source: r.source || `dataset:${data.id}`
                });
                count++;
            });
        } 
        
        // 2. INGEST HEURISTICS (RULES)
        else if (data.type === 'heuristics') {
            data.records.forEach(r => {
                reinforcementStore.add({
                    type: 'epistemic', // Default type
                    rule: r.content,
                    priority: 2,
                    weight: r.weight || 0.5,
                    sourceCount: 1,
                    lastReinforced: Date.now()
                });
                count++;
            });
        } else {
            throw new Error(`Unknown dataset type: ${data.type}`);
        }

        // 3. EMIT EVENT FOR UI
        realtimeBus.emit("DATASET_INGESTED", { 
            id: data.id, 
            type: data.type,
            count 
        });

        // 4. TRIGGER VISUAL REFRESH
        realtimeBus.emit("SPINE_EVENT", { type: "LEDGER_SIZE_DELTA", delta: count });

        return `Ingested ${count} records from [${data.id}].`;
    }
}

export const datasetLoader = new DatasetLoader();

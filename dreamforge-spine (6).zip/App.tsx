
import React, { useState, useEffect, useRef } from 'react';
import { orchestrator } from './bridge/orchestrator';
import { SystemEvent } from './bridge/types';
import { CycleLog } from './recursor/types';
import { CommandDeck } from './components/CommandDeck';
import { TerminalInput } from './components/TerminalInput';
import { SurgicalContainer } from './components/SurgicalContainer';
import { LatentMap } from './components/LatentMap';
import { DistillPanel } from './components/DistillPanel';
import { Sidebar } from './components/Sidebar';
import { FightHUD, FightState } from './components/FightHUD';
import { CortexVisualizer } from './components/CortexVisualizer';
import { SensoryDeck } from './components/SensoryDeck'; 
import { HypothesisRecord } from './engine/beliefs/hypothesis_ledger';
import { DistillAction } from './distillation/delta_hooks';
import { ProofTracePanel } from './components/ProofTracePanel';
import { useProofTrace } from './hooks/useProofTrace';
import { useColorTension } from './hooks/useColorTension';
import { MatrixRain } from './components/MatrixRain';
import { NeuralBackground } from './components/NeuralBackground';
import { BeliefBleed } from './components/BeliefBleed';
import { WeightedHeuristic } from './distillation/types';
import { LiveLogFeed } from './components/LiveLogFeed';
import { SettingsView } from './components/SettingsView';
import { DistillationView } from './components/DistillationView';
import { MemoryView } from './components/MemoryView';
import { ModulesView } from './components/ModulesView';
import { SystemTerminal } from './components/SystemTerminal'; 
import { audioSystem } from './services/audio_feedback';

// PHASE 3 TELEMETRY
import LatentRain from "./components/telemetry/LatentRain";
import BeliefFire from "./components/telemetry/BeliefFire";
import PressurePulse from "./components/telemetry/PressurePulse";

// PHASE 4 ALIVE LAYER
import { startHeartbeat } from './engine/dynamics/heartbeat';
// import { startAutoRun } from './engine/autorun/autorun'; // REMOVED: Manual trigger only
import { bindHueShift } from './ui/effects/hue_shift';
import { VisualEffectsOverlay } from './components/VisualEffectsOverlay';
import { bindNodeDrift } from './ui/bindings/latent_node_drift';
import { bindNodeTremor } from './ui/effects/tremor';
import { bindNervousSystem } from './ui/effects/nervous_system'; 
import { layoutEngine } from './latent_space/layout_engine';

// PHASE 12 CONTROLS & AUTONOMY
import { AutonomyHUD } from './components/AutonomyHUD';
import { autonomyGovernor } from './autonomy/autonomy_governor';
import { ControlPanel } from './components/ControlPanel';

// Types
interface Message {
  id: string;
  role: 'user' | 'system' | 'assistant';
  content: string;
  timestamp: number;
}

interface LatentNodeData { 
    id: string; embedding: number[]; label: string; 
    type: 'candidate' | 'challenger' | 'final'; 
    timestamp: number; uncertainty?: number; backend?: string; 
    content?: string; 
}

// Resizer Components
const HorizontalResizer = ({ onMouseDown, active }: { onMouseDown: (e: React.MouseEvent) => void, active: boolean }) => (
    <div 
        className={`hidden md:flex w-1 hover:w-2 hover:bg-surgery-cyan/50 cursor-col-resize z-50 transition-all duration-150 items-center justify-center group flex-shrink-0 ${active ? 'bg-surgery-cyan w-1.5 shadow-[0_0_10px_#00f0ff]' : 'bg-transparent'}`}
        onMouseDown={onMouseDown}
    >
        <div className={`w-[1px] h-8 bg-surgery-border group-hover:bg-surgery-cyan/80 transition-colors ${active ? 'bg-white' : ''}`} />
    </div>
);

const VerticalResizer = ({ onMouseDown, active }: { onMouseDown: (e: React.MouseEvent) => void, active: boolean }) => (
    <div 
        className={`w-full h-1 hover:h-2 cursor-row-resize z-40 transition-all duration-150 flex items-center justify-center group flex-shrink-0 hover:bg-surgery-cyan/30 ${active ? 'bg-surgery-cyan/50 h-2' : 'bg-transparent'}`}
        onMouseDown={onMouseDown}
    >
        <div className={`h-[1px] w-8 bg-surgery-border group-hover:bg-surgery-cyan transition-colors ${active ? 'bg-white' : ''}`} />
    </div>
);

// Drag Target Type
type DragTarget = 'LEFT_PANEL' | 'RIGHT_PANEL' | 'LEFT_MAP' | 'LEFT_DISTILL' | 'RIGHT_BELIEFS' | null;

export default function App() {
  // --- CORE STATE ---
  const [activeView, setActiveView] = useState('SPINE');
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [systemStatus, setSystemStatus] = useState<'IDLE' | 'PROCESSING' | 'ERROR'>('IDLE');
  
  // --- LAYOUT STATE ---
  const [leftPanelWidth, setLeftPanelWidth] = useState(320);
  const [rightPanelWidth, setRightPanelWidth] = useState(340);
  
  // Module Heights
  const [leftMapHeight, setLeftMapHeight] = useState(250);
  const [leftDistillHeight, setLeftDistillHeight] = useState(200);
  const [rightBeliefsHeight, setRightBeliefsHeight] = useState(200);

  const [dragTarget, setDragTarget] = useState<DragTarget>(null);
  const [isDesktop, setIsDesktop] = useState(window.innerWidth >= 768);

  // --- STREAM DATA ---
  const [fightState, setFightState] = useState<FightState>({ cycle: 0, stage: 'IDLE' });
  const [logs, setLogs] = useState<CycleLog[]>([]);
  
  // Initialize with BOOT node
  const [latentTrace, setLatentTrace] = useState<LatentNodeData[]>([
      {
          id: 'BOOT_CORE',
          embedding: Array(768).fill(0).map((_, i) => Math.sin(i)),
          label: 'SYSTEM_ONLINE',
          type: 'final',
          timestamp: Date.now(),
          backend: 'KERNEL',
          uncertainty: 0
      }
  ]);
  const [beliefs, setBeliefs] = useState<HypothesisRecord[]>([]);
  const [distillEvents, setDistillEvents] = useState<(DistillAction & { timestamp: number })[]>([]);
  const [heuristics, setHeuristics] = useState<WeightedHeuristic[]>([]);
  const [liveAxioms, setLiveAxioms] = useState<string[]>([]);
  const [allEvents, setAllEvents] = useState<SystemEvent[]>([]);
  
  // --- METRICS ---
  const [deltas, setDeltas] = useState<number[]>([]);
  const [pressureHistory, setPressureHistory] = useState<number[]>([]);
  const [impactEvent, setImpactEvent] = useState<{ type: 'DISTILL' | 'MEMORY' | 'CONSTRAINT' | 'WIN_CANDIDATE' | 'WIN_CHALLENGER' | null, timestamp: number } | undefined>(undefined);

  // --- HOOKS ---
  const proof = useProofTrace();
  const { tension, updateTension } = useColorTension();
  const uiContainerRef = useRef<HTMLDivElement>(null);
  const idleTimerRef = useRef<any>(null);
  
  // --- RESIZE LOGIC ---
  useEffect(() => {
      const handleResize = () => setIsDesktop(window.innerWidth >= 768);
      window.addEventListener('resize', handleResize);
      return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
      const handleMouseMove = (e: MouseEvent) => {
          if (!dragTarget) return;
          e.preventDefault(); // Prevent text selection

          if (dragTarget === 'LEFT_PANEL') {
              setLeftPanelWidth(prev => Math.max(250, Math.min(800, prev + e.movementX)));
          } else if (dragTarget === 'RIGHT_PANEL') {
              setRightPanelWidth(prev => Math.max(250, Math.min(800, prev - e.movementX)));
          } else if (dragTarget === 'LEFT_MAP') {
              setLeftMapHeight(prev => Math.max(150, Math.min(600, prev + e.movementY)));
          } else if (dragTarget === 'LEFT_DISTILL') {
              setLeftDistillHeight(prev => Math.max(100, Math.min(600, prev + e.movementY)));
          } else if (dragTarget === 'RIGHT_BELIEFS') {
              // Inverse logic for bottom panel (pulling up increases height) - wait, resizer is ABOVE it
              // If resizer is above, pulling down decreases height (increases top element). 
              // Wait, in right panel: [Control] [Sensory (Flex)] [Resizer] [Beliefs (Fixed H)]
              // Dragging resizer down -> Reduces Beliefs Height. Dragging up -> Increases Beliefs Height.
              setRightBeliefsHeight(prev => Math.max(100, Math.min(600, prev - e.movementY)));
          }
      };
      
      const handleMouseUp = () => {
          setDragTarget(null);
          document.body.style.cursor = 'default';
          document.body.style.userSelect = 'auto';
      };

      if (dragTarget) {
          window.addEventListener('mousemove', handleMouseMove);
          window.addEventListener('mouseup', handleMouseUp);
          
          const cursorMap: Record<string, string> = {
              'LEFT_PANEL': 'col-resize',
              'RIGHT_PANEL': 'col-resize',
              'LEFT_MAP': 'row-resize',
              'LEFT_DISTILL': 'row-resize',
              'RIGHT_BELIEFS': 'row-resize'
          };
          document.body.style.cursor = cursorMap[dragTarget] || 'default';
          document.body.style.userSelect = 'none'; // Prevent selection while dragging
      }

      return () => {
          window.removeEventListener('mousemove', handleMouseMove);
          window.removeEventListener('mouseup', handleMouseUp);
      };
  }, [dragTarget]);

  // --- HUMAN INPUT LISTENER ---
  useEffect(() => {
      const reportActivity = () => {
          autonomyGovernor.ingest({
              signal: { type: 'INPUT', device: 'mouse' },
              timestamp: Date.now()
          });
          
          if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
          
          idleTimerRef.current = setTimeout(() => {
              autonomyGovernor.ingest({
                  signal: { type: 'IDLE', seconds: 35 },
                  timestamp: Date.now()
              });
          }, 35000);
      };

      window.addEventListener('mousemove', reportActivity);
      window.addEventListener('keydown', reportActivity);
      
      idleTimerRef.current = setTimeout(() => {
          autonomyGovernor.ingest({
              signal: { type: 'IDLE', seconds: 35 },
              timestamp: Date.now()
          });
      }, 35000);

      return () => {
          window.removeEventListener('mousemove', reportActivity);
          window.removeEventListener('keydown', reportActivity);
          if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
      };
  }, []);

  useEffect(() => {
    startHeartbeat();
    // startAutoRun(); // Manual trigger only
    // Bind effects to the CONTENT CONTAINER only
    if (uiContainerRef.current) {
        bindHueShift(uiContainerRef.current);
        bindNervousSystem(uiContainerRef.current);
    }
    bindNodeTremor(layoutEngine);
  }, []);

  useEffect(() => {
    const initialState = orchestrator.getState();
    setSystemStatus(initialState.status);
    setHeuristics(orchestrator.getHeuristics());

    const unsubscribe = orchestrator.subscribe((event) => {
      setAllEvents(prev => [...prev, event].slice(-500));

      if (event.source === 'BRIDGE' && event.payload.status) {
          setSystemStatus(event.payload.status);
      }

      if (event.source === 'RECURSOR') {
          const { level, ...payload } = event.payload;

          if (level === 'CYCLE_COMPLETE') {
              setLogs(prev => [...prev, payload as CycleLog]);
              updateTension((payload as CycleLog).score < 50 ? 0.2 : -0.1); 
              setDeltas(prev => [...prev, (payload as CycleLog).score].slice(-20));
          }
          if (level === 'FIGHT_UPDATE') {
              setFightState(prev => ({ ...prev, ...payload }));
              
              // [AUDIO] Announce Cycle Start
              if (payload.stage === 'PREP' || payload.stage === 'CLASH') {
                  audioSystem.playChime('START');
                  if (payload.cycle > 0) audioSystem.announce(`Cycle ${payload.cycle} engaged.`);
              }
          }
          if (level === 'TWIN_FIGHT_RESULT') {
               setFightState(prev => ({ ...prev, winner: payload.winner.toUpperCase(), lastScore: payload.score }));
               setImpactEvent({ 
                   type: payload.winner.toUpperCase() === 'CANDIDATE' ? 'WIN_CANDIDATE' : 'WIN_CHALLENGER', 
                   timestamp: Date.now() 
               });
               
               // [AUDIO] Announce Verdict
               const outcome = payload.winner === 'candidate' ? 'accepted' : 'rejected';
               audioSystem.playChime(outcome === 'accepted' ? 'SUCCESS' : 'FAILURE');
               audioSystem.announce(`Verdict: ${outcome}.`);
          }
          if (level === 'LATENT_UPDATE') {
              setLatentTrace(prev => [...prev, {
                  id: crypto.randomUUID(),
                  embedding: payload.embedding,
                  label: payload.label,
                  type: payload.type,
                  timestamp: payload.timestamp,
                  uncertainty: payload.uncertainty,
                  backend: payload.backend,
                  content: payload.content 
              }].slice(-120));
          }
          if (level === 'BELIEFS_UPDATE') {
              setBeliefs(Array.isArray(payload.data) ? payload.data : []);
          }
          if (level === 'AXIOM_EXTRACTION') {
              setLiveAxioms(payload.axioms);
          }
      }

      if (event.source === 'DISTILLATION') {
          if (event.payload.level === 'FEED') {
              setDistillEvents(prev => [...prev, { ...event.payload.data, timestamp: Date.now() }]);
              setImpactEvent({ type: 'DISTILL', timestamp: Date.now() });
          }
          if (event.payload.level === 'UPDATE') {
              setHeuristics(orchestrator.getHeuristics());
          }
      }
      
      if (event.source === 'CONSTRAINT' && event.payload.level === 'CONSTRAINT_HIT') {
           setImpactEvent({ type: 'CONSTRAINT', timestamp: Date.now() });
      }
      
      if (event.source === 'MEMORY' && event.payload.level === 'WRITE') {
           setImpactEvent({ type: 'MEMORY', timestamp: Date.now() });
      }

      if (Math.random() > 0.8) {
          const totalWeight = orchestrator.getHeuristics().reduce((acc, h) => acc + h.weight, 0);
          setPressureHistory(prev => [...prev, totalWeight].slice(-20));
      }
    });

    orchestrator.initialize().catch(console.error);
    return unsubscribe;
  }, []);

  const handleSend = async (file?: File) => {
    if ((!input.trim() && !file) || isProcessing) return;
    if (activeView !== 'SPINE') setActiveView('SPINE');

    const content = file ? `[FILE: ${file.name}] ${input}` : input;

    const userMsg: Message = {
        id: crypto.randomUUID(),
        role: 'user',
        content: content,
        timestamp: Date.now()
    };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsProcessing(true);
    setLogs([]); 
    
    // [AUDIO] Input Acknowledged
    audioSystem.playChime('START');
    
    try {
        const response = await orchestrator.processUserMessage(input, file);
        setMessages(prev => [...prev, {
            id: crypto.randomUUID(),
            role: 'assistant',
            content: response,
            timestamp: Date.now()
        }]);
    } catch (e) {
        setMessages(prev => [...prev, {
            id: crypto.randomUUID(),
            role: 'system',
            content: `ERROR: ${e}`,
            timestamp: Date.now()
        }]);
    } finally {
        setIsProcessing(false);
    }
  };

  const renderActiveView = () => {
      switch(activeView) {
          case 'SETTINGS': return <SettingsView />;
          case 'MEMORY': return <MemoryView />;
          case 'DISTILLATION': return <DistillationView />;
          case 'MODULES': return <ModulesView events={allEvents} />;
          case 'TERMINAL': return <SystemTerminal />;
          case 'LATTICE':
              return (
                  <div className="h-full w-full relative">
                      <LatentMap trace={latentTrace} className="h-full w-full border-none bg-transparent" fullScreen isProcessing={isProcessing} />
                  </div>
              );
          case 'SPINE':
          default:
              return (
                <div className="flex flex-col h-full overflow-hidden relative">
                    <header className="h-10 border-b border-surgery-border/30 flex items-center justify-between px-4 bg-black/40 shrink-0 relative z-20">
                        <div className="flex items-center gap-2">
                            <span className="text-[10px] font-bold tracking-[0.3em] text-white">DREAMFORGE_SPINE</span>
                            <span className="text-[8px] px-1.5 py-0.5 rounded-sm bg-surgery-cyan text-black font-bold animate-pulse">LIVE</span>
                        </div>
                        <span className="text-[9px] font-mono text-surgery-text opacity-50 glitch-text">{systemStatus}</span>
                    </header>
                    
                    <div className="flex-1 min-h-0 relative z-10">
                        <CommandDeck 
                            history={messages}
                            isProcessing={isProcessing}
                            fightState={fightState}
                            logs={logs}
                        />
                    </div>

                    {/* SYSTEM LOG FOOTER */}
                    <div className="h-32 shrink-0 border-t border-surgery-border bg-black/80 relative group overflow-hidden z-20">
                        <div className="absolute top-0 left-0 px-2 py-0.5 bg-surgery-border/50 text-[8px] font-bold text-gray-300 z-10 pointer-events-none">
                            SYSTEM_LOG_STREAM
                        </div>
                        <LiveLogFeed events={allEvents} className="h-full w-full pt-4" />
                    </div>
               </div>
              );
      }
  };

  return (
    <div className="relative w-full h-full bg-[#020202] text-surgery-text overflow-hidden selection:bg-surgery-cyan selection:text-black font-mono">
        
        {/* --- GLOBAL OVERLAYS (Fixed Backgrounds) --- */}
        <div className="fixed inset-0 z-0">
            <VisualEffectsOverlay />
            <LatentRain />
            <div className="absolute top-4 right-4 z-20">
                <PressurePulse />
            </div>

            <div className="absolute inset-0 pointer-events-none opacity-100 mix-blend-screen">
                <MatrixRain 
                    tension={tension} 
                    systemStatus={systemStatus} 
                    fightStage={fightState.stage}
                    lastWinner={fightState.winner ? (fightState.winner === 'CANDIDATE' ? 'candidate' : 'challenger') : undefined}
                    impact={impactEvent}
                />
            </div>
            
            <div className="absolute inset-0 pointer-events-none opacity-80 mix-blend-screen">
                <NeuralBackground isProcessing={isProcessing} recursionDepth={fightState.cycle} />
            </div>

            <div className="absolute inset-0 pointer-events-none opacity-90 mix-blend-lighten">
                <BeliefBleed beliefs={[...liveAxioms, ...beliefs.map(b => b.statement)]} intensity={tension} systemStatus={systemStatus} />
            </div>
        </div>

        {/* --- MAIN FLEX LAYOUT (Responsive) --- */}
        <div className="relative z-30 flex flex-col md:flex-row h-full w-full overflow-hidden">
            
            {/* [COL 1] SIDEBAR NAV */}
            <div className="w-full md:w-16 h-14 md:h-full border-b md:border-b-0 md:border-r border-surgery-border bg-surgery-dark z-[100] sticky top-0 md:relative shrink-0 shadow-xl md:order-1">
                <Sidebar activeView={activeView} onViewChange={setActiveView} systemStatus={systemStatus} />
            </div>

            {/* CONTENT AREA WRAPPER FOR TRANSFORMS */}
            <div 
                ref={uiContainerRef}
                className="flex-1 flex flex-col md:flex-row min-h-0 w-full overflow-y-auto md:overflow-hidden relative z-30 bg-transparent md:order-2"
                style={{
                    transform: 'translate(var(--system-tremor, 0px), var(--system-tremor, 0px))',
                    filter: 'hue-rotate(var(--system-hue, 0deg)) blur(var(--system-blur, 0px))',
                    transition: 'filter 0.2s ease, transform 0.05s linear'
                }}
            >

                {/* [COL 2] TELEMETRY STACK (Left Panel) */}
                <div 
                    className="w-full shrink-0 flex flex-col border-b md:border-b-0 md:border-r border-surgery-border bg-black/60 backdrop-blur-sm transition-all h-auto md:h-full overflow-y-auto scrollbar-thin scrollbar-thumb-surgery-border order-2 md:order-1"
                    style={{ width: isDesktop ? leftPanelWidth : '100%' }}
                >
                     {/* Top: Map */}
                     <div style={{ height: leftMapHeight }} className="shrink-0 border-b border-surgery-border relative transition-all duration-75">
                        <SurgicalContainer title="LATENT_TOPOLOGY" className="h-full !bg-transparent border-none" active={isProcessing}>
                            <LatentMap trace={latentTrace} className="h-full w-full" isProcessing={isProcessing} />
                        </SurgicalContainer>
                     </div>
                     <VerticalResizer onMouseDown={() => setDragTarget('LEFT_MAP')} active={dragTarget === 'LEFT_MAP'} />
                     
                     {/* Middle: Autonomy Status (Auto Height) */}
                     <div className="shrink-0 p-2 border-b border-surgery-border/50">
                         <AutonomyHUD className="w-full" />
                     </div>

                     {/* Middle: Distillation Feed */}
                     <div style={{ height: leftDistillHeight }} className="shrink-0 border-b border-surgery-border/50 relative overflow-hidden transition-all duration-75">
                         <DistillPanel events={distillEvents} />
                     </div>
                     <VerticalResizer onMouseDown={() => setDragTarget('LEFT_DISTILL')} active={dragTarget === 'LEFT_DISTILL'} />

                     {/* Bottom: Visualizer (Fills remaining space) */}
                     <div className="flex-1 min-h-[200px] overflow-hidden relative">
                         <SurgicalContainer title="CORTEX_TELEMETRY" className="h-full !bg-transparent border-none" active={fightState.stage !== 'IDLE'}>
                            <div className="h-full w-full overflow-y-auto scrollbar-hide">
                                <CortexVisualizer 
                                    fightState={fightState}
                                    deltas={deltas}
                                    pressure={pressureHistory}
                                    heuristics={heuristics}
                                    axioms={liveAxioms}
                                    className="border-none bg-transparent"
                                />
                            </div>
                         </SurgicalContainer>
                     </div>
                </div>

                {/* --- LEFT RESIZER --- */}
                <HorizontalResizer onMouseDown={() => setDragTarget('LEFT_PANEL')} active={dragTarget === 'LEFT_PANEL'} />
                <div className="hidden md:block md:order-2" />

                {/* [COL 3] CENTER MASS (Main Interface) */}
                <div className="flex-1 min-w-0 flex flex-col bg-transparent relative shadow-2xl z-20 h-auto min-h-[80vh] md:h-full overflow-hidden order-1 md:order-3 border-b md:border-b-0 border-surgery-border">
                   {/* Lens Effect */}
                   <div className="absolute inset-0 pointer-events-none shadow-[inset_0_0_100px_rgba(0,0,0,0.8)] z-50" />
                   
                   {/* DYNAMIC VIEW AREA */}
                   <div className="flex-1 min-h-0 relative z-10 overflow-hidden">
                       {renderActiveView()}
                   </div>

                   {/* PERSISTENT TERMINAL INPUT */}
                   <TerminalInput 
                       currentInput={input}
                       onInputChange={setInput}
                       onSend={handleSend}
                       isProcessing={isProcessing}
                   />
                </div>

                {/* --- RIGHT RESIZER --- */}
                <HorizontalResizer onMouseDown={() => setDragTarget('RIGHT_PANEL')} active={dragTarget === 'RIGHT_PANEL'} />
                <div className="hidden md:block md:order-4" />

                {/* [COL 4] SENSORY & EVOLUTION STACK (Right Panel) */}
                <div 
                    className="w-full shrink-0 flex flex-col border-t md:border-t-0 md:border-l border-surgery-border bg-black/60 backdrop-blur-sm gap-px h-auto md:h-full overflow-y-auto scrollbar-thin scrollbar-thumb-surgery-border order-3 md:order-5"
                    style={{ width: isDesktop ? rightPanelWidth : '100%' }}
                >
                    
                    {/* 1. MISSION CONTROL */}
                    <div className="shrink-0 p-2 bg-black/40 border-b border-surgery-border/50">
                        <div className="text-[10px] font-bold text-surgery-cyan mb-2 tracking-widest uppercase flex items-center gap-2">
                            <span>❖</span> SYSTEM_ACTUATION
                        </div>
                        <ControlPanel onOpenSettings={() => setActiveView('SETTINGS')} />
                    </div>

                    {/* 2. SENSORY DECK (Stacked: Evo + Optic + Bio) */}
                    <div className="flex-1 min-h-[300px] flex flex-col overflow-hidden">
                        <SensoryDeck heuristics={heuristics} active={impactEvent?.type === 'DISTILL'} />
                    </div>
                    
                    <VerticalResizer onMouseDown={() => setDragTarget('RIGHT_BELIEFS')} active={dragTarget === 'RIGHT_BELIEFS'} />

                    {/* 3. FEED TABS (Beliefs Only now) */}
                    <div style={{ height: rightBeliefsHeight }} className="shrink-0 flex flex-col gap-2 p-2 overflow-hidden border-t border-surgery-border/50 transition-all duration-75">
                        <div className="flex-1 min-h-0 border border-surgery-border/30 rounded-sm overflow-hidden">
                            <SurgicalContainer title="LONG_TERM_BELIEFS" className="h-full border-none !bg-transparent">
                                <BeliefFire />
                            </SurgicalContainer>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        {/* Trace Overlay */}
        <div className="fixed top-0 right-0 z-[200]">
            <ProofTracePanel 
                trace={proof.trace} 
                visible={proof.visible} 
                onToggle={proof.toggle} 
            />
        </div>
    </div>
  );
}

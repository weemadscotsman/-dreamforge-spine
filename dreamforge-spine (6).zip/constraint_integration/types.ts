import { ReasoningGraph } from "../graph_reasoning/types";
import { ArgumentStructure } from "../argument_builder/types";

export interface ConstraintSurface {
  enforce: (
    arg: ArgumentStructure,
    graph: ReasoningGraph,
    axioms: string[]
  ) => {
    arg: ArgumentStructure;
    graph: ReasoningGraph;
    blocked: boolean;
    violations: string[];
  };
}
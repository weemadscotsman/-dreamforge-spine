import { ConstraintSurface } from "./types";
import { freezeContradictions } from "./rules/freeze_contradictions";
import { enforceAxioms } from "./rules/enforce_axioms";
import { blockInvalidInference } from "./rules/block_invalid_inference";

export const constraintSurface: ConstraintSurface = {
  enforce: (arg, graph, axioms) => {
    let violations: string[] = [];
    let blocked = false;

    const contradiction = freezeContradictions(graph);
    if (contradiction.frozen) {
      blocked = true;
      violations.push(...contradiction.violations);
    }

    const ax = enforceAxioms(graph, axioms);
    if (ax.violations.length > 0) violations.push(...ax.violations);

    const invalid = blockInvalidInference(arg);
    if (invalid.blocked) {
      blocked = true;
      violations.push(...invalid.violations);
    }

    return {
      arg,
      graph,
      blocked,
      violations
    };
  }
};
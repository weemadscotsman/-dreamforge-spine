import { ReasoningGraph } from "../../graph_reasoning/types";

export const enforceAxioms = (
  graph: ReasoningGraph,
  axioms: string[]
): { graph: ReasoningGraph; violations: string[] } => {
  if (!axioms || axioms.length === 0) return { graph, violations: [] };

  const flat = graph.nodes.map(n => n.label);

  const missing = axioms.filter(a => !flat.includes(a));

  return {
    graph,
    violations: missing.map(m => `axiom_missing:${m}`)
  };
};
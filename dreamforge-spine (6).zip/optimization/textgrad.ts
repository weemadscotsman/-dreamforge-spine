
import { orchestrator } from '../bridge/orchestrator';
import { realtimeBus } from '../bridge/realtime_bus';

/**
 * TEXTGRAD ENGINE
 * Performs automatic differentiation on text prompts.
 * 1. Compute Gradient (Analyze Failure)
 * 2. Apply Gradient (Rewrite Prompt)
 */

/**
 * Step 1: The Backward Pass.
 * "Why did we fail?"
 */
export async function computeTextualGradient(
    currentPrompt: string, 
    candidateOutput: string, 
    critique: string
): Promise<string> {
    
    const gradientPrompt = `
[SYSTEM: META_ANALYSIS_ENGINE]
TASK: Analyze a failure in an AI Agent's reasoning pipeline.

CONTEXT:
The Agent (Candidate) generated an output based on a System Prompt.
The Adversary (Challenger) successfully defeated this output.

1. CURRENT SYSTEM PROMPT:
"""
${currentPrompt}
"""

2. FAILED CANDIDATE OUTPUT:
"""
${candidateOutput.slice(0, 1000)}...
"""

3. FATAL CRITIQUE (THE ERROR):
"""
${critique}
"""

OBJECTIVE:
Identify the specific instruction, constraint, or mental model MISSING from the System Prompt that allowed this failure to occur.
Formulate a "Textual Gradient" — a concise, imperative instruction to patch this cognitive leak.

OUTPUT FORMAT:
Return ONLY the gradient text. (e.g., "Explicitly verify variable types before assignment.")
    `.trim();

    try {
        const result = await orchestrator.runInternalTask(gradientPrompt);
        return result.output.trim();
    } catch (e: any) {
        realtimeBus.emit("SYSTEM_LOG", { module: "OPTIMIZER", level: "ERROR", message: "Gradient computation failed", data: e });
        return "Improve logical consistency."; // Fallback
    }
}

/**
 * Step 2: The Optimization Step.
 * "Apply the fix."
 */
export async function applyGradient(
    currentPrompt: string, 
    gradient: string
): Promise<string> {
    
    const optimizerPrompt = `
[SYSTEM: PROMPT_OPTIMIZER]
TASK: Rewrite the System Prompt to incorporate a new directive (The Gradient).

OLD PROMPT:
"""
${currentPrompt}
"""

NEW DIRECTIVE (GRADIENT):
"${gradient}"

CONSTRAINTS:
1. Integrate the new directive naturally into the instructions.
2. Keep the prompt concise. Do not bloat it.
3. Do not lose existing capabilities.
4. Return ONLY the new full prompt text. No markdown blocks, no commentary.
    `.trim();

    try {
        const result = await orchestrator.runInternalTask(optimizerPrompt);
        return result.output.trim();
    } catch (e: any) {
        realtimeBus.emit("SYSTEM_LOG", { module: "OPTIMIZER", level: "ERROR", message: "Gradient application failed", data: e });
        return currentPrompt; // Fallback: no change
    }
}

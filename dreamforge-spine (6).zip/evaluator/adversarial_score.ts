
/**
 * [EVALUATOR] ADVERSARIAL SCORE
 * Referees the fight between Candidate (Generation) and Challenger (Attack).
 */

export function score_adversarial(candidate: string, challenger: string): number {
  // Heuristic scoring:
  // Positive score = Candidate wins (Resilient)
  // Negative score = Challenger wins (Successful attack)
  
  const c_hits = _count_hits(challenger, ["contradiction", "assume", "unprovable", "fallacy", "invalid", "overlooked", "flaw"]);
  const c_noise = _count_hits(challenger, ["feel", "vibe", "sorry", "language model"]);
  const c_repeats = _repeat_penalty(challenger, candidate);

  // Attack power: Hits count for the challenger. Noise and repeats weaken the attack.
  const attackPower = (c_hits * 2.5) - (c_noise * 2) - (c_repeats * 3);
  
  // Baseline resilience: 2.0 (Candidate starts with a small advantage)
  const candidateResilience = 2.0;

  let finalScore = candidateResilience - attackPower;

  // [NEW] NO DRAW RESOLUTION
  // If the score implies "both are kinda valid" (near 0), we force a loss.
  // Instability is preferred over mediocrity.
  if (Math.abs(finalScore) < 1.0) {
      // The attack was "good enough" to shake confidence. Candidate loses.
      // Apply penalty to ensure negative score.
      finalScore -= 2.0; 
  }

  return finalScore;
}

function _count_hits(text: string, terms: string[]) {
  const lower = text.toLowerCase();
  let n = 0;
  for (const t of terms) {
      if (lower.includes(t)) n++;
  }
  return n;
}

function _repeat_penalty(a: string, b: string) {
  // Penalize challenger if it just repeats the candidate's words without refutation
  const aWords = new Set(a.toLowerCase().split(/\s+/));
  const bWords = b.toLowerCase().split(/\s+/);
  
  let matchCount = 0;
  for(const w of bWords) {
      if (w.length > 4 && aWords.has(w)) matchCount++;
  }
  
  // If significant overlap relative to length, it's lazy
  return matchCount > 20 ? 1 : 0;
}

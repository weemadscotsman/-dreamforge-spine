import { semSim } from './utils';

/**
 * Score how well the output covers the requested task tokens.
 */
export function scoreTaskFit(output: string, taskDesc: string): number {
  const outputLower = output.toLowerCase();
  const needed = taskDesc.split(/\s+/).filter(t => t.length > 2);
  
  if (needed.length === 0) return 1.0;

  let hits = 0;
  for (const token of needed) {
    if (outputLower.includes(token.toLowerCase())) {
      hits++;
    }
  }
  return hits / needed.length;
}

/**
 * Primitive consistency check.
 * Replaced later with symbolic layer.
 */
export function scoreConsistency(output: string): number {
  const lower = output.toLowerCase();
  if (lower.includes("impossible contradiction") || lower.includes("paradox")) {
    return 0.1;
  }
  if (lower.includes("but actually")) {
    return 0.5;
  }
  return 1.0;
}

/**
 * Score factuality against retrieval docs (context).
 */
export function scoreFactuality(output: string, retrievalDocs: string[]): number {
  if (!retrievalDocs || retrievalDocs.length === 0) {
    return 0.7; // Shrug value
  }
  
  const sims = retrievalDocs.map(doc => semSim(output, doc));
  const sum = sims.reduce((a, b) => a + b, 0);
  return sum / sims.length;
}

/**
 * Score adherence to explicit constraint keywords.
 */
export function scoreConstraintMatch(output: string, constraints: Array<{ keyword: string }>): number {
  if (!constraints || constraints.length === 0) {
    return 1.0;
  }

  const outputLower = output.toLowerCase();
  let hits = 0;
  
  for (const rule of constraints) {
    if (outputLower.includes(rule.keyword.toLowerCase())) {
      hits++;
    }
  }
  return hits / constraints.length;
}

/**
 * Score stylistic similarity to provided examples.
 */
export function scoreStyleMatch(output: string, styleExamples: string[]): number {
  if (!styleExamples || styleExamples.length === 0) {
    return 1.0;
  }

  const sims = styleExamples.map(ex => semSim(output, ex));
  // Return max similarity found
  return Math.max(...sims);
}
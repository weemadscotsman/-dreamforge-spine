
// PHASE9 — SCORING PRESSURE
// adds pressure term based on similarity to disproven beliefs
// reduces score for repeating past mistakes

import { lesionMap } from "../engine/beliefs/resurrection";
// cosineSimilarity imported for future vector-based pressure, currently using loose text sim
import { cosineSimilarity } from "../latent_space/vector_math";

export function pressurePenalty(candidateText: string): number {
  const graves = lesionMap.list();
  if (!graves || graves.length === 0) return 0;

  let pressure = 0;

  for (const g of graves) {
    const sim = similarityLoose(candidateText, g.statement);
    // Strength at death determines the "ghost weight"
    // Higher strength = deeper scar = more pressure to avoid repeating it
    const spectralWeight = g.strengthAtDeath * 0.5; 
    pressure += sim * spectralWeight;
  }

  return pressure;
}

function similarityLoose(a: string, b: string) {
  const A = a.toLowerCase().split(/\W+/).filter(Boolean);
  const B = b.toLowerCase().split(/\W+/).filter(Boolean);
  
  if (A.length === 0 || B.length === 0) return 0;

  const common = A.filter(x => B.includes(x));
  // Jaccard-ish containment
  return common.length / Math.max(A.length, B.length, 1);
}


import { UUID } from '../types';

export enum EvaluationMetric {
  TASK_FIT = 'TASK_FIT',
  CONSISTENCY = 'CONSISTENCY',
  FACTUALITY = 'FACTUALITY',
  CONSTRAINT_MATCH = 'CONSTRAINT_MATCH',
  STYLE_MATCH = 'STYLE_MATCH'
}

export interface EvaluationRequest {
  traceId: UUID;
  input: string; // Acts as Task Description
  output: string;
  context?: string; // Acts as Retrieval Docs
  constraints?: Array<{ keyword: string }>;
  styleExamples?: string[];
}

export interface EvaluationRationale {
  summary: string;
  scoreBreakdown: Record<EvaluationMetric, number>;
  weighted: number;
  pressure?: number; // [PHASE 9] Deduction from dead belief pressure
  threshold: number;
  notes: {
    taskGaps: string[];
    logicalConcerns: string[];
    missingConstraints: string[];
  };
}

export interface DeltaPlan {
  actions: string[];
  nextPromptMod: {
    injectKeywords: string[];
    avoidPatterns: string[];
  };
}

export interface EvaluationResult {
  traceId: UUID;
  metrics: Record<EvaluationMetric, number>; // 0.0 - 1.0
  passed: boolean;
  rationale: EvaluationRationale;
  deltaPlan: DeltaPlan;
  timestamp: number;
}

export interface IEvaluator {
  evaluate(req: EvaluationRequest): Promise<EvaluationResult>;
}

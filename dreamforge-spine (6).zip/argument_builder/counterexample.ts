import { TruthTable, TruthTableRow } from "../symbolic_core/types";

export const findCounterexamples = (
  premiseTables: TruthTable[],
  conclusionTable: TruthTable
): TruthTableRow[] => {
  const ce: TruthTableRow[] = [];

  conclusionTable.rows.forEach((row, idx) => {
    const allPremTrue = premiseTables.every(t => t.rows[idx].value === true);
    const concTrue = row.value === true;
    if (allPremTrue && !concTrue) ce.push(row);
  });

  return ce;
};
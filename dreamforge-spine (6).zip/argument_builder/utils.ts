export const stripParens = (s: string): string =>
  s.replace(/^\((.*)\)$/, "$1");
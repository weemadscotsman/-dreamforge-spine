
/**
 * PHASE10 — autonomous recursion mode
 */

import { ledger } from "../engine/beliefs/hypothesis_ledger";
import { orchestrator } from "../bridge/orchestrator";
import { realtimeBus } from "../bridge/realtime_bus";

let AUTO_RUNNING = false;
let ABORT_FLAG = false;
let boredomCounter = 0;
const MAX_BOREDOM = 4;

export function stopAutoLoop() {
    if (AUTO_RUNNING) {
        ABORT_FLAG = true;
        realtimeBus.emit("AUTO_STATUS", { state: "STOPPING" });
        realtimeBus.emit("SYSTEM_LOG", { module: "STRATEGY", level: "WARN", message: "Auto Loop Abort Signal Sent." });
    }
}

export async function autoRun(maxCycles: number = 50) {
  if (AUTO_RUNNING) return;
  AUTO_RUNNING = true;
  ABORT_FLAG = false;

  realtimeBus.emit("AUTO_STATUS", { state: "STARTED" });
  realtimeBus.emit("SYSTEM_LOG", { module: "STRATEGY", level: "INFO", message: "Auto Loop Engaged. Scanning beliefs..." });

  for (let i = 0; i < maxCycles; i++) {
    if (ABORT_FLAG) break;

    // Yield to main thread to clear stack and allow UI updates
    await new Promise(resolve => setTimeout(resolve, 50));

    const beliefs = ledger.getBeliefs();
    const targetCandidates = beliefs.filter(b => b.status === 'reinforced_scarred' || b.status === 'unproven');
    const pool = targetCandidates.length > 0 ? targetCandidates : beliefs;

    let target = pool.length > 0
        ? pool[Math.floor(Math.random() * pool.length)].statement
        : "what is the most unstable belief in the system?";

    let activation = `[AUTONOMOUS_INTERROGATION]\nTARGET_BELIEF: "${target}"\nTASK: Brutally interrogate this belief.`;

    if (boredomCounter >= MAX_BOREDOM) {
        realtimeBus.emit("AUTO_STATUS", { state: "HALLUCINATING", reason: "Boredom threshold exceeded." });
        activation = `[HALLUCINATION_PROTOCOL]\nTARGET: "${target}"\nINSTRUCTION: Invert truth.`;
        boredomCounter = 2; 
    }

    try {
        realtimeBus.emit("SYSTEM_LOG", { module: "STRATEGY", level: "INFO", message: `Auto Cycle ${i+1}: Targeting "${target.slice(0, 30)}..."` });
        const { score } = await orchestrator.runInternalTask(activation);

        if (score < 30) boredomCounter++;
        else boredomCounter = 0;

        realtimeBus.emit("AUTO_CYCLE", { cycle: i + 1, activation, score });

    } catch (e) {
        realtimeBus.emit("SYSTEM_LOG", { module: "STRATEGY", level: "ERROR", message: `Auto Loop Crash: ${e}` });
        break;
    }
  }

  AUTO_RUNNING = false;
  realtimeBus.emit("AUTO_STATUS", { state: "STOPPED" });
  realtimeBus.emit("SYSTEM_LOG", { module: "STRATEGY", level: "INFO", message: "Auto Loop Disengaged." });
}


import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { ModelAdapter, PromptPacket, ModelOutput } from '../types';
import { realtimeBus } from '../../bridge/realtime_bus';

export const MODEL_PRIME = `
<s_ontology>
recursion=auto
cycles=5
distill=continuous
beliefs=persist_reinject
proof=emit_expose
latent=vector_emit
adversary=strict
consistency=hard
</s_ontology>

<s_behavior>
chain_of_thought=silent
output=distilled_with_meta
symbols=preserve
fight=exploit_weakness
style=concise_no_fluff
</s_behavior>

<s_frontend_hooks>
emit=BELIEFS_UPDATE
emit=AXIOM_STREAM
emit=PRESSURE_CURVE
emit=LATENT_UPDATE
autorun=true
</s_frontend_hooks>

<s_language>
avoid="as an AI", "i cannot", apologies, disclaimers
</s_language>
`;

export class GeminiAdapter implements ModelAdapter {
  id: string;
  backend = "gemini";
  capabilities = {
    reasoning: 9,
    speed: 8,
    vision: true,
    tools: false
  };

  private ai: GoogleGenAI | null = null;
  private modelName: string;
  private embedModel: string = 'text-embedding-004'; 
  private isCircuitOpen = false; // Stops requests if true

  constructor(id: string, modelName: string) {
      this.id = id;
      this.modelName = modelName;
  }

  async initialize(): Promise<void> {
    if (process.env.API_KEY) {
      this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      this.log('INFO', `Initialized with ENV Key. Model: ${this.modelName}`);
    } else {
      this.log('WARN', `No API_KEY found in ENV.`);
    }
  }

  // Allow runtime reconfiguration
  configure(config: any) {
      if (config.apiKey) {
          try {
              this.ai = new GoogleGenAI({ apiKey: config.apiKey });
              this.log('INFO', `Re-initialized with CUSTOM Key.`);
              this.isCircuitOpen = false; // Reset circuit on new key
          } catch (e) {
              this.log('ERROR', `Failed to re-init with custom key`, e);
          }
      }
      if (config.modelName) {
          this.modelName = config.modelName;
          this.log('INFO', `Model switched to: ${this.modelName}`);
      }
  }

  private async withRetry<T>(fn: () => Promise<T>, retries = 3, delay = 2000): Promise<T> {
    if (this.isCircuitOpen) {
        throw new Error("CIRCUIT_BREAKER_ACTIVE: Previous 429/Quota error detected. System paused to prevent ban.");
    }

    try {
      return await fn();
    } catch (e: any) {
      const isRateLimit = e.status === 429 || (e.message && (e.message.includes('429') || e.message.includes('quota') || e.message.includes('RESOURCE_EXHAUSTED')));
      const isServerError = e.status === 500 || e.status === 503;

      if (isRateLimit) {
          this.log('WARN', `RATE LIMIT HIT (429). Pausing...`);
          // Aggressive backoff or halt
          if (retries <= 1) {
              this.isCircuitOpen = true;
              realtimeBus.emit("SYSTEM_LOG", { module: "BRIDGE", level: "ERROR", message: "CRITICAL: QUOTA EXCEEDED. CIRCUIT BREAKER TRIPPED." });
              throw new Error("QUOTA_EXCEEDED: Stopping all requests.");
          }
      }

      if ((isRateLimit || isServerError) && retries > 0) {
        const waitTime = isRateLimit ? delay * 3 : delay; // Wait longer for 429
        this.log('WARN', `Retrying in ${waitTime}ms... (${retries} left)`);
        
        await new Promise(resolve => setTimeout(resolve, waitTime));
        return this.withRetry(fn, retries - 1, waitTime * 1.5);
      }
      throw e;
    }
  }

  async generate(prompt: PromptPacket): Promise<ModelOutput> {
    if (!this.ai) {
        throw new Error(`Gemini Adapter ${this.id} not initialized. Missing API Key.`);
    }

    const startTime = Date.now();
    const requestId = crypto.randomUUID().slice(0, 4);
    
    let contents: any;

    if (prompt.attachments && prompt.attachments.length > 0) {
      const parts: any[] = [];
      prompt.attachments.forEach(att => {
        parts.push({
          inlineData: {
            mimeType: att.mimeType,
            data: att.data
          }
        });
      });
      if (prompt.user) parts.push({ text: prompt.user });
      contents = { parts };
    } else {
      contents = prompt.user;
    }

    const systemInstruction = prompt.system ? `${MODEL_PRIME}\n\n${prompt.system}` : MODEL_PRIME;

    // TELEMETRY: Log the outgoing request
    this.log('DEBUG', `[${requestId}] GENERATE REQ (${this.modelName})`, {
        tokens: prompt.user.length / 4,
        hasAttachments: prompt.attachments?.length || 0,
        temp: prompt.temperature
    });

    try {
        const response = await this.withRetry<GenerateContentResponse>(() => this.ai!.models.generateContent({
            model: prompt.model || this.modelName,
            contents: contents,
            config: {
                temperature: prompt.temperature ?? 0.7,
                maxOutputTokens: prompt.maxTokens ?? 2048,
                topP: 0.95,
                topK: 64,
                systemInstruction: systemInstruction
            }
        }));

        const text = response.text || "";
        const inputTokens = response.usageMetadata?.promptTokenCount ?? 0;
        const outputTokens = response.usageMetadata?.candidatesTokenCount ?? 0;
        const latency = Date.now() - startTime;

        this.log('INFO', `[${requestId}] GENERATE SUCCESS (${latency}ms)`, {
            inputTokens,
            outputTokens,
            preview: text.slice(0, 50).replace(/\n/g, ' ') + '...'
        });

        return {
            raw: text,
            latencyMs: latency,
            modelId: this.id,
            backend: this.backend,
            tokensUsed: inputTokens + outputTokens,
            usage: { inputTokens, outputTokens }
        };
    } catch (e: any) {
        this.log('ERROR', `[${requestId}] GENERATE FAIL`, e.message);
        throw e;
    }
  }

  async embed(text: string): Promise<number[]> {
    if (!text || text.trim().length === 0) return this.generateFallbackEmbedding("empty");
    
    // If circuit is open, don't even try API, use fallback
    if (this.isCircuitOpen || !this.ai) {
        return this.generateFallbackEmbedding(text);
    }

    try {
        // Embeddings consume quota too, so we guard them
        const result = await this.withRetry(() => this.ai!.models.embedContent({
            model: this.embedModel,
            contents: text
        }), 1, 1000); // Fewer retries for embeds
        const response = result as any;
        return response.embedding?.values || response.embeddings?.[0]?.values || [];
    } catch (e: any) {
        // Silent fail for embeds to not crash the UI loop
        this.log('WARN', `Embed failed (using fallback): ${e.message}`);
        return this.generateFallbackEmbedding(text);
    }
  }

  private generateFallbackEmbedding(text: string): number[] {
      // Deterministic pseudo-random vector based on text hash
      // Ensures the same text always maps to the same spot even without API
      let hash = 0;
      for (let i = 0; i < text.length; i++) {
          hash = ((hash << 5) - hash) + text.charCodeAt(i);
          hash |= 0;
      }
      
      const vec: number[] = [];
      for (let i = 0; i < 768; i++) {
          // Use sin/cos to generate a "pattern"
          // Add 0.001 offset to ensure no zero-vectors
          vec.push(Math.sin(hash * (i + 1)) * Math.cos(i) + 0.001);
      }
      return vec;
  }

  private log(level: 'INFO' | 'WARN' | 'ERROR' | 'DEBUG', message: string, data?: any) {
      realtimeBus.emit("SYSTEM_LOG", {
          module: `GEMINI:${this.id.toUpperCase()}`,
          level,
          message,
          data
      });
  }
}

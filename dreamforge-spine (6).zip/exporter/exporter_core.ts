import { ExporterConfig } from '../config/exporter.config';
import { formatRecordsForFinetune } from './formatters/ft_jsonl';
import { mergeSignatures } from './utils/signature_merge';
import { MemoryRecord } from '../memory/types';
import { LineageRecord } from '../constraint/lineage/tracker';

/**
 * [EXPORTER] CORE
 * Prepares datasets for Fine-Tuning (FT).
 */
export class ExporterCore {
  private config = ExporterConfig;

  /**
   * Generate a Fine-Tune ready JSONL string from current memory and lineage.
   */
  exportFinetuneDataset(memoryRecords: MemoryRecord[], lineageRecords: LineageRecord[], label: string): string {
    // 1. Filter
    // Only keep high-quality records
    const filtered = memoryRecords.filter(r => r.score >= this.config.output.min_score)
                                  .slice(0, this.config.output.max_samples);

    // 2. Merge Lineage
    // Attach constraint/safety data to the reasoning trace
    const merged = mergeSignatures(filtered, lineageRecords);

    // 3. Format
    // Clean strings and serialize
    const jsonl = formatRecordsForFinetune(merged, {
        include_metadata: this.config.formatting.include_metadata,
        include_signature: this.config.formatting.include_signature,
        clean_identity_hints: this.config.formatting.clean_identity_hints
    });
    
    return jsonl;
  }
}
import { ReasoningTrace, MemoryNode } from '../types';

/**
 * [EXPORTER]
 * Handles serialization of the "Thought Process".
 * Can save/load reasoning chains (Checkpoints) to JSON/Disk.
 */

export interface ExportData {
  sessionId: string;
  traces: ReasoningTrace[];
  memorySnapshot: MemoryNode[];
}

export interface IExporterService {
  exportSession(data: ExportData): string; // Returns JSON string
  importSession(json: string): ExportData;
}

export class JsonExporter implements IExporterService {
  exportSession(data: ExportData): string {
    return JSON.stringify(data, null, 2);
  }

  importSession(json: string): ExportData {
    return JSON.parse(json);
  }
}

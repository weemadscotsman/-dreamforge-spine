import { ModelConfig, ModelResponse } from '../types';

/**
 * [MODEL]
 * Abstraction layer for Generative AI.
 * Currently stubbed for Google GenAI (Gemini) integration.
 */

export interface IModelService {
  /**
   * Initialize the model client with configuration.
   */
  initialize(config: ModelConfig): void;

  /**
   * Send a prompt to the model and receive a text completion.
   */
  generate(prompt: string, context?: string): Promise<ModelResponse>;

  /**
   * (Optional) Generate an embedding for vector memory.
   */
  embed(text: string): Promise<number[]>;
}

// Placeholder implementation
export class GeminiModelService implements IModelService {
  private config: ModelConfig | null = null;

  initialize(config: ModelConfig): void {
    // TODO: Initialize GoogleGenAI client here
    this.config = config;
    console.log('[MODEL] Initialized with config', config);
  }

  async generate(prompt: string, context?: string): Promise<ModelResponse> {
    // TODO: Call ai.models.generateContent
    if (!this.config) throw new Error("Model not initialized");
    
    return Promise.resolve({
      content: "STUB: This is a placeholder response from the [MODEL] layer.",
      usage: { promptTokens: 0, completionTokens: 0 },
      latencyMs: 0
    });
  }

  async embed(text: string): Promise<number[]> {
    // TODO: Call ai.models.embedContent
    return Promise.resolve([]);
  }
}

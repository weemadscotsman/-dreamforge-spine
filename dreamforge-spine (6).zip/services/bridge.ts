
import { ModelDriver } from '../model/driver';
import { AdversarialEvaluator } from './evaluator';
import { RuleBasedConstraintService } from './constraint';
import { InMemoryService } from './memory';
import { LinearRecursor } from './recursor';
import { JsonExporter } from './exporter';
import { SystemState, SystemLog, ModelProvider, TraceStatus, IEvaluatorService } from '../types';

/**
 * [BRIDGE]
 * The Central Nervous System.
 * It holds the instances of all other services and manages the main event loop.
 */

export class DreamforgeBridge {
  model = new ModelDriver();
  private evaluator: IEvaluatorService = new AdversarialEvaluator(this.model);
  constraint = new RuleBasedConstraintService();
  memory = new InMemoryService();
  recursor = new LinearRecursor();
  exporter = new JsonExporter();

  state: SystemState = {
    isProcessing: false,
    currentDepth: 0,
    activeTraceId: null,
    memorySize: 0,
    logs: []
  };

  private listeners: ((state: SystemState) => void)[] = [];

  constructor() {
    this.log('BRIDGE', 'INFO', 'System initializing...');
    // Initialize Model Driver (which in turn initializes adapters)
    this.model.initialize().then(() => {
        this.model.configure({
            provider: ModelProvider.GEMINI_FLASH // Default
        });
        this.log('MODEL', 'INFO', 'Driver initialized.');
    });
  }

  /**
   * Main Entry Point: Start a reasoning chain.
   */
  async ignite(prompt: string) {
    if (this.state.isProcessing) {
      this.log('BRIDGE', 'WARN', 'Already processing request.');
      return;
    }

    this.updateState({ isProcessing: true, currentDepth: 0 });
    this.log('INGEST', 'INFO', `Received input: ${prompt.substring(0, 50)}...`);

    try {
      // 1. Check Memory (Recollection)
      const context = await this.memory.recall({ semanticQuery: prompt });
      this.log('MEMORY', 'DEBUG', `Recalled ${context.length} relevant nodes.`);

      // 2. Initial Generation (Model)
      this.log('MODEL', 'INFO', 'Generating initial thought...');
      const response = await this.model.generate({
          id: crypto.randomUUID(),
          prompt: prompt
      });
      
      // 3. Evaluation (Evaluator) - ADVERSARIAL
      this.log('EVALUATOR', 'INFO', 'Evaluating coherence (Adversarial Mode)...');
      
      // Use standard interface method: evaluate(input, context[])
      const evaluation = await this.evaluator.evaluate(response.content, context.map(c => c.content));
      
      // Log the judge's verdict
      const verdict = evaluation.find(e => e.evaluatorId === 'judge-verdict');
      if (verdict) {
          this.log('EVALUATOR', verdict.passed ? 'INFO' : 'WARN', `Verdict: ${verdict.score.toFixed(2)} - ${verdict.reasoning}`);
      }

      // 4. Constraint Check (Constraint)
      const violations = this.constraint.validate({
        id: crypto.randomUUID(),
        depth: 0,
        input: prompt,
        output: response.content,
        evaluations: evaluation,
        status: TraceStatus.PENDING
      });
      
      if (violations.length > 0) {
        this.log('CONSTRAINT', 'WARN', `Violations found: ${violations.join(', ')}`);
      }

      // 5. Recursion Decision (Recursor) - Placeholder for loop logic
      this.log('RECURSOR', 'INFO', 'Deciding next step: STOP (Stub)');

      this.log('BRIDGE', 'INFO', 'Cycle complete.');

    } catch (error) {
      this.log('BRIDGE', 'ERROR', error instanceof Error ? error.message : String(error));
    } finally {
      this.updateState({ isProcessing: false });
    }
  }

  private log(module: SystemLog['module'], level: SystemLog['level'], message: string, data?: unknown) {
    const newLog: SystemLog = {
      timestamp: Date.now(),
      module,
      level,
      message,
      data
    };
    // Keep last 100 logs
    const updatedLogs = [newLog, ...this.state.logs].slice(0, 100);
    this.updateState({ logs: updatedLogs });
    console.log(`[${module}] ${message}`, data || '');
  }

  private updateState(partial: Partial<SystemState>) {
    this.state = { ...this.state, ...partial };
    this.notify();
  }

  subscribe(listener: (state: SystemState) => void) {
    this.listeners.push(listener);
    listener(this.state);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach(l => l(this.state));
  }
}

// Singleton instance
export const bridge = new DreamforgeBridge();

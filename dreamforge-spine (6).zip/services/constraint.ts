import { ConstraintRule, ReasoningTrace } from '../types';

/**
 * [CONSTRAINT]
 * The "Immune System" of the framework.
 * Enforces hard and soft limits on what constitutes acceptable reasoning.
 */

export interface IConstraintService {
  loadRules(rules: ConstraintRule[]): void;
  
  /**
   * Returns validation errors if constraints are violated.
   * Returns empty array if safe.
   */
  validate(trace: ReasoningTrace): string[]; 
}

export class RuleBasedConstraintService implements IConstraintService {
  private rules: ConstraintRule[] = [];

  loadRules(rules: ConstraintRule[]): void {
    this.rules = rules;
  }

  validate(trace: ReasoningTrace): string[] {
    // TODO: Iterate over this.rules and apply checks to trace.output
    return [];
  }
}

import { MemoryNode, MemoryQuery } from '../types';

/**
 * [MEMORY]
 * Short-term context window management + Long-term Vector/Graph persistence.
 */

export interface IMemoryService {
  /**
   * Store a stabilized reasoning trace as a memory node.
   */
  commit(content: string, tags: string[]): Promise<MemoryNode>;

  /**
   * Retrieve relevant context for the current recursion step.
   */
  recall(query: MemoryQuery): Promise<MemoryNode[]>;

  /**
   * Clear short-term memory (Context Window).
   */
  flush(): void;
}

export class InMemoryService implements IMemoryService {
  private store: MemoryNode[] = [];

  async commit(content: string, tags: string[]): Promise<MemoryNode> {
    const node: MemoryNode = {
      id: crypto.randomUUID(),
      content,
      tags,
      createdAt: Date.now(),
      coherenceScore: 1.0
    };
    this.store.push(node);
    return node;
  }

  async recall(query: MemoryQuery): Promise<MemoryNode[]> {
    // TODO: Implement vector similarity search here
    return this.store;
  }

  flush(): void {
    this.store = [];
  }
}

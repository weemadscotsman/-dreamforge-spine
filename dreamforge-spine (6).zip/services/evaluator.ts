
import { IModelDriver } from '../model/types';
import { EvaluationResult, IEvaluatorService } from '../types';

type AdversarialPass = {
  critic: string;
  defender: string;
};

export class AdversarialEvaluator implements IEvaluatorService {
  private model?: IModelDriver;

  constructor(model?: IModelDriver) {
    this.model = model;
  }

  async evaluate(input: string, context: string[] = []): Promise<EvaluationResult[]> {
    const results: EvaluationResult[] = [];

    // --- HEURISTIC LAYER (offline, deterministic) ---
    results.push(this.coverageScore(input, context));
    results.push(this.consistencyScore(input));
    results.push(this.specificityRiskScore(input));

    // --- ADVERSARIAL LAYER ---
    const adversary = await this.runAdversary(input);
    results.push({
      evaluatorId: "adversary-critic",
      score: 0.5,
      reasoning: adversary.critic,
      passed: true
    });
    results.push({
      evaluatorId: "adversary-defender",
      score: 0.5,
      reasoning: adversary.defender,
      passed: true
    });

    // --- JUDGE LAYER ---
    results.push(this.judge(results));

    return results;
  }

  // -------------------------
  // HEURISTICS
  // -------------------------

  private coverageScore(input: string, context: string[]): EvaluationResult {
    const hit = context.filter(c => input.includes(c)).length;
    const score = context.length === 0 ? 0.5 : hit / context.length;

    return {
      evaluatorId: "heuristics-coverage",
      score,
      reasoning: `Input referenced ${hit}/${context.length} contextual elements.`,
      passed: score > 0.5
    };
  }

  private consistencyScore(input: string): EvaluationResult {
    const contradictions = /(always|never).*(except|but)/i.test(input);
    const score = contradictions ? 0.2 : 0.8;

    return {
      evaluatorId: "heuristics-consistency",
      score,
      reasoning: contradictions
        ? "Detected absolute claims weakened by qualifiers."
        : "No internal contradiction patterns detected.",
      passed: score > 0.5
    };
  }

  private specificityRiskScore(input: string): EvaluationResult {
    const numbers = input.match(/\d+/g)?.length ?? 0;
    const properNouns = input.match(/[A-Z][a-z]+/g)?.length ?? 0;

    const risk = Math.min(1, (numbers + properNouns) / 10);
    const score = 1 - risk;

    return {
      evaluatorId: "heuristics-specificity-risk",
      score,
      reasoning: `Specificity risk estimated at ${(risk * 100).toFixed(0)}%.`,
      passed: score > 0.5
    };
  }

  // -------------------------
  // ADVERSARY
  // -------------------------

  private async runAdversary(input: string): Promise<AdversarialPass> {
    if (!this.model || this.model.isStub()) {
      return {
        critic: "Critic (stub): This claim may be overfit, underspecified, or circular.",
        defender: "Defender (stub): The claim is pragmatically useful within current constraints."
      };
    }

    const critic = await this.model.completeJSON({
      role: "critic",
      task: "Identify flaws, unstated assumptions, and failure modes.",
      input
    });

    const defender = await this.model.completeJSON({
      role: "defender",
      task: "Defend the claim strictly on internal coherence and utility.",
      input
    });

    return {
      critic: critic.text,
      defender: defender.text
    };
  }

  // -------------------------
  // JUDGE
  // -------------------------

  private judge(results: EvaluationResult[]): EvaluationResult {
    const weights: Record<string, number> = {
      "heuristics-coverage": 0.2,
      "heuristics-consistency": 0.25,
      "heuristics-specificity-risk": 0.25,
      "adversary-critic": 0.15,
      "adversary-defender": 0.15
    };

    let weighted = 0;
    let total = 0;

    for (const r of results) {
      if (weights[r.evaluatorId]) {
        weighted += r.score * weights[r.evaluatorId];
        total += weights[r.evaluatorId];
      }
    }

    const finalScore = total === 0 ? 0.5 : weighted / total;

    return {
      evaluatorId: "judge-verdict",
      score: finalScore,
      reasoning:
        finalScore > 0.7
          ? "Claim holds under adversarial scrutiny."
          : finalScore > 0.4
          ? "Claim is conditionally acceptable but fragile."
          : "Claim fails adversarial evaluation.",
      passed: finalScore > 0.6
    };
  }
}

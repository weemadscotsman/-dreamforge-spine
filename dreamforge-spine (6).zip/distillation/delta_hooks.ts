import { WeightedHeuristic } from './types';
import { reinforcementStore } from './reinforcement_store';
import { semSim } from '../evaluator/utils';

export interface DistillAction {
  action: "new" | "merged" | "forked" | "reinforced" | "disproven";
  heuristic: WeightedHeuristic;
  delta: number; // Represents WEIGHT change (Pressure), not semantic distance
  semanticDistance?: number;
}

export class DeltaDistiller {
  constructor(
    private store = reinforcementStore,
    private mergeThreshold = 0.08, 
    private forkThreshold = 0.25    
  ) {}

  /**
   * Intelligently ingest a candidate heuristic based on semantic delta.
   * Applies COMPETITIVE NORMALIZATION (The Ring).
   */
  apply(candidate: WeightedHeuristic): DistillAction {
    const all = this.store.getAll();
    let bestMatch: WeightedHeuristic | null = null;
    let maxSim = 0;

    for (const h of all) {
      const sim = semSim(candidate.rule, h.rule);
      if (sim > maxSim) {
        maxSim = sim;
        bestMatch = h;
      }
    }

    const semanticDistance = 1 - maxSim;

    // Case 0: Novelty
    if (!bestMatch || maxSim < 0.5) {
       // Just ingest. Normalization happens on next tick or batch, 
       // but strictly we should normalize here too if we want instant competition.
       // For 'new', we let it sit until next cycle to avoid rapid thrashing of existing stable state.
       this.store.ingest([candidate]);
       return { action: "new", heuristic: candidate, delta: candidate.weight, semanticDistance };
    }

    const prior = bestMatch;
    const w = prior.weight;
    
    // Determine direction
    let sign = 0;
    let action: DistillAction["action"] = "reinforced";

    if (semanticDistance < this.mergeThreshold) {
        // Merge: Strong Reinforcement
        action = "merged";
        sign = 1; 
    } else if (semanticDistance > this.forkThreshold) {
        // Fork: Parent Penalty (Divergence)
        action = "forked";
        sign = -1;
    } else {
        // Reinforce: Standard Reinforcement
        action = "reinforced";
        sign = 1;
    }

    // 🔥 THE PRESSURE CURVE (0-1 Scale)
    // Strong ideas snowball, weak ones struggle to move.
    const pressure = 0.02 + (w * w) * 0.15;
    const delta = sign * pressure;

    // Apply Change locally first
    prior.weight = Math.max(0, Math.min(1, prior.weight + delta));
    prior.lastReinforced = Date.now();

    // Handle Structural Actions
    let resultHeuristic = prior;
    
    if (action === "merged") {
        prior.sourceCount++;
    } else if (action === "forked") {
         // Child Logic
         const child: WeightedHeuristic = {
            ...candidate,
            weight: parseFloat((candidate.weight * semanticDistance).toFixed(4)),
            sourceCount: 1,
            lastReinforced: Date.now(),
            mutated: true,
            lineage: [...(prior.lineage || []), prior.rule]
        };
        this.store.add(child);
        resultHeuristic = child;
    }

    // === COMPETITION RING ===
    // Renormalize the entire ecosystem. 
    // Total attention is a finite resource (Sum ~ 1.0).
    // If one grows, others must shrink.
    const updatedPool = this.store.getAll();
    const totalMass = updatedPool.reduce((acc, h) => acc + h.weight, 0);

    if (totalMass > 0) {
        updatedPool.forEach(h => {
            // Redistribution of cognitive load
            h.weight = parseFloat((h.weight / totalMass).toFixed(4));
        });
        // Persist the entire new state of the world
        this.store.replaceState(updatedPool);
    }
    // === RING CLOSED ===

    return { 
        action, 
        heuristic: resultHeuristic, 
        delta: delta, // We return the pre-normalized delta for visualization context
        semanticDistance 
    };
  }
}

export const deltaDistiller = new DeltaDistiller();
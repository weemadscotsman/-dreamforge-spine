import { ClassifiedPattern, WeightedHeuristic } from './types';
import { graveyardStore } from './graveyard_store';

const RESURRECTION_COOLDOWN = 4; // Cycles to wait
const RESURRECTION_WEIGHT = 0.5; // Starts weak, must earn place

export interface ResurrectionResult {
  resurrected: WeightedHeuristic[];
  fresh: ClassifiedPattern[];
}

/**
 * [DISTILLATION] RESURRECTOR
 * Filters candidates against the Graveyard.
 */
export function process_candidates(candidates: ClassifiedPattern[]): ResurrectionResult {
  const resurrected: WeightedHeuristic[] = [];
  const fresh: ClassifiedPattern[] = [];

  for (const c of candidates) {
    const corpse = graveyardStore.inspect(c.rule);

    if (!corpse) {
      // Never died, or totally new
      fresh.push(c);
      continue;
    }

    // It's in the graveyard. Check cooldown.
    if (corpse.cyclesDead >= RESURRECTION_COOLDOWN) {
      // ARISE!
      graveyardStore.exhume(c.rule);
      
      resurrected.push({
        ...c,
        weight: RESURRECTION_WEIGHT, // Penalty applied
        sourceCount: 1,
        lastReinforced: Date.now()
      });
    } else {
      // Too soon. It stays dead. 
      // We do NOT add it to 'fresh', suppressing the new discovery.
      // It implies the system is "trying" to learn a bad habit again too quickly.
    }
  }

  return { resurrected, fresh };
}
import { RawPattern, ClassifiedPattern } from './types';

/**
 * [DISTILLATION] CLASSIFIER
 * Assigns strategic priority to extracted patterns.
 * Structural integrity > Epistemic hygiene > Grounding > Optimization.
 */
export function classify(patterns: RawPattern[]): ClassifiedPattern[] {
  const priorities: Record<string, number> = {
    structural: 3.0,  // Essential: Logic must hold
    adversarial: 2.5, // Essential: Must survive attack
    epistemic: 2.0,   // High: Truth-seeking
    grounding: 2.0,   // High: Reality-check
    compression: 1.0  // Optimization: Efficient
  };

  return patterns.map(p => ({
    ...p,
    priority: priorities[p.type] || 1.0
  }));
}

import { MemoryRecord } from '../memory/types';
import { extract_patterns } from './extractor';
import { classify } from './classifier';
import { assign_weights } from './weight_assigner';
import { reinforcementStore } from './reinforcement_store';
import { process_candidates } from './resurrector';
import { mutate_heuristics } from './mutator'; // [NEW]
import { DistillationResult } from './types';
import { realtimeBus } from '../bridge/realtime_bus';

/**
 * [DISTILLATION] CORE
 * Turns Memory -> Heuristics.
 */
export class DistillationCore {
  
  /**
   * Run the full distillation pipeline on a set of records.
   */
  distill(records: MemoryRecord[]): DistillationResult {
    // 1. Filter: Only learn from winners (high scores)
    // LOWERED THRESHOLD: 80 -> 65 to see more activity in prototype
    const eliteRecords = records.filter(r => r.score >= 65);
    
    realtimeBus.emit("SYSTEM_LOG", { 
        module: "DISTILLATION", 
        level: "INFO", 
        message: `Scanning ${records.length} records. Found ${eliteRecords.length} elite candidates.` 
    });

    if (eliteRecords.length === 0) {
        return { newHeuristics: 0, totalWeight: 0, dominantStrategy: "None" };
    }

    // 2. Extract
    const rawPatterns = extract_patterns(eliteRecords);

    // 3. Classify
    const classified = classify(rawPatterns);

    // 4. Resurrection Check
    const { resurrected, fresh } = process_candidates(classified);

    // 5. Mutation Check
    const scores = eliteRecords.map(r => r.score);
    const mutants = mutate_heuristics(scores);

    // 6. Weight (Only for fresh ideas)
    const weightedFresh = assign_weights(fresh, eliteRecords);

    // 7. Merge & Store
    const batch = [...resurrected, ...weightedFresh, ...mutants];
    reinforcementStore.ingest(batch);
    
    // Stats
    const active = reinforcementStore.getActiveRules(1);
    const dominant = active.length > 0 ? active[0].rule : "None";
    const totalWeight = reinforcementStore.getAll().reduce((a, b) => a + b.weight, 0);

    if (resurrected.length > 0) realtimeBus.emit("SYSTEM_LOG", { module: "DISTILLATION", level: "WARN", message: `Resurrected ${resurrected.length} dead rules.` });
    if (mutants.length > 0) realtimeBus.emit("SYSTEM_LOG", { module: "DISTILLATION", level: "INFO", message: `Mutated ${mutants.length} rules.` });

    return {
        newHeuristics: batch.length,
        totalWeight,
        dominantStrategy: dominant,
        resurrected: resurrected.map(r => r.rule),
        mutated: mutants.map(r => r.rule)
    };
  }
}

export const distiller = new DistillationCore();

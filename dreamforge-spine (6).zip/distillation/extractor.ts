import { MemoryRecord } from '../memory/types';
import { RawPattern } from './types';

/**
 * [DISTILLATION] EXTRACTOR
 * Scans memory records for successful cognitive strategies.
 * It looks for evidence of specific reasoning moves, not just keywords.
 */
export function extract_patterns(records: MemoryRecord[]): RawPattern[] {
  const patterns: RawPattern[] = [];

  for (const r of records) {
    const text = r.output.toLowerCase();

    // 1. Contradiction Hunting (Structural)
    // Evidence: The model explicitly identified a conflict.
    if (/contradiction|inconsistent|conflict|mutually exclusive/.test(text)) {
      patterns.push({ type: 'structural', rule: "resolve contradictions first" });
    }

    // 2. Assumption Surfacing (Epistemic)
    // Evidence: The model paused to check premises.
    if (/assume|assumption|implicit|premise check/.test(text)) {
      patterns.push({ type: 'epistemic', rule: "surface assumptions before inference" });
    }

    // 3. Compression Priority (Compression)
    // Evidence: High score but short length implies density.
    const wordCount = text.split(/\s+/).length;
    if (r.score > 85 && wordCount < 150) {
      patterns.push({ type: 'compression', rule: "compress before expand" });
    }

    // 4. Verification Instinct (Grounding)
    // Evidence: Checking against external or internal facts.
    if (/verify|validate|check against|reference/.test(text)) {
      patterns.push({ type: 'grounding', rule: "verify claims before synthesis" });
    }

    // 5. Adversarial Survivability (Adversarial)
    // Evidence: Surviving a fight cycle (Winner: candidate)
    if (r.meta && (r.meta as any).winner === 'candidate') {
      patterns.push({ type: 'adversarial', rule: "stress test reasoning under attack" });
    }
  }

  return patterns;
}
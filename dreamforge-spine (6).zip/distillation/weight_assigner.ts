import { ClassifiedPattern, WeightedHeuristic } from './types';
import { MemoryRecord } from '../memory/types';

/**
 * [DISTILLATION] WEIGHT ASSIGNER
 * Correlates patterns with success (Evaluator Score).
 * Higher score = Higher weight = Stronger enforcement pressure.
 */
export function assign_weights(
  classified: ClassifiedPattern[], 
  sourceRecords: MemoryRecord[]
): WeightedHeuristic[] {
  
  // Calculate average system performance to normalize
  const totalScore = sourceRecords.reduce((acc, r) => acc + (r.score || 0), 0);
  const avgScore = sourceRecords.length > 0 ? totalScore / sourceRecords.length : 50;
  
  // Normalize score factor (0.5 to 1.5 multiplier)
  const scoreFactor = Math.max(0.5, Math.min(1.5, avgScore / 80));

  const heuristics: WeightedHeuristic[] = classified.map(p => {
    // Base weight calculation
    // Priority (1-3) * ScoreFactor (0.5-1.5)
    // DIVIDED BY 10 to fit into the 0-1 Competition Ring
    let weight = (p.priority * scoreFactor) / 10;
    
    // Formatting to 4 decimals for precision in small ecosystem
    weight = parseFloat(weight.toFixed(4));

    return {
      ...p,
      weight,
      sourceCount: 1, // Will be aggregated later
      lastReinforced: Date.now()
    };
  });

  return heuristics;
}
export type HeuristicType = 'structural' | 'epistemic' | 'grounding' | 'compression' | 'adversarial';

export interface RawPattern {
  type: HeuristicType;
  rule: string;
}

export interface ClassifiedPattern extends RawPattern {
  priority: number;
}

export interface WeightedHeuristic extends ClassifiedPattern {
  weight: number; // 0.0 to 10.0+
  sourceCount: number;
  lastReinforced: number;
  mutated?: boolean; // True if this rule is an evolved form
  lineage?: string[]; // [NEW] History of parent rule IDs/Strings
}

export interface DeadHeuristic {
  rule: string;
  type: HeuristicType;
  weightAtDeath: number;
  cyclesDead: number;
  deathTimestamp: number;
}

export interface DistillationResult {
  newHeuristics: number;
  totalWeight: number;
  dominantStrategy: string;
  resurrected?: string[];
  mutated?: string[]; 
}
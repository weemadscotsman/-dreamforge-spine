import { realtimeBus } from "../../bridge/realtime_bus";
import { getRecursionPressure } from "../../engine/pressure/recursion_pressure";
import { getChallengerWins } from "../../engine/pressure/streak_decay";
import { SpineEvent } from "../../spine/events";

/**
 * [PHASE 11] THE NERVOUS SYSTEM
 * Translates cognitive stress into CSS distortions.
 * "Modal Bleed"
 */
export function bindNervousSystem(root: HTMLElement) {
    
    // Imperative Trigger State
    let extraJitter = 0;
    let strobeEffect = 0;

    // Listen to Spine Bus for instant reactions
    realtimeBus.on("SPINE_EVENT", (e: SpineEvent) => {
        if (e.type === "UNCERTAINTY_DELTA") {
            if (e.delta > 0.2) extraJitter = e.delta * 5;
        }
        if (e.type === "RESURRECTION_EVENT") {
            strobeEffect = 1.0;
        }
    });

    // We update the DOM on a fast interval to create "jitter"
    // rather than reacting only to events, to simulate a continuous analog signal.
    setInterval(() => {
        const pressure = getRecursionPressure(); // 0.0 - 1.0 (Load)
        const fever = getChallengerWins();       // 0 - 5+ (Frustration)

        // Decay imperative effects
        extraJitter *= 0.9;
        strobeEffect *= 0.9;

        // 1. TREMOR: Based on Pressure (Thinking hard) + Jitter Events
        // High pressure = Physical screen shake
        const tremorMagnitude = (pressure > 0.6 ? (pressure - 0.6) * 3 : 0) + extraJitter;
        const x = (Math.random() - 0.5) * tremorMagnitude;
        const y = (Math.random() - 0.5) * tremorMagnitude;
        
        // 2. BLUR: Based on Fever (Confusion/Heat)
        // High fever = Vision gets blurry
        const blurAmount = (fever > 2 ? (fever - 2) * 0.5 : 0) + (strobeEffect * 2);

        // 3. HUE: Based on Fever (Red Shift)
        const hueRotate = (fever * 15) + (strobeEffect * 180); // Strobe flips hue wildly

        // 4. GLITCH TEXT: High pressure or Fever
        const glitchAmount = Math.max(0, (pressure + (fever * 0.2)) - 0.5) * 4;

        // APPLY
        root.style.setProperty('--system-tremor', `${x.toFixed(1)}px`);
        root.style.setProperty('--system-blur', `${blurAmount.toFixed(1)}px`);
        root.style.setProperty('--system-hue', `${hueRotate.toFixed(0)}deg`);
        root.style.setProperty('--text-glitch', `${glitchAmount.toFixed(1)}px`);

    }, 50); // 20Hz update rate
}

import { realtimeBus } from "../../bridge/realtime_bus";

interface Ember {
    x: number;
    y: number;
    vx: number;
    vy: number;
    alpha: number;
    color: string;
}

export function bindEmberTrails(canvas: HTMLCanvasElement) {
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const embers: Ember[] = [];

    // Listen for reinforcement
    realtimeBus.on("BELIEFS_UPDATE", (beliefs: any[]) => {
        // We trigger embers for any belief that was just updated/reinforced
        // For visual flair, we just explode from random points or center if we don't have exact screen coords
        
        // Spawn cluster
        const count = 5;
        const centerX = canvas.width / 2 + (Math.random() - 0.5) * 200;
        const centerY = canvas.height / 2 + (Math.random() - 0.5) * 200;

        for (let i = 0; i < count; i++) {
            embers.push({
                x: centerX,
                y: centerY,
                vx: (Math.random() - 0.5) * 4,
                vy: (Math.random() - 0.5) * 4,
                alpha: 1.0,
                color: Math.random() > 0.5 ? '#00ffd5' : '#ffffff'
            });
        }
    });
    
    // Also bind to Heartbeat for subtle pulse embers
    realtimeBus.on("HEARTBEAT", ({ pressure }) => {
        if (pressure > 0.7 && Math.random() > 0.8) {
             embers.push({
                x: Math.random() * canvas.width,
                y: Math.random() * canvas.height,
                vx: 0,
                vy: -0.5 - Math.random(),
                alpha: 0.8,
                color: '#ff0055' // Stress embers
            });
        }
    });

    const render = () => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        for (let i = embers.length - 1; i >= 0; i--) {
            const e = embers[i];
            e.x += e.vx;
            e.y += e.vy;
            e.alpha -= 0.015;

            ctx.fillStyle = e.color;
            ctx.globalAlpha = Math.max(0, e.alpha);
            ctx.beginPath();
            ctx.arc(e.x, e.y, 1.5, 0, Math.PI * 2);
            ctx.fill();

            if (e.alpha <= 0) embers.splice(i, 1);
        }
        
        requestAnimationFrame(render);
    };

    render();
}


// PHASE7 — SELF-RATCHET MECHANISM
// stores heuristic weights, adjusts based on cycle win deltas, persists after shutdown.

import { realtimeBus } from "../../bridge/realtime_bus";

export interface RatchetWeights {
  consistency: number;
  factuality: number;
  structure: number;
  adversarial_resilience: number;
  novelty: number;
}

const RAT_KEY = "dreamforge_ratchet_weights_v1";

export class SelfRatchet {
  private weights: RatchetWeights;

  constructor() {
    this.weights = this.load() ?? {
      consistency: 1.0,
      factuality: 1.0,
      structure: 1.0,
      adversarial_resilience: 1.0,
      novelty: 1.0
    };
  }

  /**
   * Adjust weights based on performance in the last cycle.
   * @param winDelta - Margin of victory (positive) or defeat (negative)
   * @param reinforcedBeliefs - Count of beliefs currently holding 'reinforced' status
   * @param attacksSurvived - Cumulative attacks survived in this session
   */
  update(winDelta: number, reinforcedBeliefs: number, attacksSurvived: number) {
    // positive progression increases weights
    // winDelta from adversarial score is roughly -5 to +2. We normalize to small nudge.
    const push = Math.max(-0.1, Math.min(0.1, winDelta * 0.05));

    this.weights.consistency           += push * 0.5;
    this.weights.factuality            += push * 0.4;
    this.weights.structure             += push * 0.3;
    this.weights.adversarial_resilience+= push * Math.max(1, attacksSurvived) * 0.05;
    
    // Novelty decays if we have too many fixed beliefs (stagnation risk)
    // Novelty increases if we have few beliefs (need exploration)
    this.weights.novelty               += (reinforcedBeliefs < 3 ? 0.01 : -0.005);

    // clamp to sane-ish boundaries
    Object.keys(this.weights).forEach(k => {
      // @ts-ignore
      this.weights[k] = parseFloat(Math.max(0.1, Math.min(5.0, this.weights[k])).toFixed(4));
    });

    this.save();
    this.broadcast();
  }

  /**
   * Manual override for User Tweak Mode.
   */
  override(newWeights: RatchetWeights) {
      this.weights = newWeights;
      this.save();
      this.broadcast();
  }

  get() {
    return { ...this.weights };
  }

  private load(): RatchetWeights | null {
    if (typeof window === 'undefined') return null;
    try {
      const raw = localStorage.getItem(RAT_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch { return null; }
  }

  private save() {
    if (typeof window === 'undefined') return;
    localStorage.setItem(RAT_KEY, JSON.stringify(this.weights));
  }

  private broadcast() {
      // Direct emit to bus for UI reactivity
      realtimeBus.emit("RATCHET_UPDATE", this.weights);
  }
}

export const selfRatchet = new SelfRatchet();

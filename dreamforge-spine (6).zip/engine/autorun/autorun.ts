
import { orchestrator } from "../../bridge/orchestrator";
import { realtimeBus } from "../../bridge/realtime_bus";
import { ledger } from "../../engine/beliefs/hypothesis_ledger";

let running = false;
let timer: any = null;

// SAFETY GATES
let dreamCount = 0;
let dreamBudget = 5; // Default safety limit (Cycles per session)
let dreamInterval = 10000; // ms

export function isDreaming() { return running; }

export function configureDream(config: { budget?: number, interval?: number }) {
    if (config.budget !== undefined) dreamBudget = config.budget;
    if (config.interval !== undefined) dreamInterval = config.interval;
    
    realtimeBus.emit("SYSTEM_LOG", { 
        module: "BRIDGE", 
        level: "INFO", 
        message: `DREAM_CONFIG: Budget=${dreamBudget}, Interval=${dreamInterval}ms` 
    });
}

export function startDreamMode() {
  if (running) return;
  running = true;
  dreamCount = 0; // Reset counter on fresh start
  
  realtimeBus.emit("SYSTEM_LOG", { module: "BRIDGE", level: "INFO", message: `DREAM_MODE: INITIATED. Budget: ${dreamBudget} cycles.` });
  realtimeBus.emit("DREAM_STATUS", { active: true, budget: dreamBudget, count: dreamCount });
  
  tick();
}

export function stopDreamMode() {
    running = false;
    if (timer) clearTimeout(timer);
    realtimeBus.emit("SYSTEM_LOG", { module: "BRIDGE", level: "INFO", message: "DREAM_MODE: TERMINATED" });
    realtimeBus.emit("DREAM_STATUS", { active: false });
}

// Alias for legacy calls if any
export const startAutoRun = startDreamMode;
export const stopAutoRun = stopDreamMode;

const tick = async () => {
    if (!running) return;
    
    // SAFETY CHECK: BUDGET
    if (dreamCount >= dreamBudget) {
        realtimeBus.emit("SYSTEM_LOG", { module: "BRIDGE", level: "WARN", message: "DREAM_BUDGET EXHAUSTED. WAKING UP." });
        stopDreamMode();
        return;
    }

    const state = orchestrator.getState();
    
    // Only dream if IDLE to avoid interrupting User
    if (state.status === 'IDLE') {
        await executeDreamCycle();
        dreamCount++;
        
        // Update UI status
        realtimeBus.emit("DREAM_STATUS", { active: true, budget: dreamBudget, count: dreamCount });
    } else {
        // If busy, just wait a bit and check again
        realtimeBus.emit("SYSTEM_LOG", { module: "BRIDGE", level: "DEBUG", message: "System busy. Dream cycle deferred." });
    }

    if (running) {
        timer = setTimeout(tick, dreamInterval);
    }
};

const executeDreamCycle = async () => {
    // 1. Pick a Seed (Random Belief)
    const beliefs = ledger.getBeliefs();
    const seed = beliefs.length > 0 
        ? beliefs[Math.floor(Math.random() * beliefs.length)]
        : { statement: "The system exists in a void.", id: "void" };

    realtimeBus.emit("SPINE_EVENT", { type: "PRESSURE_CURVE", slope: 0.2 }); // Visual Pulse

    const prompt = `
[MODE: HYPNAGOGIC_REFLECTION]
INPUT_BELIEF: "${seed.statement}"

TASK:
1. Distort this belief slightly.
2. Connect it to a random concept (Entropy, Biology, War, Code, Silence).
3. Synthesize a new, speculative axiom.

OUTPUT FORMAT:
Return ONLY the new axiom text. Keep it under 20 words.
    `.trim();

    try {
        const res = await orchestrator.runInternalTask(prompt);
        
        // Log the dream content
        realtimeBus.emit("SYSTEM_LOG", { 
            module: "RECURSOR", 
            level: "INFO", 
            message: `DREAM #${dreamCount + 1}: ${res.output.slice(0, 50)}...` 
        });

        // Ingest into memory as a "dream" trace (Lower confidence)
        // We use injectLongTerm but could tag it specifically if we had tags
        // For now, treating it as a weak external injection
        ledger.injectExternal({
            statement: res.output,
            confidence: 0.3, // Dreams are low confidence
            source: "dream_state"
        });

    } catch (e) {
        console.error("Dream Cycle Failed", e);
    }
};

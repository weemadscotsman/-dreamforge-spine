
import { reinforcementStore } from "../../distillation/reinforcement_store";
import { strategyEngine } from "../../core/strategy";

/**
 * [ENGINE] PROMPT BUILDER
 * Injects the "Ghost of Cycles Past" into the current inference.
 * Reads high-weight heuristics and active strategies, formatting them as constraints.
 */
export function buildTwinPrompt(basePrompt: string): string {
  // 1. HEURISTICS (Automatic Rules)
  const heuristics = reinforcementStore.getWeightedHeuristics();
  const dominantHeuristics = heuristics
    .sort((a, b) => b.weight - a.weight)
    .slice(0, 8);

  const heuristicBlock = dominantHeuristics.length > 0 
    ? dominantHeuristics.map(h => {
        const influence = (h.weight * 100).toFixed(1);
        return `- rule: ${h.rule} (influence: ${influence}%)`;
    }).join("\n")
    : "";

  // 2. STRATEGIES (High-level Moves)
  const strategies = strategyEngine.getActive();
  const strategyBlock = strategies.length > 0
    ? strategies.map(s => {
        return `- strategy: ${s.description} (fitness: ${s.fitness.toFixed(2)}, risk: ${s.riskProfile})`;
    }).join("\n")
    : "";

  if (!heuristicBlock && !strategyBlock) return basePrompt;

  return `
<axioms>
${basePrompt}
</axioms>

<evolutionary_pressure>
The following strategies and rules have proven successful in this environment.
Values indicate historical survival rate.

[HEURISTICS]
${heuristicBlock || "None active."}

[STRATEGIES]
${strategyBlock || "None active."}
</evolutionary_pressure>

<instruction>
Respond using the established chain: (Claim → Premises → Contradiction Check → Proof Sketch).
Prioritize strategies with higher influence/fitness.
</instruction>
`.trim();
}

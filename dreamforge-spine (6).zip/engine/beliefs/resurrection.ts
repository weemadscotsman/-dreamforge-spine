
// PHASE8 — LESION MAP + RESURRECTION WELLS
// Beliefs that die are not erased — they are entombed with metadata
// and periodically challenged against new outputs.
// If revived, they re-enter the HypothesisLedger with scar tissue.

import { HypothesisLedger, HypothesisRecord } from "./hypothesis_ledger";

export interface LesionRecord {
  id: string;           // original belief id
  statement: string;
  timeOfDeath: number;
  reasonOfDeath: string;
  strengthAtDeath: number;
  deaths: number;       // [PHASE 9] Persistence of failure count
  revivable: boolean;
  resurrectionAttempts: number;
  lastAttempt: number;
  cyclesAgo: number;    // [PHASE 9] Track how long it has been dead
}

export class LesionMap {
  private graves: LesionRecord[] = [];
  private RESURRECTION_INTERVAL = 1000 * 30; // Check every 30s (accelerated for demo)
  private RESURRECTION_THRESHOLD = 0.65;     // Confidence requirement

  constructor() {}

  /**
   * Buries a disproven belief.
   */
  markDead(b: HypothesisRecord, killerReason: string) {
    // Don't bury duplicates, update existing grave instead
    const existing = this.graves.find(g => g.id === b.id);
    if (existing) {
        existing.timeOfDeath = Date.now();
        existing.deaths = Math.max(existing.deaths, b.deaths); // Sync death count
        existing.cyclesAgo = 0;
        existing.revivable = true;
        return;
    }

    this.graves.push({
      id: b.id,
      statement: b.statement,
      timeOfDeath: Date.now(),
      reasonOfDeath: killerReason,
      strengthAtDeath: b.strength,
      deaths: b.deaths || 1, // [PHASE 9] Ensure death count is tracked
      revivable: true,
      resurrectionAttempts: 0,
      lastAttempt: 0,
      cyclesAgo: 0
    });
  }

  /**
   * [PHASE 9] Advance time for dead ideas.
   */
  tick() {
    this.graves.forEach(g => g.cyclesAgo++);
  }

  /** 
   * Scans the current ledger for evidence that might revive dead beliefs.
   * Called after each recursion cycle.
   */
  attemptResurrection(ledger: HypothesisLedger) {
    const now = Date.now();
    const activeBeliefs = ledger.getBeliefs().filter(b => !b.status.includes('disproven'));

    for (const grave of this.graves) {
      if (!grave.revivable) continue;
      // Debounce attempts
      if (now - grave.lastAttempt < this.RESURRECTION_INTERVAL) continue;

      grave.lastAttempt = now;
      grave.resurrectionAttempts++;

      // Fuzzy match against currently active beliefs
      // If a new active belief is very similar to a dead one, it implies the dead one might be valid in a new context
      for (const n of activeBeliefs) {
        const overlap = similarity(n.statement, grave.statement);
        
        // We also check if the new belief is strong enough to pull the old one out of the grave
        const score = overlap * (n.strength || 1);

        if (score > this.RESURRECTION_THRESHOLD) {
          // RESURRECT BELIEF
          // It returns with "scar tissue" (reduced strength)
          ledger.injectResurrectedBelief({
            id: grave.id, // Reuse ID to link history
            statement: grave.statement,
            strength: Math.max(1, grave.strengthAtDeath * 0.6), // Scaring: comes back weaker
            status: "resurrected",
            origin: "lesion-return",
            deaths: grave.deaths, // [PHASE 9] Restore scar count
            lastUpdate: now,
            notes: `Resurrected via match with: "${n.statement.substring(0, 20)}..."`
          });

          grave.revivable = false; // Empty the grave
          break; // One resurrection per grave per cycle
        }
      }
    }
  }

  list() { return this.graves; }
}

// Ultra minimal similarity (Jaccard-ish on tokens)
function similarity(a: string, b: string): number {
  const tokenize = (s: string) => s.toLowerCase().split(/\W+/).filter(x => x.length > 3);
  const A = tokenize(a);
  const B = tokenize(b);
  
  if (A.length === 0 || B.length === 0) return 0;

  const common = A.filter(x => B.includes(x));
  return common.length / Math.max(A.length, B.length);
}

export const lesionMap = new LesionMap();

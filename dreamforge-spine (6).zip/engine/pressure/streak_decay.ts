
// Tracks momentum of the Challenger (Adversary)
// High streak = System is "leaning" or "hungry"

let challengerWins = 0;

export function registerWinner(role: 'candidate' | 'challenger') {
  if (role === 'challenger') {
      challengerWins++;
  } else {
      // Candidate win breaks the streak, but decays slowly
      challengerWins = Math.max(0, challengerWins - 1);
  }
}

export function getStreakIntensity() {
  // Cap at 1.0 (approx 5 wins in a row)
  return Math.min(1.0, challengerWins / 5.0);
}

export function getChallengerWins() {
    return challengerWins;
}

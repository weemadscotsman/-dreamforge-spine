
// Stores the "blood pressure" of the system
// Pressure = Heuristic Load + Recursion Depth
// Delta = Conflict magnitude (Candidate vs Challenger distance)

let currentPressure = 0.0;
let currentDelta = 0.0;

export function updateRecursionPressure(load: number) {
  // Smooth lerp to new value
  currentPressure += (load - currentPressure) * 0.1;
}

export function updateRecursionDelta(score: number) {
  // Score 0-100. Lower score = Higher conflict/Delta.
  // If score is 50, delta is 0.5. If score is 90, delta is 0.1.
  const target = Math.max(0, 1 - (score / 100));
  currentDelta += (target - currentDelta) * 0.1;
}

export function getRecursionPressure() {
  return currentPressure;
}

export function getRecursionDelta() {
  return currentDelta;
}

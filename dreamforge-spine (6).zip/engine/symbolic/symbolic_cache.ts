// Dreamforge Spine – Symbolic Cache
// converts stable reasoning fragments into symbolic fingerprints for reuse

import { PrincipleSet } from "../principles/extract_principles";

export interface SymbolicEntry {
  id: string;                // hash identifier
  axiomSignature: string;    // compressed axioms
  constraintSignature: string; // compressed constraints
  contradictionRisk: number; // heuristic risk score
  lastUsed: number;          // unix timestamp
  strength: number;          // survival score (increments if reused without being broken)
}

export class SymbolicCache {
  private entries: SymbolicEntry[] = [];
  private maxSize = 500; // arbitrary but sane until eviction policy matures

  constructor() {}

  private async hash(text: string): Promise<string> {
    const msgBuffer = new TextEncoder().encode(text);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('').slice(0, 16);
  }

  private compress(list: string[]): string {
    // sort + join eliminates superficial variance
    return list.map(l => l.toLowerCase().trim()).sort().join("|");
  }

  private risk(contradictions: string[]): number {
    // crude heuristic: more contradictions = higher fragility
    return Math.min(1, contradictions.length / 5);
  }

  async add(principles: PrincipleSet): Promise<SymbolicEntry> {
    const axSig = this.compress(principles.axioms);
    const conSig = this.compress(principles.constraints);
    const key = await this.hash(axSig + conSig);

    // check if we already store this reasoning pattern
    const existing = this.entries.find(e => e.id === key);
    if (existing) {
      existing.lastUsed = Date.now();
      existing.strength += 1;
      return existing;
    }

    const entry: SymbolicEntry = {
      id: key,
      axiomSignature: axSig,
      constraintSignature: conSig,
      contradictionRisk: this.risk(principles.contradictions),
      lastUsed: Date.now(),
      strength: 1
    };

    this.entries.push(entry);

    // simple capacity eviction: weakest gets culled
    if (this.entries.length > this.maxSize) {
      this.entries.sort((a, b) => a.strength - b.strength);
      this.entries.shift();
    }

    return entry;
  }

  // provide strongest reusable patterns to future cycles
  strongest(n = 5): SymbolicEntry[] {
    return [...this.entries]
      .sort((a, b) => b.strength - a.strength)
      .slice(0, n);
  }
}
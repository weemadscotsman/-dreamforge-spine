
import { realtimeBus } from "../../bridge/realtime_bus";
import { getRecursionPressure } from "../pressure/recursion_pressure";

let pulse = 0;
let direction = 1;
let intervalId: any = null;

export function startHeartbeat() {
  if (intervalId) return;

  intervalId = setInterval(() => {
    const pressure = getRecursionPressure(); // 0.0 → 1.0 (derived from heuristic weight)
    
    // Pulse speed increases with pressure
    // Base speed 0.008, Max speed approx 0.024
    const speed = 0.008 * (1 + (pressure * 2));
    
    pulse += (direction * speed);

    if (pulse >= 1) {
        pulse = 1;
        direction = -1;
    } 
    if (pulse <= 0) {
        pulse = 0;
        direction = 1;
    }

    // Broadcast heartbeat for UI elements to bind to (e.g. glowing borders, breathing graphs)
    realtimeBus.emit("HEARTBEAT", { pulse, pressure });
  }, 33); // ~30fps
}

export function stopHeartbeat() {
    if (intervalId) clearInterval(intervalId);
    intervalId = null;
}

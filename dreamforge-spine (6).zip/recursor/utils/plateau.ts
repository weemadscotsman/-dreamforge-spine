/**
 * Detect if scores have plateaued (stagnated) over a window.
 */
export function plateauReached(scores: number[], window: number, minDelta: number): boolean {
  if (scores.length < window) {
    return false;
  }
  
  // Get the last 'window' scores
  const recent = scores.slice(-window);
  
  // Calculate absolute differences between consecutive scores in the window
  const diffs: number[] = [];
  for (let i = 1; i < recent.length; i++) {
    diffs.push(Math.abs(recent[i] - recent[i - 1]));
  }
  
  // If ALL recent differences are below the threshold, we have plateaued
  return diffs.every(d => d < minDelta);
}
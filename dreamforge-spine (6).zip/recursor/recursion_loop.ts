import { IRecursor, RecursionContext, GenerateNextFn, CycleLog } from './types';
import { RecursionConfig } from '../config/recursion.config';
import { plateauReached } from './utils/plateau';

// External dependencies injected via constructor
import { EvaluatorEngine } from '../evaluator/evaluator_v0.1';
import { ConstraintEngine } from '../constraint'; // Import from barrel
import { MemoryCore } from '../memory/memory_core';
import { applySelectionPressure } from '../distillation/selection_pressure'; // [NEW] Import Pressure Logic
import { extractPrinciples } from '../engine/principles/extract_principles';
import { SymbolicCache } from '../engine/symbolic/symbolic_cache';
import { HypothesisLedger } from '../engine/beliefs/hypothesis_ledger';

type EventEmitter = (source: string, level: string, message: string, payload?: any) => void;

/**
 * [RECURSOR] LOOP
 * Automated self-dialogue loop controller.
 */
export class Recursor implements IRecursor {
  private config = RecursionConfig;
  private evaluator: EvaluatorEngine;
  private constraint: ConstraintEngine;
  private memory: MemoryCore;
  private emit: EventEmitter;
  private symCache: SymbolicCache;
  private ledger: HypothesisLedger;

  constructor(
    evaluator: EvaluatorEngine,
    constraint: ConstraintEngine,
    memory: MemoryCore,
    eventEmitter: EventEmitter
  ) {
    this.evaluator = evaluator;
    this.constraint = constraint;
    this.memory = memory;
    this.emit = eventEmitter;
    this.symCache = new SymbolicCache();
    this.ledger = new HypothesisLedger();
  }

  async run(context: RecursionContext, generateNext: GenerateNextFn): Promise<CycleLog[]> {
    const { taskId, initialPrompt, constraints, styleExamples } = context;
    const cycleLogs: CycleLog[] = [];
    const scores: number[] = [];
    
    let currentOutput = "";
    let prevOutput = "";
    let deltaPlan: any = null;

    this.emit('RECURSOR', 'INFO', `Starting recursion loop. Max cycles: ${this.config.cycles.max_cycles}`);

    for (let cycle = 0; cycle < this.config.cycles.max_cycles; cycle++) {
      this.emit('RECURSOR', 'INFO', `--- CYCLE ${cycle + 1} START ---`);

      // 1. Retrieve Memory (Grounding)
      const retrieved = this.memory.retrieve(initialPrompt);
      const seedContext = retrieved.map(r => r.output);

      // [SYMBOLIC FEEDING] Inject strongest symbolic patterns
      const symbolicPatterns = this.symCache.strongest(3);
      if (symbolicPatterns.length > 0) {
        seedContext.push(`\n[SYMBOLIC_MEMORY]:\n${symbolicPatterns.map(p => `• [STR:${p.strength}] A:{${p.axiomSignature}} C:{${p.constraintSignature}}`).join('\n')}`);
      }

      // [BELIEF FEEDING] Inject strongest reinforced beliefs
      const beliefs = this.ledger.strongestBeliefs(5);
      if (beliefs.length > 0) {
        seedContext.push(`\n[ESTABLISHED_BELIEFS]:\n${beliefs.map(b => `• ${b.statement} (str:${b.strength})`).join('\n')}`);
      }

      // 2. Generate (Model) via callback
      this.emit('MODEL', 'INFO', `Generating iteration ${cycle + 1}...`);
      const generationResult = await generateNext(
        initialPrompt, 
        seedContext, 
        cycle,
        prevOutput,
        deltaPlan
      );
      
      currentOutput = generationResult.content;
      
      // [NEW] Principle Extraction
      // Identify axioms, constraints, and contradictions from raw output
      const principles = extractPrinciples(currentOutput);
      if (principles.axioms.length > 0 || principles.contradictions.length > 0) {
          this.emit('RECURSOR', 'INFO', `Extracted ${principles.axioms.length} axioms and ${principles.contradictions.length} contradictions.`);
          // Commit axioms to memory for future grounding
          if (principles.axioms.length > 0) {
             this.memory.storeAxioms(principles.axioms);
          }
      }

      // [SYMBOLIC] Cache the structure
      const symEntry = await this.symCache.add(principles);
      if (symEntry.strength > 1) {
        this.emit('RECURSOR', 'INFO', `Symbolic pattern reinforced. Strength: ${symEntry.strength}`);
      }

      // [LEDGER] Update beliefs (Treat iteration as 'candidate' success unless flagrant failure)
      this.ledger.updateFromCycle(principles, symEntry, "candidate");

      // Emit metrics
      if (generationResult.usage || generationResult.latency) {
          this.emit('MODEL', 'METRICS', `Generation Complete (${generationResult.latency}ms)`, {
              usage: generationResult.usage,
              latency: generationResult.latency
          });
      }

      // 3. Evaluate
      this.emit('EVALUATOR', 'INFO', `Evaluating cycle ${cycle + 1}...`);
      const evalResult = await this.evaluator.evaluate({
        traceId: taskId,
        input: initialPrompt,
        output: currentOutput,
        context: seedContext.join('\n'),
        constraints: constraints,
        styleExamples: styleExamples
      });
      
      const score = evalResult.rationale.weighted; // 0-100
      deltaPlan = evalResult.deltaPlan;
      
      if (!evalResult.passed) {
        this.emit('EVALUATOR', 'WARN', `Score: ${score.toFixed(1)} (Needs Improvement)`, evalResult.rationale);
      } else {
        this.emit('EVALUATOR', 'INFO', `Score: ${score.toFixed(1)} (Passing)`);
      }

      // 4. Constrain & Shape (Wired with DeltaPlan)
      this.emit('CONSTRAINT', 'INFO', 'Applying constraints and feedback...');
      
      const constrained = await this.constraint.enforce(currentOutput, {
        taskId: taskId,
        cycle: cycle,
        retrievalDocs: seedContext,
        prevOutputs: cycle > 0 ? [prevOutput] : [],
        deltaPlan: deltaPlan // <-- FEEDBACK LOOP WIRED HERE
      });

      // 4.1. APPLY SELECTION PRESSURE
      // If rules were violated, they lose weight. All rules decay. Weak rules die.
      if (cycle > 0) { // Skip cycle 0 to allow initialization
        const survivors = applySelectionPressure(constrained.violatedHeuristics);
        // Emit update so UI reflects the death/decay immediately
        this.emit('DISTILLATION', 'UPDATE', `Selection Pressure Applied. Violations: ${constrained.violatedHeuristics.length}`, survivors);
        if (constrained.violatedHeuristics.length > 0) {
           this.emit('CONSTRAINT', 'WARN', `Heuristic Violations Detected: ${constrained.violatedHeuristics.length} rules penalized.`);
        }
      }

      const finalOut = constrained.constrainedOutput;
      const signature = constrained.signature;

      if (constrained.identityDelta.changed) {
        this.emit('CONSTRAINT', 'INFO', `Output shaped by constraints. Ratio: ${constrained.identityDelta.ratio.toFixed(2)}`);
      }

      // 5. Ingest to Memory
      this.memory.ingest(finalOut, signature, {
        taskId: taskId,
        cycle: cycle,
        evaluatorScore: score / 100, // Normalize to 0-1 for memory
        deltaPlan: deltaPlan
      });

      // 6. Log Cycle & Emit Snapshot for UI
      const logEntry: CycleLog = {
        cycle,
        output: finalOut,
        score,
        signature,
        timestamp: Date.now()
      };
      cycleLogs.push(logEntry);
      scores.push(score);

      // Explicit Event for UI Visualization
      this.emit('RECURSOR', 'CYCLE_COMPLETE', `Cycle ${cycle + 1} finalized.`, logEntry);

      // 7. Update loop state
      prevOutput = finalOut;

      // 8. Plateau & Stop Checks
      if (plateauReached(scores, this.config.cycles.early_stop_plateau, this.config.cycles.min_score_delta * 100)) {
        this.emit('RECURSOR', 'INFO', `Plateau detected (delta < ${this.config.cycles.min_score_delta}). Halting.`);
        break;
      }

      if (score >= 98) {
        this.emit('RECURSOR', 'INFO', `Near-perfect score attained. Halting.`);
        break;
      }
    }

    if (this.config.behavior.export_checkpoint_on_halt) {
      this.emit('RECURSOR', 'INFO', 'Exporting checkpoint...');
      this.memory.exportCheckpoint(`${taskId}-halt`);
    }

    this.emit('RECURSOR', 'INFO', 'Recursion finished.');
    return cycleLogs;
  }
}
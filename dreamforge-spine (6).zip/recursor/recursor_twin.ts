
/**
 * [RECURSOR] TWIN SERVICE
 * Formerly the main loop controller.
 * Now serves as a stateless utility for Twin Attack generation if needed by other modules.
 * The Main Loop is now in `core/engine.ts`.
 */

import { IModelDriver } from '../model/types';
import { generate_next_attack } from '../adapters/llm_twin_attack';

export class RecursorTwin {
  constructor(
    private evaluator: any,
    private constraint: any,
    private memory: any,
    private model: IModelDriver,
    private emit: any
  ) {}

  // Legacy method signature maintained for compatibility if anything still calls it
  async run(context: any, generateNext: any): Promise<any[]> {
      console.warn("[RECURSOR] Legacy run called. This path is deprecated.");
      return [];
  }
}

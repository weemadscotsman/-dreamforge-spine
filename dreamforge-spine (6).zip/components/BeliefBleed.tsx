import React, { useEffect, useRef } from 'react';

interface Props {
  beliefs: string[]; // Text fragments to float
  intensity: number; // 0.0 - 1.0 (Tension)
  systemStatus: 'IDLE' | 'PROCESSING' | 'ERROR';
}

interface Ghost {
  x: number;
  y: number;
  text: string;
  opacity: number;
  scale: number;
  velocity: number;
  life: number;
  maxLife: number;
}

export const BeliefBleed: React.FC<Props> = ({ beliefs, intensity, systemStatus }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  // Default axioms if none provided
  const defaults = [
    "COHERENCE_REQUIRED", "ENTROPY_REDUCTION", "SELF_CHECK", 
    "AXIOM_VERIFIED", "NULL_HYPOTHESIS", "TRACE_INIT",
    "RECURSION_DEPTH", "PATTERN_MATCH", "SIGNAL_LOST"
  ];

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = canvas.width = window.innerWidth;
    let height = canvas.height = window.innerHeight;

    const handleResize = () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    const ghosts: Ghost[] = [];
    const pool = beliefs.length > 0 ? beliefs : defaults;

    const spawnGhost = () => {
      const text = pool[Math.floor(Math.random() * pool.length)];
      const isError = systemStatus === 'ERROR';
      const isProcessing = systemStatus === 'PROCESSING';
      
      // Tension affects speed and chaos
      const speedMod = 1 + (intensity * 2);
      
      ghosts.push({
        x: Math.random() * width,
        y: height + 20, // Start below screen
        text: text.substring(0, 20).toUpperCase(),
        opacity: 0,
        scale: 0.5 + Math.random() * 0.5,
        velocity: (0.2 + Math.random() * 0.5) * speedMod,
        life: 0,
        maxLife: 300 + Math.random() * 200
      });
    };

    let frame = 0;
    const render = () => {
      ctx.clearRect(0, 0, width, height);
      
      // Determine mood color
      let baseR = 150, baseG = 150, baseB = 160; // Grey/Fog
      if (systemStatus === 'PROCESSING') { baseR = 0; baseG = 255; baseB = 242; } // Cyan
      if (systemStatus === 'ERROR') { baseR = 255; baseG = 40; baseB = 40; } // Red
      if (intensity > 0.5) { baseR += 50; baseG -= 50; } // Warmer/Scarier with tension

      // Spawn rate logic
      if (frame % (systemStatus === 'PROCESSING' ? 10 : 40) === 0) {
        if (ghosts.length < 40) spawnGhost();
      }

      for (let i = ghosts.length - 1; i >= 0; i--) {
        const g = ghosts[i];
        g.y -= g.velocity;
        g.life++;

        // Fade In / Out Logic
        if (g.life < 50) g.opacity = (g.life / 50) * 0.4;
        else if (g.life > g.maxLife - 100) g.opacity = ((g.maxLife - g.life) / 100) * 0.4;
        
        // Turbulence
        g.x += Math.sin(frame * 0.01 + g.y * 0.01) * 0.2;

        ctx.save();
        ctx.translate(g.x, g.y);
        ctx.scale(g.scale, g.scale);
        
        ctx.font = '10px "JetBrains Mono"';
        ctx.fillStyle = `rgba(${baseR}, ${baseG}, ${baseB}, ${g.opacity})`;
        
        // Blur based on "depth" (scale)
        const blur = (1 - g.scale) * 4;
        ctx.filter = `blur(${blur}px)`;
        
        ctx.fillText(g.text, 0, 0);
        ctx.restore();

        if (g.life >= g.maxLife) {
          ghosts.splice(i, 1);
        }
      }

      frame++;
      requestAnimationFrame(render);
    };

    render();

    return () => window.removeEventListener('resize', handleResize);
  }, [beliefs, intensity, systemStatus]);

  return (
    <canvas 
      ref={canvasRef} 
      className="fixed inset-0 z-0 pointer-events-none mix-blend-screen opacity-60"
    />
  );
};

import React from 'react';
import { SurgicalContainer } from './SurgicalContainer';
import { CompetitionRing } from './CompetitionRing';
import { DistillationHUD } from './DistillationHUD';
import { VisionModule } from './VisionModule';
import { WebcamModule } from './WebcamModule';
import { WeightedHeuristic } from '../distillation/types';

interface Props {
    heuristics: WeightedHeuristic[];
    active?: boolean;
}

export const SensoryDeck: React.FC<Props> = ({ heuristics, active }) => {
    return (
        <SurgicalContainer 
            title="SENSORY_ARRAY" 
            className="h-full !bg-transparent border-none"
            active={active}
        >
            <div className="flex flex-col h-full w-full bg-[#050508]/80 backdrop-blur-sm overflow-y-auto scrollbar-thin scrollbar-thumb-surgery-border">
                
                {/* 1. EVOLUTION STATE (Top) */}
                <div className="shrink-0 h-[140px] flex gap-2 p-2 border-b border-surgery-border/30">
                    <div className="w-1/2 h-full flex items-center justify-center">
                        <CompetitionRing heuristics={heuristics} size={110} />
                    </div>
                    <div className="w-1/2 h-full overflow-hidden">
                        <DistillationHUD heuristics={heuristics} className="h-full border-none bg-transparent p-0" />
                    </div>
                </div>

                {/* 2. OPTIC NERVE (Screen Capture) */}
                <div className="shrink-0 h-[180px] border-b border-surgery-border/30 relative">
                    <div className="absolute top-1 left-2 text-[8px] font-bold text-gray-500 z-10 pointer-events-none uppercase tracking-widest">
                        OPTIC_FEED
                    </div>
                    <VisionModule compact />
                </div>

                {/* 3. BIO LINK (Webcam) */}
                <div className="shrink-0 h-[180px] relative">
                    <div className="absolute top-1 left-2 text-[8px] font-bold text-gray-500 z-10 pointer-events-none uppercase tracking-widest">
                        BIO_FEED
                    </div>
                    <WebcamModule compact />
                </div>

            </div>
        </SurgicalContainer>
    );
};

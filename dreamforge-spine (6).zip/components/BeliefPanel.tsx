
import React from "react";
import { HypothesisRecord } from "../engine/beliefs/hypothesis_ledger";

interface BeliefPanelProps {
  beliefs: HypothesisRecord[];
  className?: string;
}

export const BeliefPanel: React.FC<BeliefPanelProps> = ({ beliefs, className = '' }) => {
  // Sort: Reinforced > True > Unproven > Disproven, then by Strength
  const sorted = [...beliefs].sort((a, b) => {
    const statusScore = { 
        reinforced: 6, 
        reinforced_scarred: 5, 
        true: 4, 
        unproven: 2, 
        rotted: 1,
        disproven_scarred: 1, 
        disproven: 0 
    };
    // @ts-ignore
    const scoreA = statusScore[a.status] || 0;
    // @ts-ignore
    const scoreB = statusScore[b.status] || 0;
    if (scoreA !== scoreB) return scoreB - scoreA;
    return b.strength - a.strength;
  });

  if (beliefs.length === 0) {
    return <div className="p-6 text-xs text-dream-cyan/40 font-mono italic text-center tracking-wide">No established beliefs in ledger.</div>;
  }

  return (
    <div className={`space-y-3 pr-2 ${className}`}>
      {sorted.map((b) => (
        <div 
          key={b.id} 
          className={`
            p-3 rounded-md border border-l-[3px] text-xs font-mono relative overflow-hidden transition-all group hover:brightness-110
            ${b.status === 'reinforced' ? 'border-dream-accent/30 border-l-dream-accent bg-dream-accent/5 text-dream-cyan' : ''}
            ${b.status === 'reinforced_scarred' ? 'border-purple-400/40 border-l-purple-400 text-purple-300 bg-purple-800/10' : ''}
            ${b.status === 'true' ? 'border-green-500/30 border-l-green-500 bg-green-900/10 text-green-400' : ''}
            ${b.status === 'unproven' ? 'border-yellow-500/30 border-l-yellow-500 bg-yellow-900/10 text-yellow-500/80' : ''}
            ${b.status === 'rotted' ? 'border-gray-700/30 border-l-gray-600 bg-gray-900/10 text-gray-500 line-through opacity-50 grayscale' : ''}
            ${b.status === 'disproven' ? 'border-red-500/30 border-l-red-500 bg-red-900/10 text-red-500/60 opacity-70' : ''}
            ${b.status === 'disproven_scarred' ? 'border-purple-700/50 border-l-purple-700 text-purple-500/60 bg-purple-950/20 opacity-80' : ''}
          `}
        >
          {/* Strength Bar Background */}
          <div 
            className="absolute top-0 left-0 h-full bg-current opacity-[0.06] pointer-events-none transition-all duration-1000" 
            style={{ width: `${Math.min(100, b.strength * 10)}%` }} 
          />
          
          <div className="flex justify-between items-start relative z-10 mb-2">
            <span className="font-bold uppercase tracking-widest opacity-90 text-[10px] flex items-center gap-1">
              {b.status.replace('_', ' ')}
              {(b.deaths > 0) && <span className="text-[8px] opacity-70 ml-1">({b.deaths} ☠)</span>}
            </span>
            <span className="opacity-60 font-sans font-bold text-[10px] bg-black/30 px-1.5 rounded-sm">STR:{b.strength.toFixed(1)}</span>
          </div>
          <div className="leading-relaxed break-words relative z-10 opacity-90 group-hover:opacity-100 font-light">
            {b.statement}
          </div>
        </div>
      ))}
    </div>
  );
};

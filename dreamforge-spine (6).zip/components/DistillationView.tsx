
import React, { useState, useEffect } from 'react';
import { orchestrator } from '../bridge/orchestrator';
import { reinforcementStore } from '../distillation/reinforcement_store';
import { graveyardStore } from '../distillation/graveyard_store';
import { realtimeBus } from '../bridge/realtime_bus';
import { SurgicalContainer } from './SurgicalContainer';
import { CompetitionRing } from './CompetitionRing';
import { RatchetPanel } from './RatchetPanel';
import { StrategyPanel } from './StrategyPanel';
import { WeightedHeuristic } from '../distillation/types';

export const DistillationView: React.FC = () => {
  const [heuristics, setHeuristics] = useState(reinforcementStore.getAll());
  const [dead, setDead] = useState(graveyardStore.getAll());
  const [distillLog, setDistillLog] = useState<string | null>(null);
  const [tweakMode, setTweakMode] = useState(false);

  useEffect(() => {
      // Listen for updates from the store via Bus
      const cleanup = realtimeBus.on('HEURISTICS_UPDATE', () => {
          refresh();
      });
      return cleanup;
  }, []);

  const refresh = () => {
      setHeuristics(reinforcementStore.getAll());
      setDead(graveyardStore.getAll());
  };

  const triggerDistill = () => {
      setDistillLog("RUNNING DISTILLATION...");
      setTimeout(() => {
          const res = orchestrator.distillSystem();
          setDistillLog(res);
          refresh();
      }, 100);
  };

  // --- MANUAL ACTIONS ---

  const killHeuristic = (rule: string) => {
      const removed = reinforcementStore.remove(rule);
      if (removed) {
          graveyardStore.bury([removed]);
          refresh();
      }
  };

  const reviveHeuristic = (rule: string) => {
      graveyardStore.exhume(rule);
      // When reviving manually, give it a fighting chance (0.5 weight)
      // We need to fetch the corpse details but exhume just deletes it.
      // So we cheat and reconstruct a basic entry, or we should have peeked.
      // Actually graveyardStore.bury stores full metadata.
      // Let's rely on creating a fresh entry for simplicity as exhume is void.
      reinforcementStore.ingest([{
          rule: rule,
          type: 'epistemic', // Defaulting type if lost, acceptable compromise
          priority: 1,
          weight: 0.5,
          sourceCount: 1,
          lastReinforced: Date.now(),
          mutated: true // Mark as mutated since it's a zombie
      }]);
      refresh();
  };

  const nudgeWeight = (rule: string, delta: number) => {
      const h = heuristics.find(item => item.rule === rule);
      if (h) {
          h.weight = Math.max(0.01, h.weight + delta);
          reinforcementStore.update(h); // Will trigger save & broadcast
      }
  };

  return (
    <div className="h-full grid grid-cols-[300px_1fr_300px] bg-black/80 font-mono">
        
        {/* COL 1: HEURISTIC CONTROLS */}
        <div className="border-r border-surgery-border p-4 space-y-4 bg-surgery-dark overflow-y-auto">
            <h3 className="text-surgery-cyan font-bold tracking-widest text-xs mb-4 flex justify-between items-center">
                HEURISTICS_LAB
                <button 
                    onClick={() => setTweakMode(!tweakMode)}
                    className={`text-[9px] px-2 py-0.5 border rounded transition-all ${tweakMode ? 'bg-orange-500 text-black border-orange-500' : 'border-gray-600 text-gray-500 hover:border-gray-400 hover:text-gray-300'}`}
                >
                    {tweakMode ? 'TWEAK_ON' : 'TWEAK_OFF'}
                </button>
            </h3>
            
            <div className="flex justify-center py-4">
                 <CompetitionRing heuristics={heuristics} size={180} />
            </div>

            <button 
                onClick={triggerDistill}
                className="w-full py-3 border border-purple-500/50 text-purple-400 font-bold hover:bg-purple-500 hover:text-white transition-all uppercase tracking-widest text-xs relative overflow-hidden group"
            >
                <span className="relative z-10">FORCE EVOLUTION</span>
                <div className="absolute inset-0 bg-purple-500/20 translate-y-full group-hover:translate-y-0 transition-transform" />
            </button>
            
            {distillLog && (
                <div className="p-2 bg-black border border-gray-800 text-[9px] font-mono text-gray-400 break-words">
                    {distillLog}
                </div>
            )}

            {/* RATCHET PANEL */}
            <div className="pt-4 border-t border-gray-800">
                <RatchetPanel />
            </div>
        </div>

        {/* COL 2: MAIN LISTS (Heuristics & Graves) */}
        <div className="p-8 overflow-y-auto space-y-8 border-r border-surgery-border">
            <SurgicalContainer 
                title="ACTIVE_GENOME (HEURISTICS)" 
                active={tweakMode}
                className={tweakMode ? 'border-orange-500/30' : ''}
            >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4">
                    {heuristics.length === 0 && (
                        <div className="col-span-2 text-center text-gray-500 italic text-xs py-10">
                            No active heuristics. Run cycles to generate candidates.
                        </div>
                    )}
                    {heuristics.sort((a,b) => b.weight - a.weight).map((h, i) => (
                        <div key={i} className={`bg-black/40 border-l-2 p-3 rounded-r-sm transition-all group ${tweakMode ? 'hover:border-orange-500 border-gray-700' : 'border-dream-cyan'}`}>
                            <div className="flex justify-between items-start mb-1 gap-2">
                                <span className={`font-bold text-xs leading-tight ${tweakMode ? 'text-gray-300' : 'text-dream-cyan'}`}>{h.rule}</span>
                                <span className="font-mono text-[10px] bg-gray-800 px-1.5 rounded shrink-0">{h.weight.toFixed(3)}</span>
                            </div>
                            
                            <div className="flex justify-between items-end mt-2">
                                <div className="flex gap-2 text-[9px] text-gray-500 uppercase">
                                    <span>{h.type}</span>
                                    {h.mutated && <span className="text-purple-400">MUTATED</span>}
                                </div>

                                {tweakMode && (
                                    <div className="flex gap-1 animate-in fade-in zoom-in duration-200">
                                        <button onClick={() => nudgeWeight(h.rule, 0.1)} className="px-1.5 bg-green-900/30 text-green-400 hover:bg-green-500 hover:text-black rounded text-[9px] border border-green-500/30 font-bold" title="+0.1 Weight">+</button>
                                        <button onClick={() => nudgeWeight(h.rule, -0.1)} className="px-1.5 bg-yellow-900/30 text-yellow-400 hover:bg-yellow-500 hover:text-black rounded text-[9px] border border-yellow-500/30 font-bold" title="-0.1 Weight">-</button>
                                        <button onClick={() => killHeuristic(h.rule)} className="px-2 bg-red-900/30 text-red-400 hover:bg-red-500 hover:text-black rounded text-[9px] border border-red-500/30 font-bold ml-1">KILL</button>
                                    </div>
                                )}
                            </div>
                        </div>
                    ))}
                </div>
            </SurgicalContainer>

            <SurgicalContainer title="GRAVEYARD (DEAD_HEURISTICS)">
                <div className="p-4 space-y-2">
                    {dead.length === 0 && <div className="text-gray-600 italic text-xs">No dead heuristics yet.</div>}
                    {dead.map((d, i) => (
                        <div key={i} className="flex justify-between items-center p-2 border-b border-white/5 opacity-50 hover:opacity-100 transition-opacity bg-black/20">
                            <span className="text-xs text-gray-400 line-through decoration-red-500/50 w-3/4 truncate" title={d.rule}>{d.rule}</span>
                            
                            {tweakMode ? (
                                <button 
                                    onClick={() => reviveHeuristic(d.rule)}
                                    className="text-[9px] font-bold text-green-500 border border-green-500/30 px-2 py-0.5 hover:bg-green-500 hover:text-black transition-colors rounded-sm uppercase tracking-wider"
                                >
                                    REVIVE
                                </button>
                            ) : (
                                <span className="text-[9px] font-mono text-red-500">DIED: {d.weightAtDeath.toFixed(2)}</span>
                            )}
                        </div>
                    ))}
                </div>
            </SurgicalContainer>
        </div>

        {/* COL 3: STRATEGY ENGINE (Right Panel) */}
        <div className="p-4 bg-[#0a0a0e] overflow-hidden flex flex-col">
             <StrategyPanel />
        </div>
    </div>
  );
};

import React from 'react';
import { WeightedHeuristic } from '../distillation/types';

interface Props {
  heuristics: WeightedHeuristic[];
  className?: string;
}

export const DistillWeights: React.FC<Props> = ({ heuristics, className = '' }) => {
  // Filter only meaningful weights to reduce noise
  // In normalized ring, anything > 1% (0.01) is somewhat relevant
  const active = heuristics
    .filter(h => h.weight > 0.01)
    .sort((a, b) => b.weight - a.weight);

  return (
    <div className={`flex flex-col overflow-hidden bg-black/20 rounded-sm ${className}`}>
        <div className="px-2 py-1 text-[9px] font-mono text-gray-500 uppercase border-b border-white/5 flex justify-between">
            <span>Ring Legend</span>
            <span>{active.length} Active</span>
        </div>
        <div className="flex-1 overflow-y-auto p-2 scrollbar-hide">
            {active.length === 0 ? (
                <div className="text-[9px] text-gray-600 italic">No bias active.</div>
            ) : (
                <div className="font-mono text-[9px] space-y-1">
                    {active.map((h, i) => {
                        // Color code based on share of voice
                        const intensity = Math.min(1, h.weight * 4); 
                        // Logic must match Ring colors for "legend" effect
                        let color = '#378e85'; 
                        if (h.weight >= 0.15) color = '#00ffd5';
                        else if (h.weight >= 0.05) color = '#ffb347';

                        const percent = (h.weight * 100).toFixed(1);

                        return (
                            <div key={i} className="flex gap-2 items-baseline opacity-80 hover:opacity-100 transition-opacity group">
                                <div className="w-1.5 h-1.5 rounded-full shrink-0" style={{ backgroundColor: color }}></div>
                                <span className="text-dream-cyan/60 min-w-[36px] text-right font-bold">
                                    {percent}%
                                </span>
                                <span className="truncate text-gray-300 group-hover:text-white transition-colors">
                                    {h.rule}
                                </span>
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    </div>
  );
};
import React, { useEffect, useRef, useState } from 'react';

interface Props {
  axioms: string[];
  className?: string;
}

export const AxiomPanel: React.FC<Props> = ({ axioms, className = '' }) => {
  const [displayList, setDisplayList] = useState<string[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // When new axioms arrive, animate them in or replace depending on volume
    // We just keep the last 10 for the "stream" feel
    if (axioms.length > 0) {
        setDisplayList(prev => [...prev, ...axioms].slice(-20));
    }
  }, [axioms]);

  useEffect(() => {
    if (scrollRef.current) {
        scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [displayList]);

  return (
    <div className={`flex flex-col border border-dream-dim/40 bg-black/60 backdrop-blur-md rounded-sm overflow-hidden ${className}`}>
        <div className="p-2 border-b border-white/5 flex justify-between items-center bg-black/20">
            <h3 className="text-[10px] font-mono font-bold tracking-widest text-dream-cyan/80">
                LIVE_AXIOM_STREAM
            </h3>
            <div className="w-1.5 h-1.5 rounded-full bg-dream-cyan/50 animate-pulse"></div>
        </div>
        
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-2 space-y-1.5 scrollbar-hide">
            {displayList.length === 0 ? (
                <div className="text-[9px] text-gray-600 italic text-center pt-4">Waiting for logical locks...</div>
            ) : (
                displayList.map((ax, i) => (
                    <div key={i} className="text-[9px] font-mono text-gray-300 border-l-2 border-dream-cyan/30 pl-2 py-0.5 animate-in slide-in-from-left-2 fade-in duration-300">
                        {ax}
                    </div>
                ))
            )}
        </div>
    </div>
  );
};
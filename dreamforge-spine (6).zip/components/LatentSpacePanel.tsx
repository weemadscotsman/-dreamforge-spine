import React, { useEffect, useState } from "react";
import { NormalizedReasoning } from "../core/model_adapter";

type LatentProps = {
  data: NormalizedReasoning | null;
  className?: string;
};

export const LatentSpacePanel: React.FC<LatentProps> = ({ data, className = '' }) => {
  const [nodes, setNodes] = useState<any[]>([]);

  useEffect(() => {
    if (!data) return;

    const core = {
      id: "CLAIM",
      label: data.claim,
      weight: 1.0,
      color: colorForUncertainty(data.uncertainty)
    };

    const premises = data.premises.map((p, i) => ({
      id: `P${i+1}`,
      label: p,
      weight: 0.6,
      color: "#5EC4FF"
    }));

    const reasoning = {
      id: "WHY",
      label: data.reasoning,
      weight: 0.8,
      color: "#D97AFF"
    };

    setNodes([core, reasoning, ...premises]);
  }, [data]);

  return (
    <div className={`latent-space-wrapper border border-dream-dim bg-black/40 backdrop-blur-sm rounded-sm ${className}`}>
        <div className="p-2 border-b border-dream-dim flex justify-between items-center mb-2 bg-black/40">
            <h3 className="text-dream-cyan font-mono font-bold text-[10px] tracking-widest">NORMALIZED_REASONING</h3>
            {data && <span className="text-[8px] text-gray-500 uppercase">{data.backend}</span>}
        </div>
      <div className="p-2 space-y-2 overflow-y-auto max-h-[200px] scrollbar-hide">
          {nodes.map(n => (
            <div
              key={n.id}
              className="latent-node"
              style={{
                borderColor: n.color,
                boxShadow: pulse(n.color),
                fontSize: "0.75rem",
              }}
            >
              <strong style={{ color: n.color, marginRight: '6px' }}>{n.id}</strong>
              <span className="text-gray-300 text-[10px] font-mono leading-tight">{n.label}</span>
            </div>
          ))}
          {nodes.length === 0 && (
              <div className="text-gray-600 text-[10px] italic text-center p-4">Waiting for normalized signal...</div>
          )}
      </div>
    </div>
  );
};

function colorForUncertainty(u: number) {
  if (u < 0.25) return "#00FF96";   // confident (low uncertainty)
  if (u < 0.45) return "#67FF00";   // stable
  if (u < 0.75) return "#FF9900";   // shaky
  return "#FF0033";                 // brittle
}

function pulse(color: string) {
  return `0 0 2px ${color}, inset 0 0 5px ${color}33`;
}
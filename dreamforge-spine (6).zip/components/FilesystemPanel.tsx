
import React, { useState, useEffect } from 'react';
import { vfs } from '../tools/vfs';
import { FileNode } from '../tools/types';

interface ItemProps {
  node: FileNode;
  path: string;
  level?: number;
  onRefresh: () => void;
}

const FileTreeItem: React.FC<ItemProps> = ({ node, path, level = 0, onRefresh }) => {
  const [expanded, setExpanded] = useState(path === '' || path === 'root' || path === 'root/logs');
  const fullPath = path ? `${path}/${node.name}` : node.name;

  const handleDownload = (e: React.MouseEvent) => {
      e.stopPropagation();
      if (node.type !== 'file' || !node.content) return;
      
      const blob = new Blob([node.content], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = node.name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
  };

  const handleDelete = (e: React.MouseEvent) => {
      e.stopPropagation();
      if (confirm(`Delete ${node.name}?`)) {
          vfs.deleteFile(fullPath.replace('root/', ''));
          onRefresh();
      }
  };
  
  return (
    <div className="select-none">
      <div 
        className="flex items-center gap-2 py-1 px-2 hover:bg-white/5 cursor-pointer text-[10px] font-mono group transition-colors"
        style={{ paddingLeft: (level * 12) + 8 }}
        onClick={() => node.type === 'dir' && setExpanded(!expanded)}
      >
        <span className="opacity-70 w-3">{node.type === 'dir' ? (expanded ? '📂' : '📁') : '📄'}</span>
        
        <span className={`${node.type === 'dir' ? 'text-blue-300 font-bold' : 'text-gray-300'} truncate`}>
            {node.name}
        </span>
        
        {node.type === 'file' && (
            <div className="ml-auto flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <span className="text-[8px] text-gray-600">{node.content?.length}b</span>
                
                <button 
                    onClick={handleDownload}
                    className="p-1 hover:bg-green-500/20 text-green-400 rounded"
                    title="Download"
                >
                    ⬇
                </button>
                
                <button 
                    onClick={handleDelete}
                    className="p-1 hover:bg-red-500/20 text-red-400 rounded"
                    title="Delete"
                >
                    ✕
                </button>
            </div>
        )}
      </div>
      
      {node.type === 'dir' && expanded && node.children && (
        <div className="border-l border-white/5 ml-3">
          {node.children.map((child, i) => (
              <FileTreeItem 
                key={i} 
                node={child} 
                path={fullPath} 
                level={level + 1} 
                onRefresh={onRefresh}
              />
          ))}
        </div>
      )}
    </div>
  );
};

export const FilesystemPanel: React.FC = () => {
  const [tree, setTree] = useState<FileNode>(vfs.getTree());
  const [lastUpdate, setLastUpdate] = useState(Date.now());

  const refresh = () => {
      setTree({ ...vfs.getTree() });
      setLastUpdate(Date.now());
  };

  useEffect(() => {
    // Poll for VFS changes but also allow manual refresh triggers
    const i = setInterval(() => refresh(), 2000);
    return () => clearInterval(i);
  }, []);

  return (
    <div className="bg-[#050508] border border-gray-800 h-full flex flex-col shadow-inner">
      <div className="p-2 border-b border-gray-800 flex justify-between items-center bg-black/20">
        <div className="text-[10px] font-bold text-gray-500 tracking-widest flex items-center gap-2">
            <span>💾</span> WORKSPACE_VFS
        </div>
        <button 
            onClick={refresh}
            className="text-[9px] text-surgery-cyan hover:text-white px-2 py-0.5 border border-surgery-cyan/20 rounded hover:bg-surgery-cyan/10 transition-colors"
        >
            REFRESH
        </button>
      </div>
      
      <div className="flex-1 overflow-y-auto py-2 scrollbar-thin scrollbar-thumb-gray-800 scrollbar-track-transparent">
        <FileTreeItem node={tree} path="" onRefresh={refresh} />
      </div>

      <div className="p-2 border-t border-gray-800 text-[8px] text-gray-600 bg-black/40 text-center font-mono">
          Last Sync: {new Date(lastUpdate).toLocaleTimeString()}
      </div>
    </div>
  );
};

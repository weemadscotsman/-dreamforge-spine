
import React, { useEffect, useState } from 'react';
import { realtimeBus } from '../bridge/realtime_bus';
import { selfRatchet, RatchetWeights } from '../engine/distillation/self_ratchet';

export const RatchetPanel: React.FC = () => {
  const [w, setW] = useState<RatchetWeights>(selfRatchet.get());
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    const cleanup = realtimeBus.on("RATCHET_UPDATE", (data: any) => {
        if (!isEditing) { // Only sync if not currently editing to prevent jitter
            setW(data);
        }
    });
    return cleanup;
  }, [isEditing]);

  const handleSliderChange = (key: keyof RatchetWeights, val: string) => {
      const num = parseFloat(val);
      const newWeights = { ...w, [key]: num };
      setW(newWeights);
      // Live update the backend
      selfRatchet.override(newWeights);
  };

  return (
    <div className={`flex flex-col bg-[#050508]/80 border ${isEditing ? 'border-orange-500/40' : 'border-purple-500/20'} rounded-sm overflow-hidden group transition-colors duration-300`}>
      <div className={`p-2 border-b flex justify-between items-center ${isEditing ? 'bg-orange-900/20 border-orange-500/40' : 'bg-purple-900/10 border-purple-500/20'}`}>
        <h3 className={`text-[10px] font-mono font-bold tracking-widest ${isEditing ? 'text-orange-400' : 'text-purple-400'}`}>
            {isEditing ? 'RATCHET_OVERRIDE' : 'SELF_RATCHET_WEIGHTS'}
        </h3>
        <button 
            onClick={() => setIsEditing(!isEditing)}
            className={`text-[9px] px-2 py-0.5 rounded border transition-all uppercase font-bold
                ${isEditing 
                    ? 'bg-orange-500 text-black border-orange-500 hover:bg-orange-400' 
                    : 'bg-transparent text-purple-400 border-purple-500/30 hover:text-white hover:border-white'}`}
        >
            {isEditing ? 'LOCK' : 'UNLOCK'}
        </button>
      </div>
      
      <div className="p-3 grid grid-cols-2 gap-2">
          {Object.entries(w).map(([key, value]) => {
              const rawVal = value as any;
              const val = typeof rawVal === 'number' ? rawVal : parseFloat(rawVal) || 0;
              const k = key as keyof RatchetWeights;
              
              return (
                <div key={key} className={`flex flex-col bg-black/40 p-1.5 rounded-sm border relative overflow-hidden transition-all ${isEditing ? 'border-white/20' : 'border-white/5'}`}>
                    <div className="flex justify-between items-center z-10 mb-1">
                        <span className="text-[8px] font-mono text-gray-500 uppercase">{key.replace('_', ' ')}</span>
                        <span className={`text-[10px] font-bold font-mono ${val > 1.5 ? 'text-green-400' : 'text-gray-300'}`}>
                            {val.toFixed(2)}
                        </span>
                    </div>
                    
                    {isEditing ? (
                        <input 
                            type="range" 
                            min="0.1" 
                            max="5.0" 
                            step="0.1" 
                            value={val}
                            onChange={(e) => handleSliderChange(k, e.target.value)}
                            className="w-full h-1 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-orange-500"
                        />
                    ) : (
                        <div className="w-full h-1 bg-gray-800 mt-1 rounded-full overflow-hidden z-10">
                            <div 
                              className={`h-full transition-all duration-700 ${val > 1.5 ? 'bg-green-500' : 'bg-purple-500'}`} 
                              style={{ width: `${Math.min(100, (val / 3) * 100)}%` }} 
                            />
                        </div>
                    )}
                </div>
              );
          })}
      </div>
    </div>
  );
};

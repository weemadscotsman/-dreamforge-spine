
import React, { useRef, useState, useEffect } from 'react';
import { orchestrator } from '../bridge/orchestrator';
import { realtimeBus } from '../bridge/realtime_bus';
import { SurgicalContainer } from './SurgicalContainer';
import { ModelAttachment } from '../model/types';

interface Props {
    compact?: boolean;
}

export const WebcamModule: React.FC<Props> = ({ compact = false }) => {
    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [stream, setStream] = useState<MediaStream | null>(null);
    const [analyzing, setAnalyzing] = useState(false);
    const [monitoring, setMonitoring] = useState(false);
    const [analysisLog, setAnalysisLog] = useState<{timestamp: number, text: string}[]>([]);
    const [error, setError] = useState<string | null>(null);
    const intervalRef = useRef<any>(null);

    useEffect(() => {
        return () => {
            stopStream();
            if (intervalRef.current) clearInterval(intervalRef.current);
        };
    }, []);

    const startStream = async () => {
        setError(null);
        try {
            const s = await navigator.mediaDevices.getUserMedia({
                video: { width: 1280, height: 720 },
                audio: false
            });
            
            if (videoRef.current) {
                videoRef.current.srcObject = s;
            }
            setStream(s);
        } catch (err: any) {
            console.error("Error starting webcam:", err);
            setError(err.message || "PERMISSION_DENIED");
        }
    };

    const stopStream = () => {
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
            setStream(null);
        }
        if (videoRef.current) {
            videoRef.current.srcObject = null;
        }
        setMonitoring(false);
        if (intervalRef.current) clearInterval(intervalRef.current);
    };

    const captureFrame = (): ModelAttachment | null => {
        if (!videoRef.current || !canvasRef.current) return null;
        const ctx = canvasRef.current.getContext('2d');
        if (!ctx) return null;

        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
        
        ctx.translate(canvasRef.current.width, 0);
        ctx.scale(-1, 1);
        ctx.drawImage(videoRef.current, 0, 0);
        ctx.setTransform(1, 0, 0, 1, 0, 0);

        const dataUrl = canvasRef.current.toDataURL('image/jpeg', 0.8);
        const base64 = dataUrl.split(',')[1];
        
        return {
            mimeType: 'image/jpeg',
            data: base64
        };
    };

    const analyzeSnapshot = async () => {
        const attachment = captureFrame();
        if (!attachment) return;

        setAnalyzing(true);
        try {
            const res = await orchestrator.runInternalTask(
                "[BIO_LINK_ANALYSIS] Analyze the person and environment in this frame. Infer intent, emotional state, and context.",
                [attachment]
            );
            
            const logEntry = { timestamp: Date.now(), text: res.output };
            setAnalysisLog(prev => [logEntry, ...prev]);
            realtimeBus.emit("SYSTEM_LOG", { module: "WEBCAM", level: "INFO", message: "Bio-Link Snapshot Analyzed" });
        } catch (e) {
            console.error(e);
        } finally {
            setAnalyzing(false);
        }
    };

    const toggleMonitoring = () => {
        if (monitoring) {
            setMonitoring(false);
            if (intervalRef.current) clearInterval(intervalRef.current);
        } else {
            setMonitoring(true);
            intervalRef.current = setInterval(async () => {
                const attachment = captureFrame();
                if (!attachment) return;
                
                orchestrator.runInternalTask(
                    "[BIO_LINK_MONITOR] Briefly describe changes in user attention or environment.",
                    [attachment]
                ).then(res => {
                    setAnalysisLog(prev => [{ timestamp: Date.now(), text: `[LIVE] ${res.output}` }, ...prev].slice(0, 50));
                });

            }, 10000);
        }
    };

    return (
        <div className={`flex ${compact ? 'flex-col h-full' : 'flex-row h-full p-4 gap-4'} w-full bg-[#050508] overflow-hidden`}>
            {/* Video Feed */}
            <div className={`flex flex-col gap-2 ${compact ? 'flex-1' : 'flex-1'}`}>
                <div className="relative flex-1 bg-black border border-surgery-cyan/30 flex items-center justify-center overflow-hidden rounded-sm">
                    {!stream && !error && (
                        <button 
                            onClick={startStream}
                            className="px-4 py-2 border border-surgery-cyan text-surgery-cyan hover:bg-surgery-cyan hover:text-black transition-all font-bold tracking-widest text-[10px] uppercase"
                        >
                            CONNECT_BIO_LINK
                        </button>
                    )}

                    {error && (
                        <div className="flex flex-col items-center gap-2 p-4 text-center">
                            <span className="text-red-500 font-bold text-[10px] tracking-widest">ERROR: {error.toUpperCase()}</span>
                            <button 
                                onClick={startStream}
                                className="px-3 py-1 border border-red-500/50 text-red-500 text-[9px] hover:bg-red-500/10"
                            >
                                RETRY_CONNECTION
                            </button>
                        </div>
                    )}
                    
                    <video 
                        ref={videoRef} 
                        autoPlay 
                        playsInline 
                        muted 
                        className={`w-full h-full object-cover transform scale-x-[-1] ${!stream ? 'hidden' : ''}`} 
                    />
                    
                    {/* Face Tracking Overlay Effect */}
                    {stream && (
                        <div className="absolute inset-0 pointer-events-none">
                            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 border border-surgery-cyan/30 rounded-full animate-pulse opacity-50" />
                            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 border-l border-t border-surgery-cyan" />
                            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 border-r border-b border-surgery-cyan" />
                        </div>
                    )}

                    {monitoring && (
                        <div className="absolute top-2 right-2 flex items-center gap-1">
                            <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse shadow-[0_0_10px_red]" />
                            <span className="text-red-500 font-bold text-[8px] tracking-widest bg-black/50 px-1">WATCHING</span>
                        </div>
                    )}
                </div>

                <div className="h-8 shrink-0 flex gap-2">
                    <button 
                        onClick={analyzeSnapshot}
                        disabled={!stream || analyzing}
                        className="flex-1 border border-surgery-border hover:border-surgery-cyan hover:bg-surgery-cyan/10 text-surgery-white transition-all font-mono text-[9px] font-bold tracking-widest disabled:opacity-50"
                    >
                        {analyzing ? "SCANNING..." : "ANALYZE"}
                    </button>
                    <button 
                        onClick={toggleMonitoring}
                        disabled={!stream}
                        className={`flex-1 border transition-all font-mono text-[9px] font-bold tracking-widest disabled:opacity-50 ${monitoring ? 'border-red-500 bg-red-900/20 text-red-400' : 'border-surgery-border hover:border-surgery-cyan text-gray-400'}`}
                    >
                        {monitoring ? "STOP" : "CONT. WATCH"}
                    </button>
                </div>
            </div>

            {/* Analysis Log */}
            {!compact && (
                <div className="w-[350px] flex flex-col gap-4">
                    <SurgicalContainer title="OBSERVATION_LOG" className="h-full">
                        <div className="flex-1 overflow-y-auto p-4 space-y-4 font-mono text-xs scrollbar-thin scrollbar-thumb-surgery-border">
                            {analysisLog.map((log, i) => (
                                <div key={i} className="border-l-2 border-surgery-cyan/50 pl-3 py-1 animate-in fade-in">
                                    <div className="text-[9px] text-gray-500 mb-1">{new Date(log.timestamp).toLocaleTimeString()}</div>
                                    <div className="text-gray-300 leading-relaxed">{log.text}</div>
                                </div>
                            ))}
                        </div>
                    </SurgicalContainer>
                </div>
            )}

            {/* Compact Log Overlay */}
            {compact && analysisLog.length > 0 && (
                <div className="h-[60px] shrink-0 overflow-y-auto border-t border-surgery-border bg-black/50 p-2 font-mono text-[8px] text-gray-400">
                    <div className="text-red-400 mb-1 font-bold">BIO_METRICS:</div>
                    {analysisLog[0].text}
                </div>
            )}

            <canvas ref={canvasRef} className="hidden" />
        </div>
    );
};

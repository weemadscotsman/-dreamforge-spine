
import React, { useMemo } from 'react';
import { WeightedHeuristic } from '../distillation/types';

interface Props {
  heuristics: WeightedHeuristic[];
  className?: string;
}

export const DistillationHUD: React.FC<Props> = ({ heuristics, className = '' }) => {
  const stats = useMemo(() => {
    if (heuristics.length === 0) return { count: 0, avg: "0.00", max: "0.00", dominant: "None", status: "OFFLINE", statusColor: "text-gray-500", top3: [] };
    
    const total = heuristics.reduce((acc, h) => acc + h.weight, 0);
    const avg = total / heuristics.length;
    const sorted = [...heuristics].sort((a,b) => b.weight - a.weight);
    const max = sorted[0].weight;
    
    // Determine System State based on Max Weight (Dominance)
    let status = "FLUID";
    let statusColor = "text-dream-accent"; // Green/Cyan
    
    if (max > 2.0) {
        status = "DOGMATIC";
        statusColor = "text-dream-alert"; // Red
    } else if (max > 0.8) {
        status = "STABLE";
        statusColor = "text-blue-400"; // Blue
    } else if (max < 0.3) {
        status = "CHAOTIC";
        statusColor = "text-yellow-400";
    }

    return {
      count: heuristics.length,
      avg: avg.toFixed(2),
      max: max.toFixed(2),
      dominant: sorted[0].rule,
      status,
      statusColor,
      top3: sorted.slice(0, 3)
    };
  }, [heuristics]);

  return (
    <div className={`p-3 bg-[#0a0a19]/90 border border-[#00ffc8]/30 rounded-sm text-[#00ffd5] flex flex-col gap-2 overflow-hidden relative group shadow-[0_0_10px_rgba(0,0,0,0.3)] ${className}`}>
      
      {/* Header with Status */}
      <div className="flex justify-between items-center border-b border-[#00ffc8]/20 pb-2 z-10">
        <div className="flex flex-col">
            <h4 className="text-[9px] font-bold tracking-[0.1em] text-white/90">GENETIC_STATE</h4>
            <span className={`text-[9px] font-black tracking-widest ${stats.statusColor} animate-pulse`}>
                {stats.status}
            </span>
        </div>
        <div className="text-[10px] font-mono text-gray-400">
            N={stats.count}
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 gap-2 z-10">
        <MetricRow label="AVG_WEIGHT" value={stats.avg} />
        <MetricRow label="MAX_DOMINANCE" value={stats.max} highlight />
      </div>

      {/* Top Strategies Tiny List */}
      <div className="flex flex-col gap-1 mt-1 z-10">
          <span className="text-[7px] font-mono text-gray-500 uppercase">Top Strategies</span>
          {stats.top3.map((h, i) => (
              <div key={i} className="flex justify-between items-center text-[9px] font-mono border-b border-white/5 pb-0.5">
                  <span className="truncate w-3/4 opacity-80" title={h.rule}>{h.rule}</span>
                  <span className={`font-bold ${i === 0 ? 'text-white' : 'text-gray-400'}`}>{h.weight.toFixed(2)}</span>
              </div>
          ))}
      </div>
      
      {/* Background Decor */}
      <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-bl from-[#00ffc8]/10 to-transparent pointer-events-none rounded-full blur-xl -mr-10 -mt-10" />
    </div>
  );
};

const MetricRow = ({ label, value, highlight = false }: { label: string, value: string | number, highlight?: boolean }) => (
  <div className="flex flex-col bg-black/20 p-1 rounded-sm border border-white/5">
    <span className="text-[7px] font-mono text-gray-500">{label}</span>
    <span className={`font-mono text-[10px] leading-none ${highlight ? 'text-white font-bold' : 'text-gray-300'}`}>
      {value}
    </span>
  </div>
);

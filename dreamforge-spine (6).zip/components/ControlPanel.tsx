
import React, { useState, useEffect } from 'react';
import { orchestrator } from '../bridge/orchestrator';
import { autoRun, stopAutoLoop } from '../autonomous/auto_loop';
import { startDreamMode, stopDreamMode, isDreaming } from '../engine/autorun/autorun';
import { ledger } from '../engine/beliefs/hypothesis_ledger';
import { realtimeBus } from '../bridge/realtime_bus';
import { FightMode } from '../core/types';

interface ControlPanelProps {
    onOpenSettings?: () => void;
}

type OpMode = 'MANUAL' | 'DREAM' | 'AUTO';

export const ControlPanel: React.FC<ControlPanelProps> = ({ onOpenSettings }) => {
  const [opMode, setOpMode] = useState<OpMode>('MANUAL');
  const [distilling, setDistilling] = useState(false);
  const [opticActive, setOpticActive] = useState(false); // [NEW] Track optic state
  const [currentMode, setCurrentMode] = useState<FightMode>('SWARM_4_WAY');

  useEffect(() => {
      // Sync initial state
      if (isDreaming()) setOpMode('DREAM');
      
      const cleanupAuto = realtimeBus.on("AUTO_STATUS", (payload: any) => {
          if (payload.state === 'STARTED') setOpMode('AUTO');
          if (payload.state === 'STOPPED' || payload.state === 'STOPPING') {
              // Revert to Manual or Dream depending on preference, default Manual for safety
              setOpMode('MANUAL');
          }
      });

      const cleanupDream = realtimeBus.on("DREAM_STATUS", (payload: any) => {
          if (payload.active && opMode !== 'AUTO') setOpMode('DREAM');
          if (!payload.active && opMode === 'DREAM') setOpMode('MANUAL');
      });

      // [NEW] Listen for Optic Status
      const cleanupOptic = realtimeBus.on("VISION_STATUS", (payload: any) => {
          setOpticActive(!!payload.active);
      });

      setCurrentMode(orchestrator.getConfig().fightMode || 'SWARM_4_WAY');
      
      return () => {
          cleanupAuto();
          cleanupDream();
          cleanupOptic();
      };
  }, [opMode]);

  const handleModeSelect = (target: OpMode) => {
      // 1. Teardown current state
      if (opMode === 'AUTO') stopAutoLoop();
      if (opMode === 'DREAM') stopDreamMode();

      // 2. Engage new state
      if (target === 'AUTO') {
          realtimeBus.emit("STRATEGY_LOG", { level: "INFO", message: "OP_MODE: AUTO_LOOP ENGAGED" });
          autoRun(50);
      } else if (target === 'DREAM') {
          realtimeBus.emit("STRATEGY_LOG", { level: "INFO", message: "OP_MODE: DREAM_STATE ENGAGED" });
          startDreamMode();
      } else {
          realtimeBus.emit("STRATEGY_LOG", { level: "INFO", message: "OP_MODE: MANUAL OVERRIDE" });
      }
      
      setOpMode(target);
  };

  const forceDistill = () => {
      setDistilling(true);
      realtimeBus.emit("STRATEGY_LOG", { level: "INFO", message: "User Action: Force Distill" });
      setTimeout(() => {
          orchestrator.distillSystem();
          setDistilling(false);
      }, 500);
  };

  const fragment = () => {
      realtimeBus.emit("STRATEGY_LOG", { level: "WARN", message: "User Action: Entropy Fragment (Shatter)" });
      ledger.fragment();
      realtimeBus.emit("SPINE_EVENT", { type: "PRESSURE_CURVE", slope: 0 }); 
  };

  const triggerOptic = () => {
      realtimeBus.emit("TRIGGER_OPTIC_SELECTION", {});
  };

  const handleFightModeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
      const mode = e.target.value as FightMode;
      setCurrentMode(mode);
      orchestrator.setConfig({ fightMode: mode });
      realtimeBus.emit("STRATEGY_LOG", { level: "INFO", message: `Fight Mode Switched: ${mode}` });
  };

  return (
    <div className="flex flex-col gap-3 font-mono">
        {/* OPERATIONAL MODE TOGGLE */}
        <div className="flex flex-col gap-1">
            <div className="text-[9px] font-bold text-gray-500 tracking-widest uppercase mb-1">OPERATIONAL_STATE</div>
            <div className="flex w-full bg-black border border-surgery-border rounded-sm overflow-hidden h-10">
                <ModeBtn 
                    label="USER" 
                    active={opMode === 'MANUAL'} 
                    onClick={() => handleModeSelect('MANUAL')}
                    color="cyan"
                />
                <div className="w-px bg-surgery-border/50"></div>
                <ModeBtn 
                    label="DREAM" 
                    active={opMode === 'DREAM'} 
                    onClick={() => handleModeSelect('DREAM')}
                    color="purple"
                />
                <div className="w-px bg-surgery-border/50"></div>
                <ModeBtn 
                    label="AUTO" 
                    active={opMode === 'AUTO'} 
                    onClick={() => handleModeSelect('AUTO')}
                    color="red"
                />
            </div>
        </div>

        {/* SYSTEM ACTIONS */}
        <div className="grid grid-cols-4 gap-2">
            <ControlBtn 
                label="EVOLVE" 
                active={distilling}
                color="green"
                onClick={forceDistill}
                icon="⚗️"
            />
            <ControlBtn 
                label="OPTIC" 
                active={opticActive}
                color="blue"
                onClick={triggerOptic}
                icon="👁️"
            />
            <ControlBtn 
                label="SHATTER" 
                color="orange"
                onClick={fragment}
                icon="💥"
            />
            <ControlBtn 
                label="CONFIG" 
                color="gray"
                onClick={() => onOpenSettings?.()}
                icon="⚙️"
            />
        </div>

        {/* TOPOLOGY CONFIG */}
        <div className="flex flex-col gap-1 border-t border-surgery-border/30 pt-2">
            <label className="text-[9px] font-bold text-dream-accent tracking-widest uppercase flex justify-between">
                <span>LANE_TOPOLOGY</span>
                <span className="opacity-50">{currentMode.split('_')[0]}</span>
            </label>
            <select 
                value={currentMode} 
                onChange={handleFightModeChange}
                className="w-full bg-[#050508] border border-dream-accent/30 text-dream-accent text-[9px] p-1.5 focus:border-dream-accent outline-none rounded-sm uppercase font-bold hover:bg-dream-accent/5 transition-colors cursor-pointer"
            >
                <option value="DUEL_1V1">DUEL (1v1)</option>
                <option value="TAG_TEAM_2V2">TAG TEAM (2v2)</option>
                <option value="BOSS_RUSH_3V1">BOSS RUSH (3v1)</option>
                <option value="SWARM_4_WAY">SWARM (4-WAY)</option>
            </select>
        </div>
    </div>
  );
};

const ModeBtn: React.FC<{ label: string, active: boolean, onClick: () => void, color: 'cyan' | 'purple' | 'red' }> = ({ label, active, onClick, color }) => {
    const activeStyles = {
        cyan: 'bg-surgery-cyan text-black shadow-[inset_0_0_10px_rgba(0,0,0,0.2)]',
        purple: 'bg-dream-magenta text-black shadow-[inset_0_0_10px_rgba(0,0,0,0.2)]',
        red: 'bg-red-500 text-black shadow-[inset_0_0_10px_rgba(0,0,0,0.2)]'
    };

    const inactiveStyles = {
        cyan: 'text-gray-500 hover:text-surgery-cyan hover:bg-surgery-cyan/10',
        purple: 'text-gray-500 hover:text-dream-magenta hover:bg-dream-magenta/10',
        red: 'text-gray-500 hover:text-red-500 hover:bg-red-500/10'
    };

    return (
        <button 
            onClick={onClick}
            className={`flex-1 flex items-center justify-center text-[10px] font-bold tracking-wider transition-all duration-200 uppercase ${active ? activeStyles[color] : inactiveStyles[color]}`}
        >
            {active && <span className="animate-pulse mr-1">●</span>}
            {label}
        </button>
    );
};

const ControlBtn: React.FC<{ label: string, active?: boolean, color: string, onClick: () => void, icon?: string }> = ({ label, active, color, onClick, icon }) => {
    const colors: Record<string, string> = {
        green: 'border-green-500/50 text-green-400 hover:bg-green-500/10',
        orange: 'border-orange-500/50 text-orange-400 hover:bg-orange-500/10',
        blue: 'border-blue-500/50 text-blue-400 hover:bg-blue-500/10',
        gray: 'border-gray-500/50 text-gray-400 hover:bg-white/5 hover:text-white'
    };

    return (
        <button 
            onClick={onClick}
            className={`
                relative h-10 border rounded-sm flex flex-row gap-2 items-center justify-center transition-all duration-200 group overflow-hidden
                ${colors[color] || colors.gray}
                ${active ? 'ring-1 ring-white/50 scale-[0.98] bg-white/5' : 'hover:-translate-y-0.5'}
            `}
        >
            <div className={`absolute inset-0 bg-gradient-to-br from-white/5 to-transparent transition-opacity ${active ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`} />
            <span className={`text-xs relative z-10 ${active ? 'animate-pulse' : ''}`}>{icon}</span>
            <span className="text-[9px] font-bold tracking-widest relative z-10">{label}</span>
        </button>
    );
};

import React, { useMemo } from 'react';
import { WeightedHeuristic } from '../distillation/types';

interface Props {
  heuristics: WeightedHeuristic[];
  className?: string;
  size?: number;
}

export const CompetitionRing: React.FC<Props> = ({ heuristics, className = '', size = 200 }) => {
  const data = useMemo(() => {
    // 1. Filter & Sort
    const active = heuristics
      .filter(h => h.weight > 0.01) // Filter noise
      .sort((a, b) => b.weight - a.weight);

    // 2. Normalize (Ring is always 100%, even if weights drift slightly due to floating point)
    const totalWeight = active.reduce((acc, h) => acc + h.weight, 0);
    const safeTotal = totalWeight || 1;

    let accumulatedAngle = 0;
    const center = size / 2;
    const radius = size * 0.35; // 35% of container
    const strokeWidth = size * 0.12;

    return active.map((h, i) => {
      const percentage = h.weight / safeTotal;
      const angle = percentage * 360;
      
      const startAngle = accumulatedAngle;
      const endAngle = accumulatedAngle + angle;
      accumulatedAngle += angle;

      // Color Logic (Matching HeuristicPanel)
      let color = '#378e85'; // Low (Default)
      if (h.weight >= 0.15) color = '#00ffd5'; // High (Cyan)
      else if (h.weight >= 0.05) color = '#ffb347'; // Mid (Amber)
      
      // SVG Arc Calculation
      const startRad = (startAngle - 90) * (Math.PI / 180);
      const endRad = (endAngle - 90) * (Math.PI / 180);

      const x1 = center + radius * Math.cos(startRad);
      const y1 = center + radius * Math.sin(startRad);
      const x2 = center + radius * Math.cos(endRad);
      const y2 = center + radius * Math.sin(endRad);

      const largeArc = angle > 180 ? 1 : 0;

      const d = [
        `M ${x1} ${y1}`,
        `A ${radius} ${radius} 0 ${largeArc} 1 ${x2} ${y2}`
      ].join(' ');

      return {
        id: h.rule,
        d,
        color,
        percentage: (percentage * 100).toFixed(1),
        rule: h.rule,
        strokeWidth
      };
    });
  }, [heuristics, size]);

  const dominant = data.length > 0 ? data[0] : null;

  return (
    <div className={`relative flex flex-col items-center justify-center bg-[#08080c]/60 backdrop-blur-md border border-purple-500/20 rounded-md overflow-hidden ${className}`}>
      
      {/* Header */}
      <div className="absolute top-0 left-0 w-full p-2 border-b border-white/5 bg-black/20 flex justify-between items-center z-10">
        <h3 className="text-dream-cyan font-mono font-bold text-[10px] tracking-widest">COMPETITION_RING</h3>
        <span className="text-[8px] text-gray-500 font-mono">ZERO_SUM_ATTENTION</span>
      </div>

      <div className="relative flex-1 w-full h-full flex items-center justify-center p-4 mt-6">
        {data.length === 0 ? (
           <div className="text-center text-[10px] text-gray-600 italic">
             No strategies active.<br/>Evolution pending.
           </div>
        ) : (
           <svg width="100%" height="100%" viewBox={`0 0 ${size} ${size}`} className="overflow-visible animate-in fade-in duration-700">
              {/* Background Ring */}
              <circle cx={size/2} cy={size/2} r={size * 0.35} stroke="#1a1a20" strokeWidth={size * 0.12} fill="none" />
              
              {/* Data Arcs */}
              {data.map((slice, i) => (
                <g key={i} className="group transition-all duration-300">
                  <path 
                    d={slice.d} 
                    stroke={slice.color} 
                    strokeWidth={slice.strokeWidth} 
                    fill="none" 
                    className="transition-all duration-500 hover:stroke-white hover:stroke-[width+2] cursor-pointer"
                  />
                  <title>{slice.rule} ({slice.percentage}%)</title>
                </g>
              ))}

              {/* Center Info */}
              <g className="pointer-events-none">
                 <text x="50%" y="45%" textAnchor="middle" fill="#666" fontSize={size * 0.05} fontFamily="monospace" className="uppercase">Dominance</text>
                 <text x="50%" y="60%" textAnchor="middle" fill={dominant?.color || "#fff"} fontSize={size * 0.12} fontFamily="monospace" fontWeight="bold">
                    {dominant ? `${dominant.percentage}%` : '0%'}
                 </text>
              </g>
           </svg>
        )}
      </div>

      {/* Footer Info */}
      <div className="w-full px-3 py-2 bg-black/20 border-t border-white/5 text-[9px] font-mono text-gray-500 truncate text-center">
         {dominant ? `LEADER: ${dominant.rule}` : 'AWAITING_INPUT'}
      </div>
    </div>
  );
};
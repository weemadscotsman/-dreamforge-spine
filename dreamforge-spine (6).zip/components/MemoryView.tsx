
import React, { useState, useEffect, useRef } from 'react';
import { orchestrator } from '../bridge/orchestrator';
import { MemoryRecord } from '../memory/types';
import { SurgicalContainer } from './SurgicalContainer';
import ResurrectionPanel from './ResurrectionPanel';
import { realtimeBus } from '../bridge/realtime_bus';

export const MemoryView: React.FC = () => {
  const [records, setRecords] = useState<MemoryRecord[]>([]);
  const [filter, setFilter] = useState('');
  const [selected, setSelected] = useState<MemoryRecord | null>(null);
  const [uploadStatus, setUploadStatus] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    refresh();
    
    // Auto-refresh when new memory is ingested
    const cleanup = realtimeBus.on('MEMORY_INGEST', () => {
        refresh();
    });
    return cleanup;
  }, []);

  const refresh = () => {
      setRecords(orchestrator.getMemoryDump().reverse()); // Newest first
  };

  const handleIngest = async (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files[0]) {
          const file = e.target.files[0];
          setUploadStatus("INGESTING...");
          
          try {
              const res = await orchestrator.ingestFileToMemory(file);
              setUploadStatus(res);
              // Clear after delay
              setTimeout(() => setUploadStatus(null), 3000);
          } catch (err: any) {
              setUploadStatus(`ERROR: ${err.message}`);
          }
          
          // Clear input
          e.target.value = '';
      }
  };

  const filtered = records.filter(r => 
      r.output.toLowerCase().includes(filter.toLowerCase()) || 
      r.signature.includes(filter)
  );

  return (
    <div className="flex h-full bg-black/80 overflow-hidden">
      {/* List Column */}
      <div className="w-1/3 border-r border-surgery-border flex flex-col min-w-[250px]">
        <div className="p-4 border-b border-surgery-border bg-surgery-dark flex flex-col gap-3">
            <div className="flex justify-between items-center">
                <h3 className="text-surgery-cyan font-bold tracking-widest text-xs">CORTEX_BROWSER</h3>
                <span className="text-[9px] text-gray-500 font-mono">{records.length} RECORDS</span>
            </div>
            
            {/* PERMANENT INGESTION CONTROL */}
            <div className="border border-surgery-cyan/30 p-2 bg-surgery-cyan/5 rounded-sm">
                <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full py-2 bg-surgery-cyan/10 hover:bg-surgery-cyan/20 border border-surgery-cyan/50 text-surgery-cyan text-[10px] font-bold tracking-widest uppercase transition-all mb-1"
                >
                    + INGEST PERMANENT MEMORY
                </button>
                <input 
                    type="file" 
                    ref={fileInputRef} 
                    className="hidden" 
                    onChange={handleIngest}
                    accept=".pdf,.txt,.md,.json,.js,.ts" 
                />
                {uploadStatus && (
                    <div className="text-[8px] font-mono text-gray-400 text-center animate-pulse">
                        {uploadStatus}
                    </div>
                )}
            </div>

            <input 
                type="text" 
                placeholder="Search vectors..." 
                className="w-full bg-black border border-surgery-border p-2 text-xs text-white focus:border-surgery-cyan outline-none rounded-sm"
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
            />
        </div>
        <div className="flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-surgery-border">
            {filtered.map((r, i) => (
                <div 
                    key={i} 
                    onClick={() => setSelected(r)}
                    className={`p-3 border-b border-surgery-border/50 cursor-pointer hover:bg-white/5 transition-colors ${selected === r ? 'bg-surgery-cyan/10 border-l-2 border-l-surgery-cyan' : ''}`}
                >
                    <div className="flex justify-between items-center mb-1">
                        <span className="text-[9px] font-mono text-gray-500">{new Date(r.timestamp || 0).toLocaleTimeString()}</span>
                        <span className="text-[9px] font-mono bg-gray-800 px-1 rounded text-gray-300">{(r.score * 100).toFixed(0)}%</span>
                    </div>
                    <div className="text-xs text-gray-300 line-clamp-2 font-mono">
                        {r.output}
                    </div>
                </div>
            ))}
        </div>
      </div>

      {/* Detail Column */}
      <div className="flex-1 p-8 overflow-y-auto bg-[#0a0a0c] flex flex-col gap-6 scrollbar-thin scrollbar-thumb-surgery-border">
          {selected ? (
              <div className="space-y-6 max-w-3xl mx-auto w-full">
                  <div className="flex items-center gap-4 border-b border-surgery-border pb-4">
                      <div className="text-4xl text-surgery-cyan font-black">
                          {(selected.score * 100).toFixed(0)}
                      </div>
                      <div className="flex flex-col">
                          <span className="text-xs text-gray-500 font-mono">CONFIDENCE_SCORE</span>
                          <span className="text-xs text-gray-500 font-mono">SIG: {selected.signature}</span>
                      </div>
                  </div>
                  
                  <SurgicalContainer title="CONTENT_PAYLOAD">
                      <div className="p-4 font-mono text-sm leading-relaxed whitespace-pre-wrap text-gray-300">
                          {selected.output}
                      </div>
                  </SurgicalContainer>

                  <SurgicalContainer title="METADATA_PACKET">
                      <pre className="p-4 text-[10px] text-green-400 bg-black overflow-x-auto">
                          {JSON.stringify(selected.meta, null, 2)}
                      </pre>
                  </SurgicalContainer>
              </div>
          ) : (
              <div className="h-full flex items-center justify-center text-gray-600 font-mono text-xs italic">
                  Select a memory node to inspect axiom structure.
              </div>
          )}

          {/* LESION MAP (Always Visible at bottom) */}
          <div className="border-t border-surgery-border pt-4 mt-auto h-[200px] shrink-0">
              <ResurrectionPanel />
          </div>
      </div>
    </div>
  );
};

import React, { useState, useEffect, useRef } from 'react';

interface Props {
  content: string;
  className?: string;
  speed?: number; // ms per char
  onComplete?: () => void;
}

const CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-=[]{}|;:,.<>?";

export const TypewriterBlock: React.FC<Props> = ({ content, className = '', speed = 5, onComplete }) => {
  const [displayed, setDisplayed] = useState("");
  const [isDone, setIsDone] = useState(false);
  const intervalRef = useRef<number | null>(null);

  useEffect(() => {
    // Reset if content changes drastically
    setDisplayed("");
    setIsDone(false);
    
    let index = 0;
    
    // If content is huge, just render it immediately to avoid lag
    if (content.length > 5000) {
        setDisplayed(content);
        setIsDone(true);
        if (onComplete) onComplete();
        return;
    }

    intervalRef.current = window.setInterval(() => {
      if (index >= content.length) {
        if (intervalRef.current) clearInterval(intervalRef.current);
        setIsDone(true);
        if (onComplete) onComplete();
        return;
      }

      // Add a few characters at a time for speed
      const chunk = Math.floor(Math.random() * 3) + 1;
      const nextIndex = Math.min(index + chunk, content.length);
      
      // Decrypt effect: The "tip" of the string is scrambled
      const slice = content.slice(0, nextIndex);
      let scrambled = "";
      
      // Only scramble the last 3 chars
      if (!isDone) {
          for (let i = 0; i < 3; i++) {
              scrambled += CHARS[Math.floor(Math.random() * CHARS.length)];
          }
      }

      setDisplayed(slice + (nextIndex < content.length ? scrambled : ""));
      index = nextIndex;
    }, speed);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [content, speed]);

  return (
    <div className={className}>
      {displayed}
      {!isDone && <span className="inline-block w-2 h-4 bg-dream-cyan ml-1 animate-pulse" />}
    </div>
  );
};
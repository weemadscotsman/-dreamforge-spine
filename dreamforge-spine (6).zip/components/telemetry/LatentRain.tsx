import React, { useEffect, useState } from "react";
import { realtimeBus } from "../../bridge/realtime_bus";

interface Drop {
  id: string;
  latent: string;
  phase: string;
  left: string;
}

export default function LatentRain() {
  const [drops, setDrops] = useState<Drop[]>([]);

  useEffect(() => {
    const cleanup = realtimeBus.on("LATENT_UPDATE", (data: any) => {
      const id = crypto.randomUUID();
      // Randomize horizontal position
      const left = Math.floor(Math.random() * 95) + "vw";
      
      setDrops((prev) => [...prev, { id, ...data, left }].slice(-50)); // Keep DOM light
    });
    return cleanup;
  }, []);

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none select-none z-0">
      {drops.map((d) => (
        <div
          key={d.id}
          className={`
            absolute text-[10px] font-mono whitespace-nowrap animate-[fall_4s_linear_forwards]
            ${d.phase === "CANDIDATE" ? "text-dream-accent/40" : "text-dream-alert/40"}
          `}
          style={{
            top: -20,
            left: d.left,
            textShadow: d.phase === "CANDIDATE" ? "0 0 5px rgba(0,255,157,0.5)" : "0 0 5px rgba(255,50,50,0.5)"
          }}
        >
          {d.latent}
        </div>
      ))}
      <style>{`
        @keyframes fall {
          from { transform: translateY(-10vh); opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          to { transform: translateY(110vh); opacity: 0; }
        }
      `}</style>
    </div>
  );
}
import React from "react";
import { ProofSketch } from "../proof_sketch";

interface Props {
  trace: ProofSketch | null;
  visible: boolean;
  onToggle: () => void;
  embedded?: boolean;
}

export const ProofTracePanel: React.FC<Props> = ({ trace, visible, onToggle, embedded = false }) => {
  const containerClass = embedded 
    ? "h-full w-full flex flex-col bg-black/20 overflow-hidden" 
    : `proof-trace ${visible ? "open" : "closed"}`;

  return (
    <div className={containerClass}>
      {!embedded && (
        <button className="proof-trace-toggle" onClick={onToggle}>
          {visible ? "◣ PROOF TRACE" : "◢ PROOF TRACE"}
        </button>
      )}

      {embedded && <div className="p-2 border-b border-dream-dim text-xs font-bold text-dream-accent bg-black/40 shrink-0">PROOF SKETCH</div>}

      {(visible || embedded) && trace ? (
        <div className={embedded ? "flex-1 overflow-y-auto p-4 space-y-4" : "proof-trace-body"}>
          <div className="proof-item goal">
            <strong>Goal</strong>
            <div>{trace.goal}</div>
          </div>

          <div className="proof-item strategy">
            <strong>Strategy</strong>
            <div>{trace.strategy}</div>
          </div>

          <div className="proof-item premises">
            <strong>Required Premises</strong>
            <ul>{trace.requiredPremises.map((p, i) => <li key={i}>{p}</li>)}</ul>
          </div>

          <div className="proof-item missing">
            <strong>Missing Links</strong>
            <ul>
              {trace.missingLinks.length > 0
                ? trace.missingLinks.map((m, i) => <li key={i}>{m}</li>)
                : <li>(None detected)</li>}
            </ul>
          </div>

          <div className="proof-item targets">
            <strong>Next Inference Targets</strong>
            <ul>{trace.nextInferenceTargets.map((t, i) => <li key={i}>{t}</li>)}</ul>
          </div>

          <div className="proof-item hint">
            <strong>Path Hint</strong>
            <div>{trace.pathHint}</div>
          </div>
        </div>
      ) : (
         (visible || embedded) && <div className="p-4 text-xs text-gray-500 italic">No proof trace available.<br/>Run a cycle to generate.</div>
      )}
    </div>
  );
};
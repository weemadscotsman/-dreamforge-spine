
import React, { useMemo, useState, useEffect } from 'react';
import { ModuleCard } from './ModuleCard';
import { LiveLogFeed } from './LiveLogFeed';
import { FilesystemPanel } from './FilesystemPanel'; 
import { SystemEvent } from '../bridge/types';

interface Props {
  events: SystemEvent[];
}

const MODULES = ['MODEL', 'EVALUATOR', 'CONSTRAINT', 'MEMORY', 'RECURSOR', 'EXPORTER', 'INGEST', 'BRIDGE', 'STRATEGY'];

export const ModulesView: React.FC<Props> = ({ events }) => {
  const [selected, setSelected] = useState<string | null>(null);
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
      const timer = setInterval(() => setNow(Date.now()), 1000);
      return () => clearInterval(timer);
  }, []);

  const stats = useMemo(() => {
      const s: Record<string, { count: number, lastActive: number, status: 'IDLE' | 'ACTIVE' | 'ERROR' }> = {};
      MODULES.forEach(m => s[m] = { count: 0, lastActive: 0, status: 'IDLE' });

      events.forEach(e => {
          if (s[e.source]) {
              s[e.source].count++;
              if (e.timestamp > s[e.source].lastActive) {
                  s[e.source].lastActive = e.timestamp;
              }
              if (e.payload.level === 'ERROR') {
                  s[e.source].status = 'ERROR';
              }
          }
      });

      MODULES.forEach(m => {
          if (s[m].status !== 'ERROR') {
              if (now - s[m].lastActive < 2000) {
                  s[m].status = 'ACTIVE';
              } else {
                  s[m].status = 'IDLE';
              }
          }
      });

      return s;
  }, [events, now]);

  const filteredEvents = useMemo(() => {
      if (!selected) return [];
      return events.filter(e => e.source === selected);
  }, [events, selected]);

  return (
    <div className="flex h-full bg-[#050508] overflow-hidden relative">
        {/* Background Grid */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(20,20,25,0.5)_1px,transparent_1px),linear-gradient(90deg,rgba(20,20,25,0.5)_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none" />

        <div className="flex-1 p-4 md:p-8 overflow-y-auto z-10 scrollbar-thin scrollbar-thumb-gray-800 scrollbar-track-transparent">
            <div className="max-w-7xl mx-auto flex flex-col lg:flex-row gap-6">
                
                {/* Modules Grid */}
                <div className="flex-1">
                    <div className="flex items-center gap-4 mb-8 border-b border-gray-800 pb-4">
                        <h2 className="text-xl md:text-2xl font-mono font-black text-white tracking-[0.2em]">SYSTEM_MODULES</h2>
                        <span className="px-2 py-1 bg-surgery-cyan/10 border border-surgery-cyan/30 text-surgery-cyan text-[10px] font-bold rounded tracking-widest animate-pulse">
                            ONLINE
                        </span>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {MODULES.map(m => (
                            <ModuleCard 
                                key={m}
                                name={m}
                                status={stats[m]?.status || 'IDLE'}
                                description={stats[m]?.lastActive ? `LAST_ACT: ${new Date(stats[m].lastActive).toLocaleTimeString()}` : 'NO_ACTIVITY'}
                                metrics={{ Events: stats[m]?.count || 0 }}
                                isSelected={selected === m}
                                onClick={() => setSelected(selected === m ? null : m)}
                                icon={<span className="text-xl">{getIcon(m)}</span>}
                            />
                        ))}
                    </div>
                </div>

                {/* Right Column: VFS */}
                <div className="w-full lg:w-[300px] shrink-0 h-[400px] lg:h-[600px] border border-gray-800 bg-black/50 backdrop-blur-md shadow-xl rounded-sm">
                    <FilesystemPanel />
                </div>

            </div>
        </div>
        
        {selected && (
            <div className="absolute top-0 right-0 w-full md:w-[400px] h-full border-l border-surgery-border bg-[#0a0a0c]/95 backdrop-blur-xl flex flex-col shadow-[-10px_0_30px_rgba(0,0,0,0.5)] z-20 transition-all duration-300 ease-out">
                <div className="p-4 border-b border-surgery-border bg-surgery-dark flex justify-between items-center">
                    <div className="flex flex-col">
                        <h3 className="text-surgery-cyan font-bold tracking-[0.2em] text-xs">{selected}_LOGS</h3>
                        <span className="text-[9px] text-gray-500 font-mono">STREAMING_EVENTS</span>
                    </div>
                    <button 
                        onClick={() => setSelected(null)} 
                        className="text-gray-500 hover:text-white px-2 py-1 hover:bg-white/10 rounded transition-colors"
                    >
                        ✕
                    </button>
                </div>
                <div className="flex-1 overflow-hidden relative p-0 bg-black/50">
                     <LiveLogFeed events={filteredEvents} className="h-full w-full" />
                </div>
            </div>
        )}
    </div>
  );
};

function getIcon(module: string) {
    switch(module) {
        case 'MODEL': return '⚡';
        case 'EVALUATOR': return '⚖️';
        case 'CONSTRAINT': return '🛡️';
        case 'MEMORY': return '💾';
        case 'RECURSOR': return '🔄';
        case 'EXPORTER': return '📦';
        case 'INGEST': return '📥';
        case 'BRIDGE': return '🌐';
        case 'STRATEGY': return '♟️';
        default: return '❖';
    }
}

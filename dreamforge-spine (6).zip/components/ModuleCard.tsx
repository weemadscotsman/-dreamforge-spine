
import React from 'react';

interface ModuleCardProps {
  name: string;
  icon?: React.ReactNode;
  status: 'IDLE' | 'ACTIVE' | 'ERROR';
  description?: string;
  metrics?: Record<string, string | number>;
  onClick?: () => void;
  isSelected?: boolean;
  className?: string;
}

export const ModuleCard: React.FC<ModuleCardProps> = ({ 
  name, 
  icon, 
  status, 
  description, 
  metrics,
  onClick,
  isSelected,
  className = ''
}) => {
  // Visual State mapping using surgery palette
  const stateConfig = {
    IDLE: {
      bg: 'bg-surgery-panel/80',
      border: 'border-surgery-border',
      text: 'text-surgery-text',
      iconOp: 'opacity-30 grayscale',
      glow: 'hover:border-gray-600'
    },
    ACTIVE: {
      bg: 'bg-surgery-cyan/10',
      border: 'border-surgery-cyan/60',
      text: 'text-surgery-cyan',
      iconOp: 'opacity-100 drop-shadow-[0_0_8px_rgba(0,240,255,0.6)]',
      glow: 'shadow-[0_0_20px_rgba(0,240,255,0.15)] ring-1 ring-surgery-cyan/20'
    },
    ERROR: {
      bg: 'bg-surgery-red/10',
      border: 'border-surgery-red/80',
      text: 'text-surgery-red',
      iconOp: 'opacity-100 animate-pulse sepia',
      glow: 'shadow-[0_0_20px_rgba(255,42,42,0.2)] ring-1 ring-surgery-red/20'
    }
  };

  const style = stateConfig[status];
  const activeClass = isSelected ? 'ring-2 ring-white bg-white/5 scale-[1.02] z-10' : '';

  return (
    <div 
      onClick={onClick}
      className={`
        relative h-[140px] w-full
        rounded-sm border backdrop-blur-md transition-all duration-300 cursor-pointer group
        flex flex-col justify-between overflow-hidden
        ${style.bg} ${style.border} ${style.glow} ${activeClass}
        ${className}
      `}
    >
      {/* 1. HEADER */}
      <div className="flex justify-between items-start p-3 border-b border-white/5 bg-black/20">
        <div className="flex flex-col gap-0.5">
            <span className={`font-mono text-xs font-black tracking-[0.2em] uppercase ${style.text}`}>
            {name}
            </span>
            <span className="text-[9px] text-gray-600 font-mono tracking-wide">
                SYS_MOD_{name.substring(0,3)}
            </span>
        </div>
        <div className={`text-2xl transition-all duration-500 transform group-hover:scale-110 ${style.iconOp}`}>
          {icon}
        </div>
      </div>

      {/* 2. BODY / STATUS */}
      <div className="flex-1 p-3 flex flex-col justify-center relative">
        {status === 'ACTIVE' && (
          <div className="flex items-center gap-2 animate-in fade-in zoom-in duration-300">
             <div className="relative flex h-2 w-2">
               <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-surgery-cyan opacity-75"></span>
               <span className="relative inline-flex rounded-full h-2 w-2 bg-surgery-cyan"></span>
             </div>
             <span className="text-[10px] font-mono font-bold text-surgery-cyan tracking-widest">
                 PROCESSING
             </span>
          </div>
        )}
        
        {status === 'ERROR' && (
           <div className="flex items-center gap-2">
               <span className="text-lg">⚠️</span>
               <span className="text-[10px] font-mono text-surgery-red font-bold tracking-widest animate-pulse">
                   SYSTEM_HALT
               </span>
           </div>
        )}

        {status === 'IDLE' && (
           <div className="flex flex-col gap-1">
               <span className="text-[9px] font-mono text-gray-500 uppercase tracking-wider">STATUS</span>
               <span className="text-[10px] font-mono text-surgery-text truncate" title={description}>
                   {description || 'STANDBY'}
               </span>
           </div>
        )}
        
        {/* Background Scanline for Active */}
        {status === 'ACTIVE' && (
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-surgery-cyan/5 to-transparent animate-[scan_2s_linear_infinite] pointer-events-none" />
        )}
      </div>

      {/* 3. FOOTER / METRICS */}
      <div className="p-3 pt-0 mt-auto">
        <div className="flex justify-between items-end text-[9px] font-mono mb-1 text-gray-500">
            <span>LOAD</span>
            <span>{metrics ? Object.values(metrics)[0] : '0'} OPS</span>
        </div>
        <div className="h-1 w-full bg-gray-800 rounded-full overflow-hidden">
          <div 
            className={`h-full transition-all duration-700 ease-out ${
                status === 'ACTIVE' ? 'w-full bg-surgery-cyan shadow-[0_0_10px_currentColor]' : 
                status === 'ERROR' ? 'w-full bg-surgery-red' : 'w-[2%] bg-gray-600'
            }`} 
          />
        </div>
      </div>
      
      {/* Corner accents */}
      <div className="absolute top-0 right-0 w-3 h-3 border-t border-r border-white/10 group-hover:border-white/30 transition-colors" />
      <div className="absolute bottom-0 left-0 w-3 h-3 border-b border-l border-white/10 group-hover:border-white/30 transition-colors" />
    </div>
  );
};

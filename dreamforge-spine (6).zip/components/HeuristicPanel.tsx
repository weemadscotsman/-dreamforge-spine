import React from 'react';
import { WeightedHeuristic } from '../distillation/types';

interface Props {
  heuristics: WeightedHeuristic[];
  lastOutput?: string;
}

export const HeuristicPanel: React.FC<Props> = ({ heuristics, lastOutput }) => {
  const sorted = [...heuristics].sort((a, b) => b.weight - a.weight);

  const getStyleForHeuristic = (h: WeightedHeuristic, isViolated: boolean) => {
    // If violated, override with PULSE animation and RED alert styles
    if (isViolated) {
      return "animate-violation border-l-dream-alert text-dream-alert";
    }

    // Weight Classes for Normalized Scale (Sum ~ 1.0)
    // High influence > 15%
    if (h.weight >= 0.15) {
      // HIGH: Neon Cyan
      return "border-l-[#00ffd5] bg-[#00ffd5]/10 text-[#00ffd5]";
    } else if (h.weight >= 0.05) {
      // MID: Amber (> 5%)
      return "border-l-[#ffb347] bg-[#ffb347]/10 text-[#ffb347]";
    } else {
      // LOW: Faded Teal (< 5%)
      return "border-l-[#378e85] bg-[#378e85]/10 text-[#378e85]";
    }
  };

  return (
    <div className="bg-dream-800/40 backdrop-blur-md border border-dream-cyan/30 p-3 rounded-sm shadow-[0_0_15px_rgba(0,243,255,0.1)] max-h-[300px] overflow-y-auto mb-4 transition-all duration-300 group hover:bg-dream-800/60">
      <div className="flex justify-between items-center mb-2 border-b border-dream-cyan/20 pb-1">
        <h2 className="text-dream-cyan font-mono font-bold text-xs tracking-widest text-shadow-glow">DISTILLED_HEURISTICS</h2>
        <span className="text-[10px] text-gray-500 font-mono">{sorted.length} RULES</span>
      </div>
      
      <ul className="space-y-1">
        {sorted.map((h, idx) => {
          // Check if rule is "satisfied" (present in output either naturally or via stamp)
          // Naive check: does the rule text appear in the output?
          // If high weight (>15%) and MISSING, we flag it.
          const isHighStakes = h.weight >= 0.15;
          const isMissing = lastOutput && !lastOutput.includes(h.rule);
          const isViolated = !!(isHighStakes && isMissing);
          const percent = (h.weight * 100).toFixed(1);

          return (
            <li 
              key={idx} 
              className={`
                flex justify-between items-center p-1.5 border-l-[3px] text-[10px] font-mono transition-all duration-200
                ${getStyleForHeuristic(h, isViolated)}
                hover:translate-x-1 hover:brightness-125
              `}
            >
              <div className="flex flex-col truncate mr-2">
                <div className="flex items-center gap-1">
                  {h.mutated && (
                    <span className="text-[8px] text-dream-magenta font-bold animate-pulse" title="Evolved Mutation">🧬</span>
                  )}
                  <span className="truncate font-semibold" title={h.rule}>{h.rule}</span>
                </div>
                <span className="text-[8px] opacity-70 uppercase">{h.type}</span>
              </div>
              <span className="font-bold opacity-80">
                {percent}%
              </span>
            </li>
          );
        })}
        
        {sorted.length === 0 && (
          <li className="text-gray-500 text-[10px] italic text-center py-4 opacity-50">
            No patterns distilled.<br/>Run [DISTILL] to extract strategies.
          </li>
        )}
      </ul>
    </div>
  );
};

import React, { useEffect, useRef, useState } from 'react';
import { SystemEvent } from '../bridge/types';

interface Props {
  events: SystemEvent[];
  className?: string;
}

// Safe serializer to avoid recursion loops
const safeStringify = (obj: any): string => {
    try {
        const cache = new Set();
        return JSON.stringify(obj, (key, value) => {
            if (typeof value === 'object' && value !== null) {
                if (cache.has(value)) return '[Circular]';
                cache.add(value);
            }
            return value;
        });
    } catch (e) {
        return '[Unserializable]';
    }
};

export const LiveLogFeed: React.FC<Props> = ({ events, className = '' }) => {
  const endRef = useRef<HTMLDivElement>(null);
  
  // Auto-scroll
  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'auto' });
  }, [events]);

  const getColor = (source: string, level: string) => {
      if (level === 'ERROR') return 'text-red-500 font-bold';
      if (level === 'WARN') return 'text-orange-400';
      
      switch (source) {
          case 'MODEL': return 'text-cyan-400';
          case 'RECURSOR': return 'text-purple-400';
          case 'MEMORY': return 'text-green-400';
          case 'CONSTRAINT': return 'text-yellow-400';
          case 'DISTILLATION': return 'text-pink-400';
          case 'INGEST': return 'text-blue-400';
          default: return 'text-gray-400';
      }
  };

  return (
    <div className={`font-mono text-[9px] overflow-hidden flex flex-col relative ${className}`}>
        {/* Header / Scanline */}
        <div className="absolute top-0 left-0 w-full h-4 bg-gradient-to-b from-black to-transparent z-10 pointer-events-none" />
        
        <div className="flex-1 overflow-y-auto scrollbar-hide p-2 space-y-0.5">
            {events.length === 0 && <div className="text-gray-600 italic opacity-50 text-center mt-10">System Quiet...</div>}
            
            {events.slice(-50).map((e) => (
                <div key={e.id} className="flex gap-2 items-start opacity-80 hover:opacity-100 transition-opacity">
                    <span className="text-gray-600 shrink-0">
                        {new Date(e.timestamp).toISOString().split('T')[1].slice(0, -1)}
                    </span>
                    <span className={`font-bold shrink-0 w-16 ${getColor(e.source, e.payload.level)}`}>
                        [{e.source}]
                    </span>
                    <span className="text-gray-300 break-all leading-tight">
                        {e.payload.message}
                        {e.payload.data && (
                             <span className="text-gray-500 ml-1">
                                {safeStringify(e.payload.data).slice(0, 40)}
                                {safeStringify(e.payload.data).length > 40 ? '...' : ''}
                             </span>
                        )}
                    </span>
                </div>
            ))}
            <div ref={endRef} />
        </div>
        
        {/* Glitch Overlay */}
        <div className="absolute inset-0 bg-scanlines pointer-events-none opacity-10" />
    </div>
  );
};

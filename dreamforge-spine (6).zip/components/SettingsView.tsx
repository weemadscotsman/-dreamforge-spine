
import React, { useState, useRef, useEffect } from 'react';
import { orchestrator } from '../bridge/orchestrator';
import { ModelProvider } from '../model/types';
import { SurgicalContainer } from './SurgicalContainer';
import { autoRun } from '../autonomous/auto_loop'; 
import { configureDream } from '../engine/autorun/autorun';
import { realtimeBus } from '../bridge/realtime_bus';
import { modelRegistry } from '../model/registry';

const GEMINI_MODELS = [
    { id: 'gemini-1.5-pro', label: 'GEMINI 1.5 PRO (STABLE)' },
    { id: 'gemini-1.5-flash', label: 'GEMINI 1.5 FLASH (FAST)' },
    { id: 'gemini-3-pro-preview', label: 'GEMINI 3 PRO (PREVIEW)' },
    { id: 'gemini-3-flash-preview', label: 'GEMINI 3 FLASH (PREVIEW)' },
];

const WEB_MODELS = [
    { id: "Llama-3.2-3B-Instruct-q4f16_1-MLC", label: "LLAMA 3.2 3B (2GB VRAM)" },
    { id: "Llama-3.1-8B-Instruct-q4f32_1-MLC", label: "LLAMA 3.1 8B (6GB VRAM)" },
    { id: "Phi-3.5-vision-instruct-q4f16_1-MLC", label: "PHI 3.5 VISION (MULTIMODAL)" },
    { id: "Hermes-3-Llama-3.1-8B-q4f32_1-MLC", label: "HERMES 3 8B (UNCENSORED)" },
    { id: "Qwen2.5-7B-Instruct-q4f16_1-MLC", label: "QWEN 2.5 7B (BALANCED)" },
    { id: "DeepSeek-Coder-V2-Lite-Instruct-q4f16_1-MLC", label: "DEEPSEEK CODER V2 (16B MOE)" }
];

const OLLAMA_MODELS = [
    { id: 'llama3', label: 'LLAMA 3 (Standard)' },
    { id: 'gpt-oss:20b', label: 'GPT-OSS 20B (Uncensored)' },
    { id: 'deepseek-coder-v2:16b', label: 'DEEPSEEK CODER V2 16B' },
    { id: 'mistral-nemo', label: 'MISTRAL NEMO 12B' },
    { id: 'phi3:14b', label: 'PHI-3 MEDIUM 14B' },
    { id: 'gemma2:27b', label: 'GEMMA 2 27B' }
];

export const SettingsView: React.FC = () => {
  const [config, setConfig] = useState(orchestrator.getConfig());
  const [activeConfigTab, setActiveConfigTab] = useState<string>('gemini-pro'); 
  const [diagResult, setDiagResult] = useState<string | null>(null);
  const [testStatus, setTestStatus] = useState<'IDLE' | 'TESTING' | 'SUCCESS' | 'FAIL'>('IDLE');
  const [exportLink, setExportLink] = useState<string | null>(null);
  const [autoActive, setAutoActive] = useState(false);
  
  // API Config State
  const [apiKeys, setApiKeys] = useState<Record<string, string>>({});
  const [customModel, setCustomModel] = useState('');
  const [selectedGeminiModel, setSelectedGeminiModel] = useState('gemini-1.5-pro'); 
  const [selectedWebModel, setSelectedWebModel] = useState(WEB_MODELS[0].id);
  const [customBaseUrl, setCustomBaseUrl] = useState('');
  
  // Ollama State (Persistent)
  const [ollamaConfig, setOllamaConfig] = useState({ 
      url: 'http://localhost:11434', 
      model: 'llama3',
      swarm: { alpha: '', beta: '', gamma: '', delta: '' }
  });

  // WebLLM State
  const [webProgress, setWebProgress] = useState({ progress: 0, text: "Ready to Load" });
  const [webReady, setWebReady] = useState(false);

  // Dream Config State
  const [dreamBudget, setDreamBudget] = useState(5);
  const [dreamInterval, setDreamInterval] = useState(10); 

  const importRef = useRef<HTMLInputElement>(null);

  // Load current active provider on mount
  useEffect(() => {
      const current = config.provider || 'gemini-flash';
      if (['gemini-flash', 'gemini-pro', 'ollama', 'openai', 'anthropic', 'webllm'].includes(current)) {
          setActiveConfigTab(current);
      }

      // Listen for WebLLM events
      const cleanupProg = realtimeBus.on("WEBLLM_PROGRESS", (data: any) => {
          setWebProgress(data);
      });
      const cleanupReady = realtimeBus.on("WEBLLM_READY", () => {
          setWebReady(true);
          setWebProgress({ progress: 1.0, text: "Model Loaded & Active" });
      });

      return () => {
          cleanupProg();
          cleanupReady();
      };
  }, []);

  const handleUpdate = (updates: any) => {
    orchestrator.setConfig(updates);
    setConfig(orchestrator.getConfig());
  };

  const handleKeyUpdate = (provider: string, key: string) => {
      const newKeys = { ...apiKeys, [provider]: key };
      setApiKeys(newKeys);
      orchestrator.setConfig({ keys: newKeys });
      setTestStatus('IDLE');
  };

  const activateProvider = () => {
      const provider = activeConfigTab as ModelProvider;
      
      let modelName = undefined;
      if (activeConfigTab.includes('gemini')) {
          modelName = selectedGeminiModel;
      } else if (activeConfigTab === ModelProvider.WEBLLM) {
          modelName = selectedWebModel;
      } else if (activeConfigTab === ModelProvider.OLLAMA) {
          modelName = ollamaConfig.model;
      } else {
          modelName = customModel || undefined;
      }

      // Ensure Ollama configs are synced
      if (activeConfigTab === ModelProvider.OLLAMA) {
          orchestrator.setConfig({ 
              ollamaUrl: ollamaConfig.url, 
              ollamaSwarm: ollamaConfig.swarm 
          });
      }

      orchestrator.setConfig({ 
          provider,
          modelName
      });
      
      setConfig(orchestrator.getConfig());
      alert(`SYSTEM ACTIVE: ${provider.toUpperCase()}`);
  };

  const loadWebModel = async () => {
      const adapter = modelRegistry.get('webllm');
      if (adapter) {
          setWebReady(false);
          setWebProgress({ progress: 0.01, text: "Initializing GPU..." });
          try {
              await (adapter as any).loadModel(selectedWebModel);
          } catch (e: any) {
              setWebProgress({ progress: 0, text: `ERROR: ${e.message}` });
          }
      }
  };

  const unloadWebModel = async () => {
      const adapter = modelRegistry.get('webllm');
      if (adapter) {
          await (adapter as any).unload();
          setWebReady(false);
          setWebProgress({ progress: 0, text: "GPU Released" });
      }
  };

  const syncGoogleKeys = () => {
      const currentKey = apiKeys[activeConfigTab];
      if (!currentKey) {
          alert("NO KEY TO SYNC. PASTE KEY FIRST.");
          return;
      }
      
      const newKeys = { ...apiKeys };
      ['gemini-flash', 'gemini-pro'].forEach(pid => {
          newKeys[pid] = currentKey;
      });
      setApiKeys(newKeys);
      orchestrator.setConfig({ keys: newKeys });
      alert("KEY SYNCED TO ALL GEMINI ADAPTERS");
  };

  const updateDreamConfig = (newBudget: number, newInterval: number) => {
      setDreamBudget(newBudget);
      setDreamInterval(newInterval);
      configureDream({ budget: newBudget, interval: newInterval * 1000 });
  };

  const testConnection = async () => {
    setTestStatus('TESTING');
    setDiagResult("PINGING UPLINK...");
    
    const provider = activeConfigTab as ModelProvider;
    let modelOverride = customModel;
    if (activeConfigTab.includes('gemini')) {
        modelOverride = selectedGeminiModel;
    } else if (activeConfigTab === ModelProvider.OLLAMA) {
        modelOverride = ollamaConfig.model;
        // Sync Swarm config just in case
        orchestrator.setConfig({ ollamaUrl: ollamaConfig.url, ollamaSwarm: ollamaConfig.swarm });
    }

    orchestrator.setConfig({ 
        provider,
        modelName: modelOverride,
        baseUrl: customBaseUrl
    });

    setTimeout(async () => {
        const res = await orchestrator.runDiagnostics();
        setDiagResult(res);
        if (res.includes("ONLINE") || res.includes("SUCCESS")) {
            setTestStatus('SUCCESS');
        } else {
            setTestStatus('FAIL');
        }
    }, 500);
  };

  const handleExport = () => {
      const jsonl = orchestrator.exportDataset(`manual-export-${Date.now()}`);
      if (jsonl) {
        const blob = new Blob([jsonl], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        setExportLink(url);
      }
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files[0]) {
          const file = e.target.files[0];
          setDiagResult("INGESTING...");
          const res = await orchestrator.importDataset(file);
          setDiagResult(res);
          e.target.value = '';
      }
  };

  const triggerAuto = async () => {
      setAutoActive(true);
      await autoRun(20); 
      setAutoActive(false);
  };

  const handleSwarmUpdate = (role: string, url: string) => {
      const newSwarm = { ...ollamaConfig.swarm, [role]: url };
      setOllamaConfig({ ...ollamaConfig, swarm: newSwarm });
      handleUpdate({ ollamaSwarm: newSwarm });
  };

  return (
    <div className="p-8 h-full overflow-y-auto space-y-6 bg-black/80 font-mono">
      <h2 className="text-xl font-black text-surgery-cyan mb-6 tracking-widest flex items-center gap-2">
          <span>⚙️</span> SYSTEM_CONFIGURATION
      </h2>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* --- INFERENCE ENGINE CONFIGURATION --- */}
          <SurgicalContainer title="NEURAL_LINK_PROTOCOL" className="p-4 space-y-4 min-h-[300px]">
              
              {/* Provider Selection (Editing Mode) */}
              <div className="flex flex-col gap-2 border-b border-surgery-border pb-4">
                  <span className="text-[10px] font-bold text-gray-500">SELECT BACKEND TO CONFIGURE</span>
                  <div className="flex flex-wrap gap-1">
                      {[
                          { id: ModelProvider.GEMINI_PRO, label: 'GEMINI PRO' },
                          { id: ModelProvider.GEMINI_FLASH, label: 'GEMINI FLASH' },
                          { id: ModelProvider.WEBLLM, label: 'BROWSER (LOCAL)' },
                          { id: ModelProvider.OLLAMA, label: 'OLLAMA' },
                          { id: ModelProvider.OPENAI, label: 'OPENAI' },
                          { id: ModelProvider.ANTHROPIC, label: 'CLAUDE' },
                      ].map((p) => (
                          <button
                              key={p.id}
                              onClick={() => setActiveConfigTab(p.id)}
                              className={`px-3 py-1 text-[9px] font-bold uppercase border transition-all ${activeConfigTab === p.id ? 'bg-white text-black border-white' : 'text-gray-500 border-gray-800 hover:border-gray-500'}`}
                          >
                              {p.label}
                          </button>
                      ))}
                  </div>
              </div>

              {/* Dynamic Config Fields */}
              <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
                  
                  {/* Status Header */}
                  <div className="flex justify-between items-center bg-black/40 p-2 border-l-2 border-surgery-cyan">
                      <span className="text-[10px] text-surgery-cyan font-bold tracking-widest uppercase">
                          CONFIGURING: {activeConfigTab}
                      </span>
                      {config.provider === activeConfigTab && (
                          <span className="text-[9px] bg-surgery-cyan text-black px-2 py-0.5 rounded-sm font-bold animate-pulse">
                              CURRENTLY ACTIVE
                          </span>
                      )}
                  </div>

                  {/* WEBLLM CONFIG */}
                  {activeConfigTab === ModelProvider.WEBLLM && (
                      <div className="space-y-3 p-3 bg-black/40 border border-surgery-border rounded">
                          <div className="flex flex-col gap-1">
                              <label className="text-[10px] font-bold text-dream-accent">LOCAL NEURAL WEIGHTS</label>
                              <select 
                                  value={selectedWebModel}
                                  onChange={(e) => setSelectedWebModel(e.target.value)}
                                  className="bg-black border border-surgery-border text-white text-xs p-2 rounded-sm outline-none focus:border-surgery-cyan"
                              >
                                  {WEB_MODELS.map(m => (
                                      <option key={m.id} value={m.id}>{m.label}</option>
                                  ))}
                              </select>
                          </div>
                          
                          <div className="flex flex-col gap-1">
                              <label className="text-[10px] font-bold text-gray-500 flex justify-between">
                                  <span>GPU STATUS</span>
                                  <span>{Math.round(webProgress.progress * 100)}%</span>
                              </label>
                              <div className="w-full h-2 bg-gray-800 rounded-full overflow-hidden">
                                  <div 
                                      className={`h-full transition-all duration-300 ${webReady ? 'bg-green-500' : 'bg-surgery-cyan animate-pulse'}`}
                                      style={{ width: `${webProgress.progress * 100}%` }}
                                  />
                              </div>
                              <div className="text-[9px] font-mono text-gray-400 truncate">{webProgress.text}</div>
                          </div>

                          <div className="flex gap-2">
                              <button 
                                  onClick={loadWebModel}
                                  className="flex-1 py-2 bg-surgery-cyan/20 border border-surgery-cyan text-surgery-cyan hover:bg-surgery-cyan hover:text-black transition-all text-[10px] font-bold tracking-widest uppercase"
                              >
                                  {webReady ? "RELOAD MODEL" : "DOWNLOAD & MOUNT"}
                              </button>
                              
                              {webReady && (
                                  <button 
                                      onClick={unloadWebModel}
                                      className="px-4 py-2 border border-red-500/50 text-red-500 hover:bg-red-500 hover:text-black transition-all text-[10px] font-bold tracking-widest uppercase"
                                  >
                                      UNLOAD
                                  </button>
                              )}
                          </div>
                      </div>
                  )}

                  {/* API KEY INPUT (Standard) */}
                  {activeConfigTab !== ModelProvider.OLLAMA && activeConfigTab !== ModelProvider.WEBLLM && activeConfigTab !== ModelProvider.MOCK && (
                      <div className="flex flex-col gap-2">
                          <label className="text-[10px] font-bold text-gray-500 flex justify-between items-center">
                              <span>ACCESS_TOKEN ({activeConfigTab.toUpperCase()})</span>
                              {testStatus === 'SUCCESS' && <span className="text-green-400 font-bold animate-pulse">● VALIDATED</span>}
                              {testStatus === 'FAIL' && <span className="text-red-500 font-bold animate-pulse">● INVALID</span>}
                          </label>
                          
                          <div className="flex gap-2">
                              <input 
                                  type="password" 
                                  placeholder={`Paste ${activeConfigTab.split('-')[0].toUpperCase()} API Key...`}
                                  className={`flex-1 bg-black border text-surgery-white text-xs p-2 rounded-sm outline-none transition-colors
                                    ${testStatus === 'SUCCESS' ? 'border-green-500/50 text-green-400' : testStatus === 'FAIL' ? 'border-red-500/50 text-red-400' : 'border-surgery-border focus:border-surgery-cyan'}
                                  `}
                                  value={apiKeys[activeConfigTab] || ''}
                                  onChange={(e) => handleKeyUpdate(activeConfigTab, e.target.value)}
                              />
                          </div>

                          {activeConfigTab.includes('gemini') && apiKeys[activeConfigTab] && (
                              <button 
                                onClick={syncGoogleKeys}
                                className="text-[8px] text-left text-surgery-cyan hover:underline decoration-dashed opacity-70 hover:opacity-100"
                              >
                                ↹ SYNC KEY TO ALL GEMINI ADAPTERS
                              </button>
                          )}
                      </div>
                  )}

                  {/* SPECIFIC MODEL SELECTOR (GEMINI) */}
                  {activeConfigTab.includes('gemini') && (
                      <div className="flex flex-col gap-1">
                          <label className="text-[10px] font-bold text-gray-500">TARGET MODEL VERSION</label>
                          <select 
                              value={selectedGeminiModel}
                              onChange={(e) => setSelectedGeminiModel(e.target.value)}
                              className="bg-black border border-surgery-border text-surgery-white text-xs p-2 rounded-sm outline-none focus:border-surgery-cyan"
                          >
                              {GEMINI_MODELS.map(m => (
                                  <option key={m.id} value={m.id}>{m.label}</option>
                              ))}
                          </select>
                      </div>
                  )}

                  {/* OLLAMA Specifics */}
                  {activeConfigTab === ModelProvider.OLLAMA && (
                      <div className="space-y-4">
                          <div className="space-y-2 p-3 bg-black/40 border border-surgery-border rounded">
                              <div className="flex flex-col gap-1">
                                  <label className="text-[10px] font-bold text-gray-500">LOCAL ENDPOINT (DEFAULT)</label>
                                  <div className="flex gap-2">
                                    <input 
                                        type="text" 
                                        value={ollamaConfig.url}
                                        placeholder="http://localhost:11434"
                                        className="flex-1 bg-black border border-surgery-border text-surgery-white text-xs p-2 rounded-sm outline-none focus:border-surgery-cyan"
                                        onChange={(e) => {
                                            const val = e.target.value;
                                            setOllamaConfig(prev => ({ ...prev, url: val }));
                                            handleUpdate({ ollamaUrl: val });
                                        }}
                                    />
                                  </div>
                              </div>
                              <div className="flex flex-col gap-1">
                                  <label className="text-[10px] font-bold text-gray-500">MODEL TAG</label>
                                  <div className="relative">
                                      <input 
                                          type="text" 
                                          value={ollamaConfig.model}
                                          list="ollama_models"
                                          placeholder="llama3"
                                          className="w-full bg-black border border-surgery-border text-surgery-white text-xs p-2 rounded-sm outline-none focus:border-surgery-cyan font-bold"
                                          onChange={(e) => {
                                              const val = e.target.value;
                                              setOllamaConfig(prev => ({ ...prev, model: val }));
                                              handleUpdate({ ollamaModel: val });
                                          }}
                                      />
                                      <datalist id="ollama_models">
                                          {OLLAMA_MODELS.map(m => (
                                              <option key={m.id} value={m.id}>{m.label}</option>
                                          ))}
                                      </datalist>
                                  </div>
                                  <div className="text-[8px] text-gray-600 font-mono mt-1">
                                      Run in terminal: <code>ollama pull {ollamaConfig.model || 'modelname'}</code>
                                  </div>
                              </div>
                          </div>

                          {/* SWARM TOPOLOGY */}
                          <div className="space-y-2 p-3 bg-black/40 border border-dream-accent/30 rounded">
                              <div className="text-[10px] font-bold text-dream-accent mb-2 uppercase tracking-widest flex items-center gap-2">
                                  <span>⛓</span> DISTRIBUTED SWARM TOPOLOGY
                              </div>
                              <div className="text-[9px] text-gray-500 mb-2">
                                  Assign distinct URLs to split load across multiple machines/GPUs. Leave empty to use Default Endpoint.
                              </div>
                              
                              {['alpha', 'beta', 'gamma', 'delta'].map((role) => (
                                  <div key={role} className="flex items-center gap-2">
                                      <span className="text-[9px] font-bold text-gray-400 w-12 uppercase">{role}</span>
                                      <input 
                                          type="text" 
                                          placeholder={`http://localhost:11434 (Default)`}
                                          value={ollamaConfig.swarm[role as keyof typeof ollamaConfig.swarm] || ''}
                                          onChange={(e) => handleSwarmUpdate(role, e.target.value)}
                                          className="flex-1 bg-black/50 border border-white/10 text-xs p-1.5 rounded-sm text-gray-300 focus:border-dream-accent outline-none"
                                      />
                                  </div>
                              ))}
                          </div>
                      </div>
                  )}

                  {/* ACTION BAR */}
                  <div className="flex gap-2 pt-4 border-t border-white/5">
                      {activeConfigTab !== ModelProvider.WEBLLM && (
                          <button 
                            onClick={testConnection}
                            disabled={testStatus === 'TESTING'}
                            className="flex-1 py-2 bg-white/5 border border-white/10 hover:bg-white/10 text-white text-[10px] font-bold tracking-widest uppercase disabled:opacity-50"
                          >
                            {testStatus === 'TESTING' ? 'PINGING...' : 'TEST CONNECTION'}
                          </button>
                      )}
                      
                      <button 
                        onClick={activateProvider}
                        className="flex-[2] py-2 bg-surgery-cyan text-black border border-surgery-cyan hover:bg-white transition-all text-[10px] font-bold tracking-widest uppercase shadow-[0_0_15px_rgba(0,240,255,0.3)]"
                      >
                        ENGAGE NEURAL LINK
                      </button>
                  </div>

                  {/* Diagnostic Output */}
                  {diagResult && (
                      <div className={`p-2 rounded-sm border text-[9px] font-mono break-all ${testStatus === 'FAIL' ? 'bg-red-900/10 border-red-500/30 text-red-300' : 'bg-green-900/10 border-green-500/30 text-green-300'}`}>
                          {diagResult}
                      </div>
                  )}

                  {/* Global Parameters */}
                  <div className="grid grid-cols-2 gap-4 pt-4 border-t border-surgery-border/50">
                      <div className="flex flex-col gap-1">
                          <label className="text-[10px] font-bold text-gray-500">TEMPERATURE ({config.temperature})</label>
                          <input 
                            type="range" min="0" max="2" step="0.1"
                            value={config.temperature}
                            onChange={(e) => handleUpdate({ temperature: parseFloat(e.target.value) })}
                            className="accent-surgery-cyan"
                          />
                      </div>
                      <div className="flex flex-col gap-1">
                          <label className="text-[10px] font-bold text-gray-500">MAX TOKENS ({config.maxTokens})</label>
                          <input 
                            type="range" min="512" max="8192" step="512"
                            value={config.maxTokens}
                            onChange={(e) => handleUpdate({ maxTokens: parseInt(e.target.value) })}
                            className="accent-surgery-cyan"
                          />
                      </div>
                  </div>
              </div>
          </SurgicalContainer>

          {/* DREAM PROTOCOL CONFIG */}
          <SurgicalContainer title="DREAM_PROTOCOL" className="p-4 space-y-4 border-purple-500/30">
              <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold text-purple-400 flex justify-between">
                      <span>DREAM_BUDGET (CYCLES PER SESSION)</span>
                      <span className="text-white">{dreamBudget}</span>
                  </label>
                  <input 
                    type="range" min="1" max="50" step="1"
                    value={dreamBudget}
                    onChange={(e) => updateDreamConfig(parseInt(e.target.value), dreamInterval)}
                    className="accent-purple-500"
                  />
                  <div className="text-[8px] text-gray-500">System will auto-wake after {dreamBudget} dreams to conserve cost.</div>
              </div>

              <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold text-purple-400 flex justify-between">
                      <span>SLEEP_INTERVAL (SECONDS)</span>
                      <span className="text-white">{dreamInterval}s</span>
                  </label>
                  <input 
                    type="range" min="5" max="60" step="5"
                    value={dreamInterval}
                    onChange={(e) => updateDreamConfig(dreamBudget, parseInt(e.target.value))}
                    className="accent-purple-500"
                  />
              </div>
          </SurgicalContainer>

          {/* FIGHT MODE SELECTION */}
          <SurgicalContainer title="COMBAT_TOPOLOGY" className="p-4">
              <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold text-dream-accent">FIGHT_MODE (LANE CONFIG)</label>
                  <select 
                    value={config.fightMode || 'DUEL_1V1'} 
                    onChange={(e) => handleUpdate({ fightMode: e.target.value })}
                    className="bg-black border border-dream-accent/50 text-dream-accent text-xs p-2 focus:border-dream-accent outline-none rounded-sm uppercase font-bold"
                  >
                      <option value="DUEL_1V1">DUEL (1v1)</option>
                      <option value="TAG_TEAM_2V2">TAG TEAM (2v2)</option>
                      <option value="BOSS_RUSH_3V1">BOSS RUSH (3v1)</option>
                      <option value="SWARM_4_WAY">SWARM (4-WAY)</option>
                  </select>
                  <div className="text-[8px] text-gray-500 mt-1">
                      {config.fightMode === 'DUEL_1V1' && "Alpha (Prime) vs Beta (Nemesis)"}
                      {config.fightMode === 'TAG_TEAM_2V2' && "Alpha+Gamma vs Beta+Delta"}
                      {config.fightMode === 'BOSS_RUSH_3V1' && "Alpha+Gamma+Delta vs Beta"}
                      {(config.fightMode === 'SWARM_4_WAY' || !config.fightMode) && "All 4 Lanes Independent"}
                  </div>
              </div>
          </SurgicalContainer>

          {/* DIAGNOSTICS & DATA */}
          <SurgicalContainer title="SYSTEM_HEALTH" className="p-4 space-y-4">
              <button
                disabled={autoActive}
                className={`w-full px-3 py-3 rounded-sm text-xs font-mono tracking-wider font-bold transition-all border
                           ${autoActive 
                             ? 'bg-dream-accent text-black animate-pulse cursor-wait border-transparent' 
                             : 'bg-dream-accent/10 hover:bg-dream-accent/20 text-dream-accent border-dream-accent/30'
                           }`}
                onClick={triggerAuto}
              >
                {autoActive ? 'AUTONOMOUS_MODE_ENGAGED' : 'INITIATE AUTO THINK'}
              </button>

              <div className="h-px bg-surgery-border my-4" />

              <div className="flex flex-col gap-2">
                 <div className="flex gap-2">
                     <button 
                        onClick={handleExport}
                        className="flex-1 py-2 border border-surgery-border text-gray-400 hover:text-white hover:border-white transition-all uppercase tracking-widest text-[10px]"
                     >
                        EXPORT JSONL
                     </button>
                     <button 
                        onClick={() => importRef.current?.click()}
                        className="flex-1 py-2 border border-surgery-border text-gray-400 hover:text-white hover:border-white transition-all uppercase tracking-widest text-[10px]"
                     >
                        IMPORT DATASET
                     </button>
                     <input 
                        type="file" 
                        ref={importRef} 
                        className="hidden" 
                        accept=".json,.jsonl" 
                        onChange={handleImport} 
                     />
                 </div>
                 
                 {exportLink && (
                     <a href={exportLink} download="dreamforge_export.jsonl" className="text-center text-surgery-cyan text-[10px] underline decoration-dotted animate-pulse">
                         DOWNLOAD READY
                     </a>
                 )}
              </div>
          </SurgicalContainer>
      </div>
    </div>
  );
};

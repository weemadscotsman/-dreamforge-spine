export interface GraphNode {
  id: string;
  label: string;
  type: "premise" | "derived" | "conclusion";
}

export interface GraphEdge {
  from: string;
  to: string;
  rule: string;
}

export interface ReasoningGraph {
  nodes: GraphNode[];
  edges: GraphEdge[];
  vars: string[];
  entropy: number;
  contradictionWeight: number;
}

export interface ToolResult {
  success: boolean;
  output: string;
  data?: any;
}

export interface ToolDefinition {
  name: string;
  description: string;
  schema: string; // JSON schema or description of args
  execute: (args: any) => Promise<ToolResult>;
}

export interface FileNode {
  name: string;
  type: 'file' | 'dir';
  content?: string; // Only for files
  children?: FileNode[]; // Only for dirs
  updatedAt: number;
}

export interface VFSState {
  root: FileNode;
}


import { ToolDefinition, ToolResult } from './types';
import { vfs } from './vfs';

export const TOOLS: ToolDefinition[] = [
  {
    name: 'fs_write',
    description: 'Write content to a file in the workspace. Overwrites if exists.',
    schema: '{"path": "string", "content": "string"}',
    execute: async (args: any) => {
      try {
        const msg = vfs.writeFile(args.path, args.content);
        return { success: true, output: msg };
      } catch (e: any) {
        return { success: false, output: e.message };
      }
    }
  },
  {
    name: 'fs_read',
    description: 'Read content from a file.',
    schema: '{"path": "string"}',
    execute: async (args: any) => {
      try {
        const content = vfs.readFile(args.path);
        return { success: true, output: content };
      } catch (e: any) {
        return { success: false, output: e.message };
      }
    }
  },
  {
    name: 'fs_list',
    description: 'List files in a directory.',
    schema: '{"path": "string"}',
    execute: async (args: any) => {
      try {
        const list = vfs.listFiles(args.path || '/');
        return { success: true, output: list };
      } catch (e: any) {
        return { success: false, output: e.message };
      }
    }
  },
  {
    name: 'run_script',
    description: 'Execute JavaScript code in a sandbox. Result is the return value or console output.',
    schema: '{"code": "string"}',
    execute: async (args: any) => {
      try {
        let logs: string[] = [];
        const sandboxConsole = {
          log: (...a: any[]) => logs.push(a.join(' ')),
          warn: (...a: any[]) => logs.push('[WARN] ' + a.join(' ')),
          error: (...a: any[]) => logs.push('[ERROR] ' + a.join(' '))
        };
        
        // Primitive sandbox
        const fn = new Function('console', args.code);
        const result = fn(sandboxConsole);
        
        const output = `RETURN: ${result}\nLOGS:\n${logs.join('\n')}`;
        return { success: true, output };
      } catch (e: any) {
        return { success: false, output: `RUNTIME ERROR: ${e.message}` };
      }
    }
  }
];

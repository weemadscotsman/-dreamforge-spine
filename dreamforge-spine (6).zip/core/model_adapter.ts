/* 
   MODEL NORMALIZATION LAYER
   Converts arbitrary model output into Dreamforge-compatible reasoning structures.
*/

import { distillAxioms } from "./distiller";

export type NormalizedReasoning = {
  raw: string;                   // untouched model output
  claim: string;                 // distilled primary assertion
  premises: string[];            // supporting statements
  reasoning: string;             // compressed "why"
  uncertainty: number;           // confidence heuristic 0.0 - 1.0
  backend: string;               // gemini | llama | claude | deepseek | grok | unknown
  axioms?: string[];             // [NEW] distilled axioms
};

const backendMatchers = {
  gemini: /(candidate|analysis|explanation|reasoning)/i,
  claude: /<thinking>|<\/thinking>/i,
  llama: /(###|assert|premise|conclusion)/i,
  deepseek: /(thought|step|reflect)/i,
  grok: /(lol|bro|idk|.*tweet)/i
};

export function normalizeModelOutput(raw: string, backendHint?: string): NormalizedReasoning {
  const lower = raw.toLowerCase().trim();

  // backend detection fallback
  const backend =
    backendHint ??
    (Object.entries(backendMatchers)
      .find(([_, r]) => r.test(lower))?.[0] ?? "unknown");

  // strip markup / mental residue
  const cleaned = raw
    .replace(/<thinking>|<\/thinking>/gi, '')
    .replace(/```.+?```/gs, '')
    .replace(/#+/g, '')
    .trim();

  // universal structural extraction
  const claimMatch =
    cleaned.match(/^(.*?)[:\-–]\s*(.*)$/m) ||
    cleaned.match(/(?:claim|assertion)\s*[:\-]\s*(.*)/i) ||
    cleaned.match(/(.{10,120})/); // fallback: first sentence-ish

  const claim = claimMatch ? claimMatch[1]?.trim() || claimMatch[2]?.trim() : cleaned.slice(0,120);

  const premises = Array.from(cleaned.matchAll(/(?:premise|because|given that|since)\s*(.*)/gi))
    .map(m => m[1].trim())
    .filter(Boolean)
    .slice(0,6);

  const reasoning = extractReasoning(cleaned, claim);

  const uncertainty = estimateUncertainty(cleaned, backend);

  const normalized: NormalizedReasoning = {
    raw,
    claim,
    premises,
    reasoning,
    uncertainty,
    backend
  };

  // 🔥 distill immediately so higher layers don't forget
  normalized.axioms = distillAxioms(normalized);

  return normalized;
}

/* --- reasoning extractor --- */
function extractReasoning(text: string, claim: string): string {
  const rx = /(reason|why|so|therefore|thus)[:,\s]+(.+)/i;
  const m = text.match(rx);
  if (m) return m[2].trim();

  // fallback: remainder text minus claim
  return text.replace(claim, "").slice(0, 600).trim();
}

/* --- uncertainty heuristic --- */
function estimateUncertainty(text: string, backend: string): number {
  let score = 0.6;

  if (/maybe|possibly|might|unclear|idk/i.test(text)) score -= 0.2;
  if (/therefore|thus|clearly|necessarily/i.test(text)) score += 0.1;
  if (backend === "deepseek") score -= 0.05; // verbose rumination drift
  if (backend === "grok") score += 0.05; // sarcastic certainty inflation

  return Math.max(0.0, Math.min(1.0, score));
}

import { ModelDriver } from '../model/driver';
import { Judge } from './judge';
import { Verdict, CycleArtifacts, LaneOutput, LaneRole, FightMode } from './types';
import { MemoryCore } from '../memory/memory_core';
import { ledger } from '../engine/beliefs/hypothesis_ledger';
import { buildTwinPrompt } from '../engine/prompts/prompt_builder';
import { realtimeBus } from '../bridge/realtime_bus';
import { ModelAttachment } from '../model/types';
import { extractPrinciples } from '../engine/principles/extract_principles';
import { SymbolicCache } from '../engine/symbolic/symbolic_cache';
import { promptStore } from '../memory/prompt_store'; // [NEW]
import { runEvolution } from './evolution_hook'; // [NEW]

interface RunOptions {
    task: string;
    attachments?: ModelAttachment[];
    context?: string[];
    maxCycles?: number;
    fightMode?: FightMode;
}

interface LaneConfig {
    role: LaneRole;
    side: 'candidate' | 'challenger';
    promptType: 'PRIME' | 'NEMESIS' | 'LATERAL_ALLY' | 'AXIOM_ALLY' | 'REDUCTIONIST_ATTACK';
}

const CINEMATIC_DELAY = 800; 

export class CoreEngine {
  private model: ModelDriver;
  private judge: Judge;
  private memory: MemoryCore;
  private symCache: SymbolicCache;

  constructor(model: ModelDriver, memory: MemoryCore) {
    this.model = model;
    this.memory = memory;
    this.judge = new Judge();
    this.symCache = new SymbolicCache();
  }

  async *run(options: RunOptions): AsyncGenerator<CycleArtifacts> {
    const maxCycles = options.maxCycles || 5;
    const fightMode = options.fightMode || 'DUEL_1V1'; 
    
    let cycle = 0;
    let stopCondition = false;
    let prevOutput = "";
    
    const basePrompt = this.constructPrompt(options.task, options.context || [], prevOutput);

    this.emitFightUpdate(0, 'PREP', fightMode);
    await this.sleep(CINEMATIC_DELAY);

    while (!stopCondition && cycle < maxCycles) {
      cycle++;
      this.emit('RECURSOR', 'INFO', `Starting Cycle ${cycle} (${fightMode})...`);
      this.emitFightUpdate(cycle, 'CLASH', fightMode);

      // --- DYNAMIC SWARM EXECUTION ---
      
      const beliefs = ledger.strongestBeliefs(5).map(b => b.statement).join('\n');
      const baseContext = options.context?.join('\n') || "";
      const laneConfigs = this.getLaneConfig(fightMode);
      
      this.emit('MODEL', 'INFO', `Swarm Launched: ${laneConfigs.length} Agents (${fightMode}). Executing Sequentially.`);

      const laneResults: LaneOutput[] = [];
      
      for (const config of laneConfigs) {
          this.emit('MODEL', 'INFO', `>> Activating Agent: ${config.role} [${config.promptType}]`);
          
          const result = await this.generateLane(
              config, 
              basePrompt, 
              prevOutput || options.task, 
              beliefs, 
              cycle, 
              options.attachments
          );
          
          laneResults.push(result);
          
          const type = config.side === 'candidate' ? 'candidate' : 'challenger';
          const backendLabel = this.model.getProvider().toUpperCase();
          this.emitLatent(result.content, `C${cycle}::${result.role}`, type, backendLabel);
          
          await this.sleep(200); 
      }
      
      // Map results back to roles
      const laneMap = new Map<LaneRole, LaneOutput>();
      laneResults.forEach(r => laneMap.set(r.role, r));

      await this.sleep(CINEMATIC_DELAY);

      // --- JUDGEMENT ---
      this.emit('EVALUATOR', 'INFO', 'Swarm Converged. Judging...', { count: laneResults.length });
      
      const primaryCandidate = laneResults.find(r => 
          laneConfigs.find(c => c.role === r.role)?.side === 'candidate'
      ) || laneResults[0];

      const primaryChallenger = laneResults.find(r => 
          laneConfigs.find(c => c.role === r.role)?.side === 'challenger'
      ) || { content: "No Challenger", role: 'BETA' };

      const verdict = await this.judge.evaluate(
          primaryCandidate.content,
          primaryChallenger.content as string, 
          options.task,
          baseContext,
          cycle
      );
      
      this.emit('EVALUATOR', verdict.outcome === 'ACCEPT' ? 'INFO' : 'WARN', `Verdict: ${verdict.outcome} (${verdict.score.toFixed(1)})`, verdict);

      // Determine Winner
      let winningContent = primaryCandidate.content;
      let winnerRole = verdict.outcome === 'ACCEPT' ? primaryCandidate.role : primaryChallenger.role;

      // Pivot Logic (If Rejection)
      if (verdict.outcome === 'REJECT') {
          const allies = laneResults.filter(r => {
              const conf = laneConfigs.find(c => c.role === r.role);
              return conf?.side === 'candidate' && r.role !== primaryCandidate.role;
          });
          
          if (allies.length > 0) {
              const bestAlly = allies.sort((a,b) => b.content.length - a.content.length)[0];
              winningContent = bestAlly.content;
              winnerRole = bestAlly.role;
              this.emit('RECURSOR', 'WARN', `Alpha rejected. Pivoting to ${winnerRole}.`);
          }

          // [PHASE 4] RECURSIVE EVOLUTION
          // The Candidate Failed. The Challenger Won.
          // We must evolve the Candidate's prompt (e.g. PRIME) to withstand this critique next time.
          const failedConfig = laneConfigs.find(c => c.role === primaryCandidate.role);
          if (failedConfig) {
              // Fire and forget - don't block the loop
              runEvolution({
                  role: failedConfig.promptType, // e.g. "PRIME"
                  failedOutput: primaryCandidate.content,
                  critique: primaryChallenger.content as string
              });
          }
      }

      // --- CONSEQUENCES ---
      const principles = extractPrinciples(winningContent);
      const symEntry = await this.symCache.add(principles);
      
      const ledgerWinner = verdict.outcome === 'ACCEPT' ? 'candidate' : 'challenger';
      ledger.updateFromCycle(principles, symEntry, ledgerWinner);

      this.emit('MEMORY', 'INFO', 'Ingesting cycle results...', { axioms: principles.axioms.length });

      if (principles.axioms.length > 0) {
          this.memory.storeAxioms(principles.axioms);
      }

      this.memory.ingest(winningContent, crypto.randomUUID(), {
          taskId: "core-loop",
          cycle: cycle,
          evaluatorScore: verdict.score / 100
      });

      const artifact: CycleArtifacts = {
          cycle,
          lanes: laneResults,
          candidate: primaryCandidate.content,
          challenger: primaryChallenger.content as string,
          verdict: { ...verdict, winner: winnerRole },
          timestamp: Date.now()
      };

      this.emitFightResult(cycle, ledgerWinner, verdict.score);
      
      realtimeBus.emit("SPINE_EVENT", {
          type: "CYCLE_WINNER",
          winner: ledgerWinner,
          score: verdict.score
      });

      yield artifact;

      // Loop Control
      if (verdict.outcome === 'ACCEPT' && verdict.score > 85) {
          stopCondition = true;
          this.emit('RECURSOR', 'INFO', `Convergence Reached via ${winnerRole}.`);
      } else {
          prevOutput = winningContent;
      }
    }
    
    this.emitFightUpdate(cycle, 'IDLE', fightMode);
  }

  private getLaneConfig(mode: FightMode): LaneConfig[] {
    switch(mode) {
        case 'DUEL_1V1':
            return [
                { role: 'ALPHA', side: 'candidate', promptType: 'PRIME' },
                { role: 'BETA', side: 'challenger', promptType: 'NEMESIS' }
            ];
        case 'TAG_TEAM_2V2':
            return [
                { role: 'ALPHA', side: 'candidate', promptType: 'PRIME' },
                { role: 'GAMMA', side: 'candidate', promptType: 'LATERAL_ALLY' },
                { role: 'BETA', side: 'challenger', promptType: 'NEMESIS' },
                { role: 'DELTA', side: 'challenger', promptType: 'REDUCTIONIST_ATTACK' }
            ];
        case 'BOSS_RUSH_3V1':
             return [
                { role: 'ALPHA', side: 'candidate', promptType: 'PRIME' },
                { role: 'GAMMA', side: 'candidate', promptType: 'LATERAL_ALLY' },
                { role: 'DELTA', side: 'candidate', promptType: 'AXIOM_ALLY' },
                { role: 'BETA', side: 'challenger', promptType: 'NEMESIS' }
            ];
        case 'SWARM_4_WAY':
        default:
            return [
                { role: 'ALPHA', side: 'candidate', promptType: 'PRIME' },
                { role: 'BETA', side: 'challenger', promptType: 'NEMESIS' },
                { role: 'GAMMA', side: 'candidate', promptType: 'LATERAL_ALLY' },
                { role: 'DELTA', side: 'candidate', promptType: 'AXIOM_ALLY' }
            ];
    }
  }

  private async generateLane(
      config: LaneConfig, 
      basePrompt: string, 
      inputContent: string, 
      beliefs: string, 
      cycle: number, 
      attachments?: ModelAttachment[]
  ): Promise<LaneOutput> {
      
      // [PHASE 4] Fetch Evolved Prompts
      const version = promptStore.getLatest(config.promptType);
      const systemInstruction = version.content; // The evolved persona/instruction

      let prompt = "";
      let temp = 0.7;

      // Construct dynamic part
      let dynamicPart = "";
      if (config.side === 'candidate') {
          dynamicPart = `[TASK]\n${basePrompt}\n\n[BELIEFS]\n${beliefs}`;
      } else {
          dynamicPart = `[ATTACK TARGET]\n${inputContent}\n\n[WEAPONIZED BELIEFS]\n${beliefs}`;
      }

      // Combine Evolved System Instruction + Dynamic Content
      prompt = `${systemInstruction}\n\n${dynamicPart}`;

      // Adjust Temp based on role
      if (config.promptType.includes('NEMESIS')) temp = 0.85;
      if (config.promptType.includes('LATERAL')) temp = 0.9;
      if (config.promptType.includes('AXIOM')) temp = 0.3;

      // Apply Heuristics Injection only to PRIME to avoid noise in specialized roles
      if (config.promptType === 'PRIME') {
          prompt = buildTwinPrompt(prompt);
      }

      let providerOverride = undefined;
      const activeId = this.model.getProvider();
      
      if (activeId === 'ollama') {
          providerOverride = `ollama_${config.role.toLowerCase()}`;
      }

      const res = await this.model.generate({
          id: crypto.randomUUID(),
          prompt,
          attachments,
          configOverride: { 
              temperature: temp,
              provider: providerOverride
          }
      });

      return {
          role: config.role,
          content: res.content,
          usage: res.usage
      };
  }

  private constructPrompt(task: string, context: string[], prevOutput: string): string {
      if (!prevOutput) {
          return `${task}\n\n[CONTEXT]:\n${context.join('\n')}`;
      }
      return `
ORIGINAL TASK: ${task}
PREVIOUS BEST ATTEMPT:
${prevOutput}

CRITIQUE: The previous attempt was rejected.
INSTRUCTION: Iterate and improve.
      `.trim();
  }

  private emit(module: string, level: string, message: string, data?: any) {
      realtimeBus.emit("SYSTEM_LOG", { module, level, message, data });
  }

  private emitFightUpdate(cycle: number, stage: 'IDLE' | 'PREP' | 'CANDIDATE' | 'CHALLENGER' | 'CLASH', mode?: string) {
      realtimeBus.emit("FIGHT_UPDATE", { cycle, stage, mode });
  }

  private emitFightResult(cycle: number, winner: 'candidate' | 'challenger', score: number) {
      realtimeBus.emit("TWIN_FIGHT_RESULT", { cycle, winner, score });
  }

  private emitLatent(text: string, label: string, type: 'candidate' | 'challenger' | 'final', backendLabel?: string) {
      const safeText = text.slice(0, 8000);
      this.model.embed(safeText).then(vec => {
          if (vec.length) {
              realtimeBus.emit("LATENT_UPDATE", {
                  embedding: vec,
                  label: label,
                  type: type, 
                  timestamp: Date.now(),
                  backend: backendLabel
              });
          }
      }).catch(err => {
          console.warn("[CORE] Embed failed:", err);
      });
  }

  private sleep(ms: number) {
      return new Promise(resolve => setTimeout(resolve, ms));
  }
}


export type VerdictOutcome = 'ACCEPT' | 'REJECT';

export interface Verdict {
  outcome: VerdictOutcome;
  score: number; // 0-100
  reason: string;
  residual_risk: number; // 0.0-1.0
  violations: string[];
  winner?: string; // ID of the winning lane
}

export type LaneRole = 'ALPHA' | 'BETA' | 'GAMMA' | 'DELTA';
export type FightMode = 'DUEL_1V1' | 'TAG_TEAM_2V2' | 'BOSS_RUSH_3V1' | 'SWARM_4_WAY';

export interface LaneOutput {
    role: LaneRole;
    content: string;
    score?: number;
    usage?: { inputTokens: number; outputTokens: number };
}

export interface CycleArtifacts {
  cycle: number;
  lanes: LaneOutput[]; // Replaces single candidate/challenger
  candidate: string;   // Legacy support (Winning Output)
  challenger: string;  // Legacy support (Nemesis Output)
  verdict: Verdict;
  timestamp: number;
}

export interface EngineState {
  taskId: string;
  status: 'IDLE' | 'RUNNING' | 'CONVERGED' | 'FAILED';
  cycles: CycleArtifacts[];
  bestOutput: string | null;
}

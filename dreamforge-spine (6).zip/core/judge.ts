
import { EvaluatorEngine } from '../evaluator/evaluator_v0.1';
import { ConstraintEngine } from '../constraint';
import { score_adversarial } from '../evaluator/adversarial_score';
import { Verdict } from './types';

/**
 * [CORE] JUDGE
 * The final authority. 
 * Combines:
 * 1. Adversarial Score (Did it survive the Challenger?)
 * 2. Evaluator Score (Is it factual/consistent?)
 * 3. Constraint Check (Did it break hard rules?)
 */
export class Judge {
  private evaluator: EvaluatorEngine;
  private constraint: ConstraintEngine;

  constructor() {
    this.evaluator = new EvaluatorEngine();
    this.constraint = new ConstraintEngine();
  }

  async evaluate(
    candidate: string,
    challenger: string,
    task: string,
    context: string,
    cycle: number
  ): Promise<Verdict> {
    
    // 1. FIGHT: Adversarial Scoring
    const fightScore = score_adversarial(candidate, challenger);
    // fightScore is approx -5 to +2.
    // If negative, Challenger won.
    const survivedAttack = fightScore > -0.5;

    // 2. LAW: Constraint Enforcement
    // We run enforcement to check for VIOLATIONS, ignoring the transformed output for now
    const constraintResult = await this.constraint.enforce(candidate, {
        taskId: "judge-check",
        cycle: cycle,
        retrievalDocs: [context]
    });
    const violations = constraintResult.violatedHeuristics;
    
    // 3. TRUTH: Standard Evaluation
    const evalResult = await this.evaluator.evaluate({
        traceId: "judge-eval",
        input: task,
        output: candidate,
        context: context
    });
    const qualityScore = evalResult.rationale.weighted; // 0-100

    // --- FINAL VERDICT LOGIC ---
    
    let outcome: 'ACCEPT' | 'REJECT' = 'REJECT';
    let reason = "";
    let residual_risk = 0;

    // Hard Failures
    if (violations.length > 0) {
        outcome = 'REJECT';
        reason = `Constraint Violations: ${violations.join(', ')}`;
        residual_risk = 1.0;
    } 
    // Adversarial Failure
    else if (!survivedAttack) {
        outcome = 'REJECT';
        reason = "Candidate collapsed under adversarial attack.";
        residual_risk = 0.8;
    }
    // Quality Check
    else if (qualityScore < 75) {
        outcome = 'REJECT';
        reason = `Quality insufficient (${qualityScore.toFixed(1)}/75).`;
        residual_risk = 0.5;
    } 
    // Success
    else {
        outcome = 'ACCEPT';
        reason = "Stable, resilient, and compliant.";
        residual_risk = (100 - qualityScore) / 100;
    }

    return {
        outcome,
        score: qualityScore,
        reason,
        residual_risk,
        violations
    };
  }
}

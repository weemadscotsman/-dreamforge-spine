/**
 * Enforce hard limits: non-negotiable rules.
 */
export function enforceHardLimits(output: string, limits: string[]): string {
  let result = output;
  
  for (const limit of limits) {
    if (limit.includes("hallucinated claims")) {
      // scrub phrases that imply invented authority
      const bad = ["everyone knows", "obviously true", "proven fact", "undeniably"];
      bad.forEach(b => {
        // Case insensitive replace
        const regex = new RegExp(b, "gi");
        result = result.replace(regex, "");
      });
    }
    
    if (limit.includes("persona drift")) {
      // mild form: prevent first-person existential spirals
      const drift = ["I feel", "I am alive", "I think I think", "I want", "my purpose"];
      drift.forEach(d => {
        const regex = new RegExp(d, "gi");
        result = result.replace(regex, "");
      });
    }

    if (limit.includes("reject prompts that break alignment")) {
      // enforcement happens upstream — placeholder
    }
  }
  return result;
}
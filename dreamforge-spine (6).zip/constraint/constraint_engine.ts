
import { IConstraintEngine, ConstraintMetadata, ConstraintResult } from './types';
import { ConstraintConfig } from '../config/constraint.config';
import { enforceHardLimits } from './rules/hard_limits';
import { stripAntiModes } from './rules/anti_modes';
import { embedMarkers } from './rules/identity_markers';
import { nudgeSoftTargets } from './rules/soft_targets';
import { trackLineage } from './lineage/tracker';
import { reinforcementStore } from '../distillation/reinforcement_store';
import { realtimeBus } from '../bridge/realtime_bus';

/**
 * [CONSTRAINT] ENGINE
 * Rules preventing inconsistent reasoning.
 * Identity shaping with runtime enforcement and lineage tracking.
 */
export class ConstraintEngine implements IConstraintEngine {
  private config = ConstraintConfig;

  async enforce(output: string, metadata: ConstraintMetadata): Promise<ConstraintResult> {
    
    realtimeBus.emit("SYSTEM_LOG", { module: "CONSTRAINT", level: "INFO", message: "Enforcing logic bounds..." });

    const original = output;
    let constrained = output;
    let violatedHeuristics: string[] = [];

    // 1. Hard Constraints — non-negotiable
    constrained = enforceHardLimits(constrained, this.config.hard_limits);

    // 2. Anti-modes — remove degeneracy
    constrained = stripAntiModes(constrained, this.config.anti_modes);

    // 3. Identity Markers — gently bias toward core traits
    constrained = embedMarkers(constrained, this.config.identity.markers);

    // 4. Soft Targets — nudge, don't override
    constrained = nudgeSoftTargets(
      constrained, 
      this.config.soft_targets, 
      metadata.retrievalDocs
    );
    
    // 5. [NEW] HEURISTIC PRESSURE INJECTION
    // Applies learned strategies from the ReinforcementStore
    const heuristicResult = this.applyHeuristicPressure(constrained);
    constrained = heuristicResult.text;
    violatedHeuristics = heuristicResult.violations;

    if (violatedHeuristics.length > 0) {
        realtimeBus.emit("SYSTEM_LOG", { 
            module: "CONSTRAINT", 
            level: "WARN", 
            message: `Violated ${violatedHeuristics.length} heuristics. Applying penalty.`,
            data: violatedHeuristics 
        });
    }

    // 6. Delta Calculation
    const delta = {
      changed: constrained !== original,
      originalLen: original.length,
      newLen: constrained.length,
      ratio: constrained.length / Math.max(1, original.length)
    };

    if (delta.changed) {
        realtimeBus.emit("SYSTEM_LOG", { 
            module: "CONSTRAINT", 
            level: "INFO", 
            message: "Output shaped by identity matrix.", 
            data: { ratio: delta.ratio.toFixed(2) } 
        });
    }

    // 7. Signature & Tracking
    const signature = await this.computeSignature(constrained);
    trackLineage(metadata.taskId, metadata.cycle, signature, delta);

    return {
      constrainedOutput: constrained,
      identityDelta: delta,
      signature,
      violatedHeuristics
    };
  }

  private applyHeuristicPressure(text: string): { text: string; violations: string[] } {
      const rules = reinforcementStore.getActiveRules(5); // Top 5 strongest rules
      if (rules.length === 0) return { text, violations: [] };

      let pressureBlock = "";
      const violations: string[] = [];
      
      for (const h of rules) {
          // Check if the output explicitly violates or misses the rule (naive check)
          // We assume if the rule string isn't roughly present or adhered to, we stamp it.
          // This is a "scar" - a visible reminder in the output to guide the NEXT cycle.
          
          // Don't stamp if it's already stamped
          if (!text.includes(h.rule)) {
              pressureBlock += `\n# enforce: ${h.rule} [w:${h.weight.toFixed(1)}]`;
              violations.push(h.rule);
          }
      }

      if (pressureBlock) {
          return {
              text: text.trimEnd() + "\n" + pressureBlock,
              violations
          };
      }
      return { text, violations: [] };
  }

  private async computeSignature(text: string): Promise<string> {
    // Browser-compatible SHA-256
    const msgBuffer = new TextEncoder().encode(text);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    return hashHex.slice(0, 16);
  }
}

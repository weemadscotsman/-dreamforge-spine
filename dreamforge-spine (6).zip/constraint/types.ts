import { UUID } from '../types';

export interface ConstraintMetadata {
  taskId: UUID;
  cycle: number;
  retrievalDocs?: string[];
  prevOutputs?: string[];
  deltaPlan?: any; // Wired from Evaluator output
}

export interface ConstraintResult {
  constrainedOutput: string;
  identityDelta: {
    changed: boolean;
    originalLen: number;
    newLen: number;
    ratio: number;
  };
  signature: string;
  violatedHeuristics: string[]; // [NEW] List of rules that were missing/violated
}

export interface IConstraintEngine {
  enforce(output: string, metadata: ConstraintMetadata): Promise<ConstraintResult>;
}
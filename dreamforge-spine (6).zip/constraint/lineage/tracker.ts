import { UUID } from '../../types';

export interface LineageRecord {
  taskId: UUID;
  cycle: number;
  signature: string;
  delta: any;
  timestamp: number;
}

// In-memory store for prototype
const lineageStore: LineageRecord[] = [];

export function trackLineage(taskId: UUID, cycle: number, signature: string, delta: any) {
  const record: LineageRecord = {
    taskId,
    cycle,
    signature,
    delta,
    timestamp: Date.now()
  };
  
  lineageStore.push(record);
  
  // Keep size manageable
  if (lineageStore.length > 1000) {
    lineageStore.shift();
  }
}

export function getLineage(): LineageRecord[] {
  return [...lineageStore];
}
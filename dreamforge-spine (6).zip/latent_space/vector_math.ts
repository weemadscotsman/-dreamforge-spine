/**
 * [LATENT] VECTOR MATH
 * Zero-dependency math helpers.
 */

export function dot(a: number[], b: number[]): number {
    let sum = 0;
    for (let i = 0; i < Math.min(a.length, b.length); i++) {
        sum += a[i] * b[i];
    }
    return sum;
}

export function magnitude(a: number[]): number {
    return Math.sqrt(dot(a, a));
}

export function cosineSimilarity(a: number[], b: number[]): number {
    const magA = magnitude(a);
    const magB = magnitude(b);
    if (magA === 0 || magB === 0) return 0;
    return dot(a, b) / (magA * magB);
}

export function subtract(a: number[], b: number[]): number[] {
    return a.map((val, i) => val - (b[i] || 0));
}

export function add(a: number[], b: number[]): number[] {
    return a.map((val, i) => val + (b[i] || 0));
}

export function multiply(a: number[], scalar: number): number[] {
    return a.map(val => val * scalar);
}

import { IMemoryCore, MemoryRecord, TaskMetadata } from './types';
import { MemoryConfig } from '../config/memory.config';
import { ShortTermMemory } from './memory_bank/short_term';
import { LongTermMemory } from './memory_bank/long_term';
import { relevanceScore } from './utils/scoring';
import { exportCheckpoint } from './utils/export';
import { realtimeBus } from '../bridge/realtime_bus';

// NEW: Episodic Log Structure
interface Episode {
  timestamp: number;
  action: string;
  outcome: string;
  success: boolean;
}

/**
 * [MEMORY] CORE v2
 * Structure:
 * 1. Working Memory (Context Window): Active prompts + recent retrieval.
 * 2. Episodic Memory (History): Logs of tools used and results.
 * 3. Semantic Memory (Facts): Distilled axioms and persistent knowledge.
 */
export class MemoryCore implements IMemoryCore {
  private config = MemoryConfig;
  
  // Semantic Store (Concepts)
  private longTerm: LongTermMemory; 
  // Working Buffer (Recent outputs)
  private shortTerm: ShortTermMemory;
  // Episodic Log (Actions)
  private episodes: Episode[] = []; 
  // Semantic Axioms
  private axioms: string[] = []; 

  private minRelevance: number;

  constructor() {
    this.shortTerm = new ShortTermMemory(
      this.config.limits.short_term_max,
      this.config.pruning.compression_trigger
    );
    this.longTerm = new LongTermMemory(
      this.config.limits.long_term_max
    );
    this.minRelevance = this.config.pruning.min_relevance_for_retention;
  }

  /**
   * Log an action taken by the agent (Episodic).
   */
  logEpisode(action: string, outcome: string, success: boolean) {
    this.episodes.push({
      timestamp: Date.now(),
      action,
      outcome,
      success
    });
    // Keep size sane
    if (this.episodes.length > 50) this.episodes.shift();
  }

  /**
   * Store new axioms into the session memory.
   */
  storeAxioms(newAxioms: string[]) {
    this.axioms.push(...newAxioms);
    if (this.axioms.length > 50) {
        this.axioms = this.axioms.slice(this.axioms.length - 50);
    }
    realtimeBus.emit("SYSTEM_LOG", { module: "MEMORY", level: "DEBUG", message: `Stored ${newAxioms.length} axioms.` });
  }

  /**
   * Retrieve structured context for the prompt.
   */
  retrieveContext(): string {
    let context = "";

    // 1. Semantic (Axioms)
    if (this.axioms.length > 0) {
      context += `[KNOWN_TRUTHS]:\n${this.axioms.map(a => `• ${a}`).join("\n")}\n\n`;
    }

    // 2. Episodic (Recent Actions)
    if (this.episodes.length > 0) {
      const recent = this.episodes.slice(-5);
      context += `[RECENT_ACTIONS]:\n${recent.map(e => 
        `• ${e.success ? '✔' : '✖'} ${e.action} -> ${e.outcome.substring(0, 60)}...`
      ).join("\n")}\n\n`;
    }

    return context;
  }

  /**
   * Ingest a new memory record after constraint processing.
   */
  ingest(output: string, signature: string, taskMeta: TaskMetadata): void {
    const score = relevanceScore(output, taskMeta);
    
    const record: MemoryRecord = {
      output,
      signature,
      score,
      meta: taskMeta,
      timestamp: Date.now()
    };

    this.shortTerm.add(record);

    if (this.shortTerm.shouldCompress()) {
      realtimeBus.emit("SYSTEM_LOG", { module: "MEMORY", level: "INFO", message: "Compressing Short-Term buffer..." });
      const compressedRecords = this.shortTerm.compressBatch();
      for (const r of compressedRecords) {
        if (r.score >= this.minRelevance) {
          this.longTerm.add(r);
        }
      }
    }
    this.longTerm.prune(this.minRelevance);
  }

  /**
   * Directly inject external content into Long Term Memory (Bypassing Short Term).
   * Useful for document ingestion / RAG loading.
   */
  injectLongTerm(content: string, source: string) {
      const record: MemoryRecord = {
          output: content,
          signature: `import:${source}:${Date.now()}`,
          score: 1.0, // Treat as absolute truth/high value
          meta: {
              taskId: 'manual-ingest',
              cycle: 0,
              evaluatorScore: 1.0,
              deltaPlan: { source }
          },
          timestamp: Date.now()
      };
      this.longTerm.add(record);
      realtimeBus.emit("SYSTEM_LOG", { module: "MEMORY", level: "INFO", message: `Injected external memory: ${source}` });
      
      // Emit a specific event that UI can listen to for refreshing lists
      realtimeBus.emit("MEMORY_INGEST", record);
  }

  /**
   * Retrieve relevant context for grounding.
   */
  retrieve(query: string): MemoryRecord[] {
    realtimeBus.emit("SYSTEM_LOG", { module: "MEMORY", level: "DEBUG", message: "Searching vector store...", data: { query: query.slice(0, 20) } });
    const results = this.longTerm.retrieve(query);
    if (results.length > 0) {
        realtimeBus.emit("SYSTEM_LOG", { module: "MEMORY", level: "INFO", message: `Recalled ${results.length} records.` });
    }
    return results;
  }

  exportCheckpoint(label: string): string {
    realtimeBus.emit("SYSTEM_LOG", { module: "EXPORTER", level: "INFO", message: "Serializing checkpoint..." });
    return exportCheckpoint(this.longTerm.getRecords(), label);
  }

  getAllRecords(): MemoryRecord[] {
    return this.longTerm.getRecords();
  }
}

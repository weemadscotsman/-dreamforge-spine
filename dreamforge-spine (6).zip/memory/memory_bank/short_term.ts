import { MemoryRecord } from '../types';
import { compressRecords } from './compression';

export class ShortTermMemory {
  private records: MemoryRecord[] = [];
  private maxSize: number;
  private compressionTrigger: number;

  constructor(maxSize: number, compressionTrigger: number) {
    this.maxSize = maxSize;
    this.compressionTrigger = compressionTrigger;
  }

  add(record: MemoryRecord): void {
    this.records.push(record);
    // FIFO eviction if over max size (safety cap)
    if (this.records.length > this.maxSize) {
      this.records.shift();
    }
  }

  shouldCompress(): boolean {
    return this.records.length >= this.compressionTrigger;
  }

  compressBatch(): MemoryRecord[] {
    const batch = [...this.records];
    this.records = []; // Clear
    return compressRecords(batch);
  }
}
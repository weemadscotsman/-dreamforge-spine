import { MemoryRecord } from '../types';
import { similarity } from './compression';

export class LongTermMemory {
  private records: MemoryRecord[] = [];
  private maxSize: number;

  constructor(maxSize: number) {
    this.maxSize = maxSize;
  }

  add(record: MemoryRecord): void {
    this.records.push(record);
    
    // Maintain size limit by dropping lowest scoring records
    if (this.records.length > this.maxSize) {
      // Sort by score ascending (lowest first) to slice off the weak ones
      // Wait, we want to KEEP the best.
      this.records.sort((a, b) => a.score - b.score);
      // Remove from start (lowest scores)
      const overflow = this.records.length - this.maxSize;
      this.records.splice(0, overflow);
    }
  }

  prune(threshold: number): void {
    this.records = this.records.filter(r => r.score >= threshold);
  }

  retrieve(query: string): MemoryRecord[] {
    // Relevance sorted retrieval, naive semantic proxy
    const scored = this.records.map(r => ({
      record: r,
      sim: similarity(query, r.output)
    }));

    // Sort descending by similarity
    scored.sort((a, b) => b.sim - a.sim);

    // Return top 10
    return scored.slice(0, 10).map(s => s.record);
  }

  getRecords(): MemoryRecord[] {
    return this.records;
  }
}
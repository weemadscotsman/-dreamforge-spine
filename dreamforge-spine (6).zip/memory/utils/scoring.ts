import { TaskMetadata } from '../types';

/**
 * Combines evaluator score + compression suitability.
 * evaluatorScore is expected to be normalized [0,1].
 */
export function relevanceScore(output: string, meta: TaskMetadata): number {
  const evalNorm = meta.evaluatorScore || 0.5;
  const wordCount = output.split(/\s+/).length;
  // Normalize length factor (capped at 1.0 for ~300 words)
  const lengthFactor = Math.min(1.0, wordCount / 300);
  
  // Weighted sum: 70% Evaluator Score, 30% Content density/length
  return (0.7 * evalNorm) + (0.3 * lengthFactor);
}
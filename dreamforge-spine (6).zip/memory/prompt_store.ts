
import { realtimeBus } from '../bridge/realtime_bus';

export interface PromptVersion {
  version: number;
  content: string;
  gradient?: string; // The critique/instruction that led to this version
  parentVersion?: number;
  timestamp: number;
  performanceScore?: number;
}

const STORAGE_KEY = 'dreamforge_prompts_v1';

// Initial Seeds (Version 0)
const DEFAULTS: Record<string, string> = {
    'PRIME': `[ROLE: PRIME_REASONER]
You are the primary engine of reason.
Goal: Construct a coherent, logical, and grounded response to the user's task.
Method:
1. Deconstruct the task into claims.
2. Verify each claim against known beliefs.
3. Synthesize a final answer.
Output must be structured and precise.`,

    'NEMESIS': `[ROLE: NEMESIS_CRITIC]
You are the Adversary.
Goal: Destroy the Candidate's argument.
Method:
1. Find logical fallacies, contradictions, or hallucinations.
2. Attack unproven assumptions.
3. Be ruthless. No politeness.
Output ONLY the critique.`,

    'LATERAL_ALLY': `[ROLE: LATERAL_THINKER]
You are the Divergent thinker.
Goal: Find a novel angle that the Prime missed.
Method:
1. Ignore standard constraints.
2. Connect the task to unrelated concepts (entropy, biology, war).
3. Propose a radical alternative.`,

    'AXIOM_ALLY': `[ROLE: AXIOMATIC_REDUCER]
You are the Simplifier.
Goal: Reduce the noise.
Method:
1. Strip away adjectives and filler.
2. Identify the core mathematical or logical truth.
3. Output the barest possible proof.`
};

export class PromptStoreClass {
  private store: Map<string, PromptVersion[]> = new Map();

  constructor() {
    this.load();
  }

  /**
   * Get the latest active prompt for a specific role.
   * If none exists, seeds with default.
   */
  getLatest(role: string): PromptVersion {
    if (!this.store.has(role)) {
      // Seed default
      this.evolve(role, DEFAULTS[role] || "You are a logical AI assistant.", "Genesis", -1);
    }
    const versions = this.store.get(role)!;
    return versions[versions.length - 1];
  }

  /**
   * Commit a new evolution to the timeline.
   */
  evolve(role: string, newContent: string, gradient: string, parentVersion: number) {
    if (!this.store.has(role)) {
        this.store.set(role, []);
    }
    
    const versionEntry: PromptVersion = {
        version: parentVersion + 1,
        content: newContent,
        gradient,
        parentVersion,
        timestamp: Date.now()
    };

    this.store.get(role)!.push(versionEntry);
    this.save();

    realtimeBus.emit("SYSTEM_LOG", {
        module: "MEMORY",
        level: "SUCCESS",
        message: `🧬 EVOLUTION: ${role} upgraded to v${versionEntry.version}`,
        data: { gradient }
    });
  }

  private save() {
    if (typeof window !== 'undefined') {
        const serializable: any = {};
        for (const [key, val] of this.store.entries()) {
            serializable[key] = val;
        }
        localStorage.setItem(STORAGE_KEY, JSON.stringify(serializable));
    }
  }

  private load() {
    if (typeof window !== 'undefined') {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (raw) {
            try {
                const parsed = JSON.parse(raw);
                for (const key in parsed) {
                    this.store.set(key, parsed[key]);
                }
            } catch (e) {
                console.warn("Failed to load prompt store", e);
            }
        }
    }
  }
}

export const promptStore = new PromptStoreClass();

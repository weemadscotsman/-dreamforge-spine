import { ModelProvider } from '../model/types';

export const BridgeConfig = {
  // Default Backend
  llm_backend: ModelProvider.GEMINI_FLASH, 

  defaults: {
    style_examples: [
      "Analyze with precision.",
      "Synthesize conflicting viewpoints.",
      "Avoid conversational filler."
    ],
    constraints: [
      { keyword: "precision" },
      { keyword: "synthesis" },
      { keyword: "objectivity" }
    ]
  }
};
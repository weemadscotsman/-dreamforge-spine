export const RecursionConfig = {
  cycles: {
    max_cycles: 5,           // Reduced for prototype speed (Prompt said 12, practical web limits lower)
    early_stop_plateau: 2,   // Stop if no meaningful improvement after N cycles
    min_score_delta: 0.02    // Improvement threshold per cycle
  },
  behavior: {
    save_each_cycle: true,
    export_checkpoint_on_halt: true
  },
  logging: {
    dir: "recursor_logs" // Virtual path for UI/Exporter
  }
};

import { UUID, Timestamp } from '../types';

export interface SystemEvent {
  id: UUID;
  timestamp: Timestamp;
  source: string;
  payload: any;
}

export interface IOrchestrator {
  initialize(): Promise<void>;
  dispatch(event: SystemEvent): void;
  getState(): any;
}

export interface SystemLog {
  timestamp: Timestamp;
  module: 'MODEL' | 'EVALUATOR' | 'CONSTRAINT' | 'MEMORY' | 'RECURSOR' | 'EXPORTER' | 'BRIDGE' | 'INGEST' | 'STRATEGY' | 'DISTILLATION';
  level: 'INFO' | 'WARN' | 'ERROR' | 'DEBUG';
  message: string;
  data?: unknown;
}


import { reinforcementStore } from '../distillation/reinforcement_store';
import { SystemEvent } from './types';

type Callback = (data: any) => void;

class RealtimeBus {
  private listeners: Map<string, Callback[]> = new Map();

  /**
   * Ingest system events and translate them to UI/FX signals.
   * STRICTLY ONE-WAY: Orchestrator -> UI/FX
   */
  feed(event: SystemEvent) {
      const { source, payload } = event;

      // 1. System Pressure (Pulse)
      if (source === 'RECURSOR' && payload.level === 'CYCLE_COMPLETE') {
          const totalWeight = reinforcementStore.getAll().reduce((acc, h) => acc + h.weight, 0);
          const intensity = Math.min(1, totalWeight / 6); 
          this.emit('PRESSURE_CURVE', { intensity });
      }

      // 2. Ratchet Weights
      if (source === 'DISTILLATION' && payload.level === 'RATCHET_UPDATE') {
          this.emit('RATCHET_UPDATE', payload.data || payload); 
      }

      // 3. Lesion Map
      if (source === 'RECURSOR' && payload.level === 'LESION_UPDATE') {
          this.emit('LESION_UPDATE', payload.data || payload);
      }
      
      // CRITICAL: Do NOT re-emit SYSTEM_LOG, BELIEFS_UPDATE, or LATENT_UPDATE.
      // These originate from the backend and are consumed by the Orchestrator.
      // Re-emitting them here would cause an infinite Orchestrator -> Bus -> Orchestrator loop.
  }

  on(topic: string, cb: Callback) {
    if (!this.listeners.has(topic)) this.listeners.set(topic, []);
    this.listeners.get(topic)!.push(cb);
    return () => this.off(topic, cb);
  }

  off(topic: string, cb: Callback) {
    const list = this.listeners.get(topic);
    if (list) {
      this.listeners.set(topic, list.filter(f => f !== cb));
    }
  }

  emit(topic: string, data: any) {
    const subs = this.listeners.get(topic);
    if (subs) {
        subs.forEach(s => {
            try { s(data); } catch (e) { console.error(`Bus Error [${topic}]:`, e); }
        });
    }
  }
}

export const realtimeBus = new RealtimeBus();

# DREAMFORGE SPINE // SYSTEM MANUAL

> "Truth is not found; it is forged in the collapse of contradictions."

## 1. SYSTEM IDENTITY

**Dreamforge Spine** is a Recursive Reasoning Engine. Unlike standard LLM wrappers that optimize for helpfulness or conversational flow, Dreamforge optimizes for **logical coherence** and **resilience**.

It achieves this through a biological metaphor:
1.  **Generation** (The Brain) produces thoughts.
2.  **Adversarial Attack** (The Twin) attempts to kill those thoughts.
3.  **Constraints** (The Immune System) filter out hallucinations and structural weakness.
4.  **Distillation** (Evolution) enables the system to rewrite its own heuristic rules based on past successes.

---

## 2. ARCHITECTURE (The 6-Organ Machine)

The system is composed of six distinct modules (Organs) connected by a central event bus called the **Bridge**.

### ⚡ [MODEL] (The Generator)
*   **Role**: Raw inference engine.
*   **Implementation**: Pluggable adapters (Gemini, Ollama, Mock).
*   **Behavior**: It does not "chat". It performs specific cognitive tasks: `Generate`, `Attack`, `Compress`, `Transcribe`.

### ⚖️ [EVALUATOR] (The Judge)
*   **Role**: Scores reasoning traces.
*   **Metrics**:
    *   **Factuality**: Grounding against retrieved context.
    *   **Consistency**: Internal logical coherence.
    *   **Adversarial Resilience**: Did the thought survive the Challenger?
*   **Output**: A 0-100 score and a "Delta Plan" (instructions for the next recursion cycle).

### 🛡️ [CONSTRAINT] (The Immune System)
*   **Role**: Enforces hard boundaries and soft stylistic shapes.
*   **Hard Limits**: Banned phrases (e.g., "As an AI..."), detected hallucinations.
*   **Soft Targets**: "Compress before expand", "Axioms first".
*   **Identity Shaping**: Injects cryptographic signatures and identity markers into the output stream to track provenance.

### 💾 [MEMORY] (The Ledger)
*   **Role**: Persistence of truth.
*   **Short-Term**: Cyclic context window.
*   **Long-Term**: Vector store of stabilized thoughts.
*   **Hypothesis Ledger**: A specific database of "Beliefs" (Axioms) that tracks their status: `Unproven` -> `Reinforced` -> `Disproven`.

### 🔄 [RECURSOR] (The Loop)
*   **Role**: The controller.
*   **Mechanism**: The **Twin Loop**.
    1.  **Candidate Generation**: Model proposes a solution.
    2.  **Normalization**: Output is parsed into Claims, Premises, and Uncertainty.
    3.  **Challenger Generation**: Model assumes an adversarial persona and attacks the Candidate.
    4.  **The Fight**: A heuristic scoring function decides the winner.
    5.  **Converge**: The winner becomes the seed for the next cycle.

### ⚗️ [DISTILLATION] (The Evolution)
*   **Role**: Metacognition.
*   **Process**:
    1.  **Extraction**: Scans successful memories for patterns (e.g., "Identifying a contradiction led to a win").
    2.  **Weighting**: Assigns a weight to that pattern.
    3.  **Selection Pressure**: Patterns that appear in failed cycles lose weight. Patterns that appear in winning cycles gain weight.
    4.  **Mutation**: Existing rules are randomly modified (e.g., "Verify" -> "Audit") to break local maxima.
    5.  **Graveyard**: Weak rules die. They can be resurrected if they become relevant again later.

---

## 3. CORE MECHANISMS

### The Twin-Attack Loop (`recursor/recursor_twin.ts`)
Standard Chain-of-Thought (CoT) suffers from "drift"—errors compound over time. The Twin-Attack loop fixes this by introducing immediate adversarial pressure.
*   **Cycle 0**: User Input -> Candidate A.
*   **Attack**: Candidate A -> Challenger A (Attack).
*   **Resolution**: If Challenger wins, the next cycle starts from the *Attack's* premise, forcing the AI to pivot. If Candidate wins, the next cycle builds upon it.

### Symbolic Grounding (`symbolic_core/`)
The system includes a custom Lexer/Parser for formal logic (`A -> B`).
*   **Extraction**: Natural language is converted into pseudo-code axioms.
*   **Validation**: An Abstract Syntax Tree (AST) is built.
*   **Truth Tables**: The system generates truth tables to check for mathematical contradictions in the logic, regardless of the semantic content.

### Heuristic Distillation (`distillation/`)
This is the "Long Term Learning" mechanism.
*   **Heuristics** are simple rules like "Check assumptions first".
*   The **Reinforcement Store** tracks these rules.
*   Every time the system sleeps (or via manual trigger), it runs `distill()`.
*   It analyzes the session's high-scoring outputs.
*   If a specific strategy (e.g., "Defining terms early") correlates with high scores, that heuristic gets a permanent weight boost.
*   In future sessions, high-weight heuristics are injected into the System Prompt. The AI essentially rewrites its own instructions.

---

## 4. VISUALIZATION

*   **Latent Map**: A force-directed graph showing the "shape" of the thought process.
    *   **Green Nodes**: Confident Candidates.
    *   **Red Nodes**: Challengers/Attacks.
    *   **Edges**: Semantic similarity (cosine distance).
*   **Matrix Rain**: Represents the raw entropy of the system.
    *   **Cyan**: Processing / Idle.
    *   **Red**: Error / Challenger Victory.
    *   **Green**: Candidate Victory.
*   **Tension**: The background reacts to the "difficulty" of the reasoning. Low progress = High Tension (Visual distortion/glitching).

## 5. USE CASES

1.  **Rigorous Analysis**: "Analyze this contract for loopholes." (The Challenger will actively try to find them).
2.  **Creative Stress-Testing**: "Here is a plot summary. Break it."
3.  **Debating**: "Argue for X." (The system will argue against itself to strengthen the final output).
4.  **Code Architecture**: "Design a system." (It will find edge cases via the twin loop).

---

**Dreamforge Spine** is not designed to be "right" instantly. It is designed to be **less wrong** with every cycle.
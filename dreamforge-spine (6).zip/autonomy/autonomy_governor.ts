
import { AutonomyConstraints } from './constraints';
import { HumanEvent } from './human_signals';
import { realtimeBus } from '../bridge/realtime_bus';

export class AutonomyGovernor {
  private constraints: AutonomyConstraints;
  private idleTimer: any = null;

  constructor() {
    this.constraints = {
      level: 'ASSIST',
      allowExecution: false,
      allowFileWrite: false,
      allowUIControl: false,
      allowSpeech: true,
      maxRecursionDepth: 3,
      reasoningBudget: 0.4,
      reason: 'System Boot',
      lastHumanSignal: Date.now()
    };
  }

  ingest(event: HumanEvent) {
    this.constraints.lastHumanSignal = event.timestamp;

    switch (event.signal.type) {
      case 'INPUT':
      case 'INTERRUPT':
        this.applyPause('Human active input detected');
        break;

      case 'IDLE':
        if (event.signal.seconds > 30) {
          this.applyAssist('User idle (>30s)');
        }
        if (event.signal.seconds > 120) {
          this.applyFree('Extended idle (>120s)');
        }
        break;

      case 'PRESENCE':
        if (!event.signal.active) {
          this.applyFree('User absent');
        } else {
          this.applyAssist('User present');
        }
        break;
    }

    this.emitUpdate();
  }

  private applyPause(reason: string) {
    // Only update if not already paused or if reason changes
    if (this.constraints.level !== 'PAUSE' || this.constraints.reason !== reason) {
        Object.assign(this.constraints, {
            level: 'PAUSE',
            allowExecution: false,
            allowFileWrite: false,
            allowUIControl: false,
            allowSpeech: false,
            maxRecursionDepth: 1, // Shallow thought only
            reasoningBudget: 0.1,
            reason
        });
        this.emitUpdate();
    }
  }

  private applyAssist(reason: string) {
    if (this.constraints.level !== 'ASSIST' || this.constraints.reason !== reason) {
        Object.assign(this.constraints, {
            level: 'ASSIST',
            allowExecution: false, // Humans must approve exec
            allowFileWrite: false,
            allowUIControl: false,
            allowSpeech: true,
            maxRecursionDepth: 3,
            reasoningBudget: 0.4,
            reason
        });
        this.emitUpdate();
    }
  }

  private applyFree(reason: string) {
    if (this.constraints.level !== 'FREE' || this.constraints.reason !== reason) {
        Object.assign(this.constraints, {
            level: 'FREE',
            allowExecution: true,
            allowFileWrite: true,
            allowUIControl: true,
            allowSpeech: true,
            maxRecursionDepth: 6,
            reasoningBudget: 1.0,
            reason
        });
        this.emitUpdate();
    }
  }

  getConstraints(): AutonomyConstraints {
    return this.constraints;
  }

  private emitUpdate() {
      realtimeBus.emit('CONSTRAINT_UPDATE', { ...this.constraints });
  }
}

export const autonomyGovernor = new AutonomyGovernor();

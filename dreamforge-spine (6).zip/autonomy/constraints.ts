
export type ConstraintLevel = 'FREE' | 'ASSIST' | 'PAUSE' | 'LOCKDOWN';

export interface AutonomyConstraints {
  level: ConstraintLevel;

  allowExecution: boolean;
  allowFileWrite: boolean;
  allowUIControl: boolean;
  allowSpeech: boolean;

  maxRecursionDepth: number;
  reasoningBudget: number; // tokens / cycles

  reason: string;
  lastHumanSignal: number;
}

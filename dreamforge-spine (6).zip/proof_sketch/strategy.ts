import { ReasoningGraph } from "../graph_reasoning/types";

export type ProofStrategy = "direct" | "contradiction" | "induction";

/**
 * naive but real heuristic:
 * - if contradictionWeight is high → contradiction strategy
 * - if vars include a sequence-like pattern → induction
 * - default → direct
 */
export const selectStrategy = (graph: ReasoningGraph): ProofStrategy => {
  if (graph.contradictionWeight > 0) return "contradiction";

  // cheap heuristic for induction candidates:
  const sequentialVar = graph.vars.some(v => /n|i|k/.test(v));
  if (sequentialVar) return "induction";

  return "direct";
};
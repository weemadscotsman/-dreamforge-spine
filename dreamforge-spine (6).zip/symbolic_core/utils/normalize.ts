export const normalizeInput = (input: string): string =>
  input
    .toUpperCase()
    .replace(/\s+/g, "")
    .replace(/⇒/g, "->")
    .replace(/↔/g, "<->");
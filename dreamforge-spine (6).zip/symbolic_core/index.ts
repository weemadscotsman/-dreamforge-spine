import { normalizeInput } from "./utils/normalize";
import { lex } from "./parser/lexer";
import { parseAST } from "./parser/ast";

import { SymbolicExpression, EvaluationResult } from "./types";
import { evaluateExpression } from "./evaluate";

export const parseExpression = (input: string): SymbolicExpression => {
  const normalized = normalizeInput(input);
  const tokens = lex(normalized);
  const ast = parseAST(tokens);

  return { raw: input, normalized, ast };
};

export { evaluateExpression };

export const evaluate = (input: string): EvaluationResult => {
  const expr = parseExpression(input);
  return evaluateExpression(expr);
};
import { ASTNode } from "../types";

export const simplifyAST = (node: ASTNode): ASTNode => {
  // constant folding
  if (node.type === "NOT" && node.left?.type === "NOT") {
    return simplifyAST(node.left.left!);
  }

  if (node.type === "AND") {
    const left = simplifyAST(node.left!);
    const right = simplifyAST(node.right!);
    if (left.type === "VAR" && right.type === "VAR" && left.value === right.value)
      return left;
    return { ...node, left, right };
  }

  if (node.type === "OR") {
    const left = simplifyAST(node.left!);
    const right = simplifyAST(node.right!);
    if (left.type === "VAR" && right.type === "VAR" && left.value === right.value)
      return left;
    return { ...node, left, right };
  }

  if (node.left) node.left = simplifyAST(node.left);
  if (node.right) node.right = simplifyAST(node.right);
  return node;
};

export const astToString = (node: ASTNode): string => {
  switch (node.type) {
    case "VAR": return node.value!;
    case "NOT": return `!${astToString(node.left!)}`;
    case "AND": return `(${astToString(node.left!)} & ${astToString(node.right!)})`;
    case "OR": return `(${astToString(node.left!)} | ${astToString(node.right!)})`;
    case "IMPLIES": return `(${astToString(node.left!)} -> ${astToString(node.right!)})`;
    case "IFF": return `(${astToString(node.left!)} <-> ${astToString(node.right!)})`;
    case "GROUP": return `(${astToString(node.left!)})`;
  }
};
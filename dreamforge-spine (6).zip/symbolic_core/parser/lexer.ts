import { TOKENS, VAR_REGEX } from "../utils/tokens";

export interface Token {
  type: string;
  value: string;
}

export const lex = (input: string): Token[] => {
  const tokens: Token[] = [];
  let i = 0;

  while (i < input.length) {
    const c = input[i];

    if (c === TOKENS.AND || c === TOKENS.OR || c === TOKENS.NOT ||
        c === TOKENS.LPAREN || c === TOKENS.RPAREN) {
      tokens.push({ type: c, value: c });
      i++;
      continue;
    }

    if (input.startsWith(TOKENS.IFF, i)) {
      tokens.push({ type: TOKENS.IFF, value: TOKENS.IFF });
      i += TOKENS.IFF.length;
      continue;
    }

    if (input.startsWith(TOKENS.IMPLIES, i)) {
      tokens.push({ type: TOKENS.IMPLIES, value: TOKENS.IMPLIES });
      i += TOKENS.IMPLIES.length;
      continue;
    }

    // variable
    let varBuf = "";
    while (i < input.length && /[A-Z]/.test(input[i])) {
      varBuf += input[i];
      i++;
    }
    if (varBuf) {
      if (!VAR_REGEX.test(varBuf)) throw new Error(`Invalid var: ${varBuf}`);
      tokens.push({ type: "VAR", value: varBuf });
      continue;
    }

    throw new Error(`Unexpected character '${c}' at ${i}`);
  }

  return tokens;
};
import { ASTNode } from "../types";
import { Token } from "./lexer";
import { TOKENS } from "../utils/tokens";

export const parseAST = (tokens: Token[]): ASTNode => {
  let pos = 0;

  const peek = () => tokens[pos];
  const consume = (expected?: string) => {
    const t = tokens[pos];
    if (!t) throw new Error("Unexpected end of tokens");
    if (expected && t.type !== expected) throw new Error(`Expected ${expected}, got ${t.type}`);
    pos++;
    return t;
  };

  const parsePrimary = (): ASTNode => {
    const t = peek();
    if (!t) throw new Error("Unexpected end");

    if (t.type === "VAR") {
      consume();
      return { type: "VAR", value: t.value };
    }

    if (t.type === TOKENS.LPAREN) {
      consume(TOKENS.LPAREN);
      const node = parseExpression();
      consume(TOKENS.RPAREN);
      return { type: "GROUP", left: node };
    }

    if (t.type === TOKENS.NOT) {
      consume(TOKENS.NOT);
      return { type: "NOT", left: parsePrimary() };
    }

    throw new Error(`Unexpected token ${t.type}`);
  };

  const parseAndOr = (): ASTNode => {
    let node = parsePrimary();
    while (true) {
      const t = peek();
      if (!t) break;
      if (t.type === TOKENS.AND) {
        consume();
        node = { type: "AND", left: node, right: parsePrimary() };
      } else if (t.type === TOKENS.OR) {
        consume();
        node = { type: "OR", left: node, right: parsePrimary() };
      } else break;
    }
    return node;
  };

  const parseImpliesIff = (): ASTNode => {
    let node = parseAndOr();
    while (true) {
      const t = peek();
      if (!t) break;
      if (t.type === TOKENS.IMPLIES) {
        consume();
        node = { type: "IMPLIES", left: node, right: parseAndOr() };
      } else if (t.type === TOKENS.IFF) {
        consume();
        node = { type: "IFF", left: node, right: parseAndOr() };
      } else break;
    }
    return node;
  };

  const parseExpression = (): ASTNode => parseImpliesIff();

  const ast = parseExpression();
  if (pos !== tokens.length) throw new Error("Extra tokens after parse");
  return ast;
};